use strict;
use warnings;

use SWF::Parser;
use SWF::Element;
use SWF::BinStream;
use SWF::BinStream::File;
use File::Path;
use Data::Dumper;
use Compress::Zlib;

sub Error($)
{
	my $msg = shift;
	open ERR, ">$::OutDir\\errors.txt";
	print ERR "$msg\n";
	close ERR;
	print STDERR $msg;
	exit 1;
	# todo; let multiple errors happen and then exit at check points?
}


print "FluixExtract is designed to only be run by the Content Pipeline."and exit 1 if $#ARGV != 1;

my %Data;
my %MovieInfo;
my $GradientTextureId = -1;
my $FakeGradientRecords = '';
my %AlreadyCreatedGradients;
my $PathsArePostscript = 0;
my $LastShapePointX = 0;
my $LastShapePointY = 0;
my $p=SWF::Parser->new('header-callback' => \&header, 'tag-callback' => \&data);

$::OutDir = $ARGV[1];
mkpath($::OutDir);

open XML, ">$::OutDir\\tags.xml" or Error("Couldn't open $::OutDir\\tags.xml for output");
Error "couldn't open $ARGV[0]" if (! -e $ARGV[0] || ! -r $ARGV[0]);
print XML "<Tags>\n";
$p->parse_file($ARGV[0]);
print XML $FakeGradientRecords;
print XML "</Tags>\n";

close XML;

sub header
{
    my ($self, $signature, $version, $length, $xmin, $ymin, $xmax, $ymax, $rate, $count) = @_;
	Error("Bad header") if ($signature ne 'FWS' and $signature ne 'CWS');
	Error("Version should be less than or equal to 6") if ($version > 6);
	print XML "<FrameRate><Value>$rate</Value></FrameRate>\n";
	print XML "<NumFrames><Value>$count</Value></NumFrames>\n";
}

sub outputToFile
{
	if (not defined $_[0])
	{
		Carp::confess;
	}
	print XML ' ' x ($_[1] * 4), $_[0]
}

sub GetSelfPath()
{
	my $selfPath = $0;
	if (defined $PerlApp::BUILD)
	{
		my $build = $PerlApp::BUILD;
		$selfPath = PerlApp::exe();
	}
	$selfPath =~ s/(.*)\\.*$/$1/;
	#print "$selfPath\n";
	return $selfPath;
}

sub GetEdge($$$)
{
	my $a = shift;
	my $b = shift;
	my $edges = shift;

	#print Dumper($a, $b, $edges);
	foreach my $edge (@$edges)
	{
		return $edge if ($edge->{a} == $a and $edge->{b} == $b);
		if ($edge->{b} == $a and $edge->{a} == $b)
		{
			return {
				a => $b,
				b => $a,
				fill0 => $edge->{fill1},
				fill1 => $edge->{fill0},
				nonorig => 1
			};
		}
	}
	return undef;
}

sub FindUntriedTriangle($$$$)
{
	my $v1 = shift;
	my $v2 = shift;
	my $tris = shift;
	my $tried = shift;

	foreach my $tri (@$tris)
	{
		if (not $tried->{$tri})
		{
			if (
				($tri->[0] == $v1 and $tri->[1] == $v2)
			or  ($tri->[1] == $v1 and $tri->[0] == $v2)
			or	($tri->[1] == $v1 and $tri->[2] == $v2)
			or  ($tri->[2] == $v1 and $tri->[1] == $v2)
			or	($tri->[0] == $v1 and $tri->[2] == $v2)
			or  ($tri->[2] == $v1 and $tri->[0] == $v2)
				)
			{
				return $tri;
			}
		}
	}
	return undef;
}

sub GetFillForTriangle($$$$);
sub GetFillForTriangle($$$$)
{
	my $tri = shift;
	my $edges = shift;
	my $tris = shift;
	my $tried = shift;

	return if (defined $tried->{$tri});
	$tried->{$tri} = 1;

	my $edge = undef;
	my $count = 0;
	#if ($tricount == 9)
	#{
	#	print Dumper($tri);
	#}
	my $a = $tri->[0];
	my $b = $tri->[1];
	my $c = $tri->[2];
	while (not defined $edge)
	{
		#print "looking for $a $b\n" if $tricount ==9;
		$edge = GetEdge($a, $b, $edges);
		#print Dumper($edge);
		my $temp = $a;
		$a = $b;
		$b = $c;
		$c = $temp;
		++$count;
		if ($count == 4)
		{
			my $sharedAB = FindUntriedTriangle($a, $b, $tris, $tried);
			if (defined $sharedAB)
			{
				#print "in AB $a, $b\n" if $tricount==9;
				#print Dumper($tried, $sharedAB) if $tricount==9;
				my $ret = GetFillForTriangle($sharedAB, $edges, $tris, $tried);
				return $ret if $ret;
			}

			my $sharedBC = FindUntriedTriangle($b, $c, $tris, $tried);
			if (defined $sharedBC)
			{
				#print "in BC $b, $c\n" if $tricount==9;
				my $ret = GetFillForTriangle($sharedBC, $edges, $tris, $tried);
				return $ret if $ret;
			}

			my $sharedCA = FindUntriedTriangle($c, $a, $tris, $tried);
			if (defined $sharedCA)
			{
				#print "in CA $c, $a\n" if $tricount==9;
				my $ret = GetFillForTriangle($sharedCA, $edges, $tris, $tried);
				return $ret if $ret;
			}
		}
	}
	return $edge;
}

sub GetStyleFor($$$$)
{
	my $tri = shift;
	my $tris = shift;
	my $edges = shift;
	my $verts = shift;

	#if ($tricount == 9)
	#{
	#print Dumper($tri);
	#print Dumper($edges);
	#}
	my $a = $tri->[0];
	my $b = $tri->[1];
	my $c = $tri->[2];
	my %tried;
	my $fill = GetFillForTriangle($tri, $edges, $tris, \%tried);
	return 0 if not defined $fill;
	my $x1 = $verts->[$a]->[0];
	my $y1 = $verts->[$a]->[1];
	my $x2 = $verts->[$b]->[0];
	my $y2 = $verts->[$b]->[1];
	my $x = $verts->[$c]->[0];
	my $y = $verts->[$c]->[1];
	if (not defined $x)
	{
		print Dumper($tri);
		print Dumper($a, $b, $c, $x, $x1, $x2, $y, $y1, $y2);
		Error("internal error in triangulation");
		exit 1;
	}
	my $halfSpace = ($x2 - $x1) * ($y - $y1) - ($y2 - $y1) * ($x - $x1);
	if ($halfSpace < 0)
	{
		#return $fill->{fill1} if ($PathsArePostscript);
		return $fill->{fill0};
	}
	elsif ($halfSpace > 0)
	{
		#return $fill->{fill0} if ($PathsArePostscript);
		return $fill->{fill1};
	}
	else
	{
		return undef;
	}
}

sub evaluateQuadraticBezier($$$$$$$)
{
	my ($x0, $y0, $x1, $y1, $x2, $y2, $t) = @_;
	my $dx0 = $x1 - $x0;
	my $dy0 = $y1 - $y0;
	my $dx1 = $x2 - $x1;
	my $dy1 = $y2 - $y1;

	my $ax = $x0 + $dx0 * $t;
	my $ay = $y0 + $dy0 * $t;
	my $bx = $x1 + $dx1 * $t;
	my $by = $y1 + $dy1 * $t;

	my $maindx = $bx - $ax;
	my $maindy = $by - $ay;
	return [ $ax + $maindx * $t, $ay + $maindy * $t ];
}

sub addPoint($$$$)
{
	my $x = shift;
	my $y = shift;
	my $points = shift;
	my $have = shift;

	#if ($PathsArePostscript)
	#{
	#$y = -$y;
	#$x = -$x;
	#}

	if (defined $have->{$x}{$y})
	{
		return $have->{$x}{$y};
	}
	push @$points, [ $x, $y ];
	$have->{$x}{$y} = $#$points;
	return $#$points;
}

sub addEdge($$$$$$$$)
{
	my ($lastPoint, $curPoint, $edges, $fillStyle0, $fillStyle1, $lineStyle, $fs, $ls) = @_;
	Error "Was expecting to have a last point when encountering a straight edge" if $lastPoint == -1;
	my $newEdge = { a => $lastPoint, b => $curPoint };
	$newEdge->{fill0} = $fillStyle0 > 0 ? $fs->[$fillStyle0 - 1] : undef;
	$newEdge->{fill1} = $fillStyle1 > 0 ? $fs->[$fillStyle1 - 1] : undef;
	$newEdge->{line} = $lineStyle > 0 ? $ls->[$lineStyle - 1] : undef;
	push @$edges, $newEdge;
}

sub GenerateLine($$$$$$$)
{
	my $width = shift;
	my $a = shift;
	my $b = shift;
	my $points = shift;
	my $finalGeoPoints = shift;
	my $finalGeoTris = shift;
	my $pointCurrentBase = shift;
	my $halfwidth = $width / 2;
	my $PI = 3.1415926535;

	my $dy = $b->[1] - $a->[1];
	my $dx = $b->[0] - $a->[0];
	my $rotation = atan2($dy, $dx);

	#
	# main quad
	#
	my $leftXDelta = $halfwidth * sin($rotation + $PI);
	my $leftYDelta = $halfwidth * cos($rotation + $PI);
	my $rightXDelta = $halfwidth * sin($rotation);
	my $rightYDelta = $halfwidth * cos($rotation);
	
	my $leftTop = [ $a->[0] + $leftXDelta,
				 $a->[1] + $leftYDelta ];
	my $rightTop = [ $a->[0] + $rightXDelta,
				  $a->[1] + $rightYDelta ];
	my $leftBottom = [ $b->[0] + $leftXDelta,
					$b->[1] + $leftYDelta ];
	my $rightBottom = [ $b->[0] + $rightXDelta,
					 $b->[1] + $rightYDelta ];

	$$finalGeoPoints .= "v $leftTop->[0] $leftTop->[1]\n";
	$$finalGeoPoints .= "v $rightTop->[0] $rightTop->[1]\n";
	$$finalGeoPoints .= "v $leftBottom->[0] $leftBottom->[1]\n";
	$$finalGeoPoints .= "v $rightBottom->[0] $rightBottom->[1]\n";

	my $v0 = $$pointCurrentBase + 0;
	my $v1 = $$pointCurrentBase + 1;
	my $v2 = $$pointCurrentBase + 2;
	my $v3 = $$pointCurrentBase + 3;
	$$finalGeoTris .= "t $v0 $v3 $v2\n";
	$$finalGeoTris .= "t $v0 $v1 $v3\n";

	$$pointCurrentBase += 4;

	if ($width > 40)
	{
		my $numSegs = 8;

		#
		# top half circle
		#
		$$finalGeoPoints .= "v $a->[0] $a->[1]\n";
		my $numAdded = 1;
		for (my $d = 0; $d >= -$PI; $d -= $PI / $numSegs)
		{
			my $p = [ $a->[0] + $halfwidth * sin($PI - ($rotation + $d)),
			$a->[1] + $halfwidth * cos($PI - ($rotation + $d))];
			$$finalGeoPoints .= "v $p->[0] $p->[1]\n";
			$numAdded += 1;
		}
		for (my $i = 0; $i < $numAdded - 2; $i++)
		{
			my $v0 = $$pointCurrentBase + $i + 1;
			my $v1 = $$pointCurrentBase + $i + 2;
			$$finalGeoTris .= "t $$pointCurrentBase $v0 $v1\n";
		}
		$$pointCurrentBase += $numAdded;

		#
		# bottom half circle
		#
		$$finalGeoPoints .= "v $b->[0] $b->[1]\n";
		$numAdded = 1;
		for (my $d = 0; $d <= $PI; $d += $PI / $numSegs)
		{
			my $p = [ $b->[0] + $halfwidth * sin($PI - ($rotation + $d)),
			$b->[1] + $halfwidth * cos($PI - ($rotation + $d)) ];
			$$finalGeoPoints .= "v $p->[0] $p->[1]\n";
			$numAdded += 1;
		}
		for (my $i = 0; $i < $numAdded - 2; $i++)
		{
			my $v0 = $$pointCurrentBase + $i + 1;
			my $v1 = $$pointCurrentBase + $i + 2;
			$$finalGeoTris .= "t $$pointCurrentBase $v0 $v1\n";
		}
		$$pointCurrentBase += $numAdded;
	}
}

sub FindGradientPair($$)
{
	my $gradients = shift;
	my $point = shift;

	my $closestBelowDist = -1000;
	my $closestBelowRecord;
	my $closestAboveDist = 1000;
	my $closestAboveRecord;

	foreach my $grad (@$gradients)
	{
		if (int($grad->Ratio) <= int($point) and int($grad->Ratio) > int($closestBelowDist))
		{
			$closestBelowDist = $grad->Ratio;
			$closestBelowRecord = $grad;
		}
		if (int($grad->Ratio) >= int($point) and int($grad->Ratio) < int($closestAboveDist))
		{
			$closestAboveDist = $grad->Ratio;
			$closestAboveRecord = $grad;
		}
	}

	if (not defined $closestAboveRecord)
	{
		$closestAboveRecord = $closestBelowRecord;
	}
	if (not defined $closestBelowRecord)
	{
		$closestBelowRecord = $closestAboveRecord;
	}
	if ($closestAboveRecord eq $closestBelowRecord)
	{
		return ($closestBelowRecord, $closestAboveRecord, 1);
	}
	else
	{
		return ($closestBelowRecord, $closestAboveRecord, ($point - $closestBelowDist) / ($closestAboveDist - $closestBelowDist));
	}
}

sub lerp($$$)
{
	my ($a, $b, $t) = @_;
	return (($b - $a) * $t) + $a;
}

sub LerpColour($$$)
{
	my $c0rec = shift;
	my $c1rec = shift;
	my $t = shift;

	my $c0 = [ $c0rec->Red, $c0rec->Green, $c0rec->Blue, 255.0 ];
	$c0->[3] = $c0rec->Alpha if ref($c0rec) =~ /RGBA/;
	my $c1 = [ $c1rec->Red, $c1rec->Green, $c1rec->Blue, 255.0 ];
	$c1->[3] = $c1rec->Alpha if ref($c1rec) =~ /RGBA/;

	my $result = [
		lerp($c0->[0], $c1->[0], $t),
		lerp($c0->[1], $c1->[1], $t),
		lerp($c0->[2], $c1->[2], $t),
		lerp($c0->[3], $c1->[3], $t)
	];

	# tga wants bgra
	return pack('CCCC', int($result->[2]), int($result->[1]), int($result->[0]), int($result->[3]));
}

sub GenerateGradientTexture($)
{
	my $style = shift;

	if (defined $AlreadyCreatedGradients{$style})
	{
		return $AlreadyCreatedGradients{$style};
	}

	my $fn = "$::OutDir\\" . $GradientTextureId . ".tga";

	# bgra order
	my $data;
	my $w;
	my $h;

	if ($style->FillStyleType == 0x10)
	{
		$w = 128;
		$h = 4;

		for (my $y = 0; $y < $h; $y++)
		{
			for (my $x = 0; $x < $w; $x++)
			{
				my ($left, $right, $fraction) = FindGradientPair($style->Gradient, $x * 255 / $w);
				$data .= LerpColour($left->Color, $right->Color, $fraction);
			}
		}
	}
	elsif ($style->FillStyleType == 0x12)
	{
		# must be square for ratio below
		$w = 128;
		$h = 128;

		for (my $y = 0; $y < $h; $y++)
		{
			for (my $x = 0; $x < $w; $x++)
			{
				my $dx = ($w / 2.0) - $x;
				my $dy = ($h / 2.0) - $y;
				my $distFromCentre = sqrt($dx*$dx + $dy*$dy);
				my $ratio = $distFromCentre * 255.0 / ($w/2.0);
				$ratio = 255.0 if $ratio > 255.0;
				$ratio = 0.0 if $ratio < 0.0;
				my ($left, $right, $fraction) = FindGradientPair($style->Gradient, $ratio);
				$data .= LerpColour($left->Color, $right->Color, $fraction);
			}
		}
		#print Dumper($style->Gradient);
	}
	else
	{
		Error("unexpected gradient fill style type: $style->FillStyleType");
	}


	$FakeGradientRecords .= <<GRAD
<DefineBitsLossless2>
    <CharacterID>$GradientTextureId</CharacterID>
    <BitmapFormat>5</BitmapFormat>
    <BitmapWidth>$w</BitmapWidth>
    <BitmapHeight>$h</BitmapHeight>
</DefineBitsLossless2>
GRAD
;

	open OUT, ">$fn" or Error "couldn't open $fn";
	binmode OUT;
	print OUT pack('CCCssCSSSSCC', 0, 0, 2, 0, 0, 0, 0, 0, $w, $h, 32, 32 + 8);
	print OUT $data;
	print OUT pack('sx493C', 495, 3);
	print OUT pack('LL', length($data) + 18, 0);
	print OUT "TRUEVISION-XFILE.\0";

	$AlreadyCreatedGradients{$style} = {
		id => $GradientTextureId,
		w => $w,
		h => $h
	};
	$GradientTextureId--;

	return $AlreadyCreatedGradients{$style};
}

sub Mult2DMatrix($$)
{
	my $mat = shift;
	my $point = shift;

	my $a = $mat->[0] * $point->[0] + $mat->[2] * $point->[1];
	my $b = $mat->[1] * $point->[0] + $mat->[3] * $point->[1];
	my $c = $mat->[0] * $point->[0];
	my $d = $mat->[2] * $point->[1];
	#print "$a, $b vs $c, $d\n";
	return [ $a, $b ];
}

sub FlushShape($$$$$$$)
{
	#print "Flushing!\n";
	my ($t, $curShape, $points, $edges, $finalGeoPoints, $finalGeoTris, $pointCurrentBase) = @_;
	#print Dumper($points);
	#print Dumper($edges);
	my $fn = "$::OutDir\\" . $t->ShapeID . "_" . $$curShape . ".poly";
	my $elefn = "$::OutDir\\" . $t->ShapeID . "_" . $$curShape . ".ele";
	my $nodefn = "$::OutDir\\" . $t->ShapeID . "_" . $$curShape . ".node";
	($$curShape) += 1;
	open POLY, ">$fn" or Error "couldn't open $fn";

	my $numOutPoints = $#$points + 1;
	while ($numOutPoints < 3)
	{
		push @$points, [ 0, 0 ];
		$numOutPoints++;
	}
	print POLY "$numOutPoints 2 0 0\n";
	for (my $i = 0; $i < $numOutPoints; $i++)
	{
		print POLY "$i $points->[$i][0] $points->[$i][1]\n";
	}
	print POLY "\n";

	print POLY ($#$edges + 1 . " 1\n");
	for (my $i = 0; $i <= $#$edges; $i++)
	{
		my $b = $i + 2;
		print POLY "$i $edges->[$i]{a} $edges->[$i]{b} $b\n";
	}
	print POLY "\n";

	print POLY "0\n";
	close POLY;

	my $selfPath = GetSelfPath();
	if (system("\"$selfPath\\trianglew.exe\" -p -P -I -Q \"$fn\"") != 0)
	{
		Error("couldn't convert geometry: $!");
	}

	open NODE, $nodefn or Error "couldn't open $nodefn";
	my $firstNodeLine = <NODE>;
	$firstNodeLine =~ s/^\s*//;
	my @firstNodeLineParts = split /\s+/, $firstNodeLine;
	my %generatedPointsMap;
	my $numFinalPoints = int($firstNodeLineParts[0]);
	for (my $i = 0; $i < $numFinalPoints; $i++)
	{
		my $l = <NODE>;
		if ($i >= $numOutPoints)
		{
			$l =~ s/^\s*//;
			my @line = split /\s+/, $l;
			$generatedPointsMap{$i} = $line[3];
		}
	}
	close NODE;

	open ELE, $elefn or Error "couldn't open $elefn";
	my @header = split /\s+/, <ELE>;
	Error("expecting 'tri'angles from triangle.exe") if $header[1] != 3;
	my @triangles;
	for (my $i = 0; $i < $header[0]; $i++)
	{
		my $l = <ELE>;
		$l =~ s/^\s*//;
		my @line = split /\s+/, $l;
		my $v0 = int($line[1]);
		my $v1 = int($line[2]);
		my $v2 = int($line[3]);
		$v0 = $generatedPointsMap{$v0} if $v0 >= $numOutPoints;
		$v1 = $generatedPointsMap{$v1} if $v1 >= $numOutPoints;
		$v2 = $generatedPointsMap{$v2} if $v2 >= $numOutPoints;
		push @triangles, [ $v0, $v1, $v2 ];
	}
	close ELE;

	foreach my $point (@$points)
	{
		$$finalGeoPoints .= "v $point->[0] $point->[1]\n";
	}

	my $prevStyle = '';
	# todo; style sort?
	foreach my $tri (@triangles)
	{
		#print "tricount: $tricount\n";
		my $style = GetStyleFor($tri, \@triangles, $edges, $points);
		#++$tricount;
		#print Dumper($style);
		next if not defined $style; # skip; empty

		my $newStyle = '';

		if ($style->FillStyleType eq 0)
		{
			my $outColour = $style->Color->Red . " " . $style->Color->Green . " " . $style->Color->Blue;
			my $alpha = "255";
			$alpha = $style->Color->Alpha if ref($style->Color) =~ /RGBA/;
			$newStyle = "mat solid $outColour $alpha";
		}
		elsif ($style->FillStyleType >= 0x40 and $style->FillStyleType <= 0x43)
		{
			my $wrapClamp = "wrap";
			$wrapClamp = "clamp" if ($style->FillStyleType == 0x41 or $style->FillStyleType == 0x43);
			$newStyle = "mat textured $wrapClamp " .
						$style->BitmapID . " " .
						$style->BitmapMatrix->ScaleX . " " .
						$style->BitmapMatrix->ScaleY . " " .
						$style->BitmapMatrix->RotateSkew0 . " " .
						$style->BitmapMatrix->RotateSkew1 . " " .
						$style->BitmapMatrix->TranslateX . " " .
						$style->BitmapMatrix->TranslateY;
		}
		elsif ($style->FillStyleType == 0x10 || $style->FillStyleType == 0x12)
		{
			my $gradData = GenerateGradientTexture($style);
			my $mat = 
			[
				$style->GradientMatrix->ScaleX,
				$style->GradientMatrix->RotateSkew0,
				$style->GradientMatrix->RotateSkew1,
				$style->GradientMatrix->ScaleY
			];
			my $multiplied = Mult2DMatrix($mat, [ 16384.0, 16384.0 ]);
			$newStyle = "mat textured clamp " .
						$gradData->{id} . " " .
						(($style->GradientMatrix->ScaleX) * 32768.0 / $gradData->{w}) . " " .
						(($style->GradientMatrix->ScaleY) * 32768.0 / $gradData->{h}) . " " .
						(($style->GradientMatrix->RotateSkew0) * 32768.0 / $gradData->{w}) . " " .
						(($style->GradientMatrix->RotateSkew1) * 32768.0 / $gradData->{h}) . " " .
						($style->GradientMatrix->TranslateX - $multiplied->[0]) . " " .
						($style->GradientMatrix->TranslateY - $multiplied->[1]);

		}
		if ($newStyle ne $prevStyle)
		{
			$$finalGeoTris .= "$newStyle\n";
			$prevStyle = $newStyle;
		}

		my $v0 = $tri->[0] + $$pointCurrentBase;
		my $v1 = $tri->[1] + $$pointCurrentBase;
		my $v2 = $tri->[2] + $$pointCurrentBase;
		$$finalGeoTris .= "t $v0 $v1 $v2\n";
	}

	$$pointCurrentBase += $#$points + 1;

	# make mitred lines
	for (my $i = 0; $i <= $#$edges; $i++)
	{
		my $style = $edges->[$i]{line};
		next if not defined $style;
		my $endA = $points->[$edges->[$i]{a}];
		my $endB = $points->[$edges->[$i]{b}];

		my $outColour = $style->Color->Red . " " . $style->Color->Green . " " . $style->Color->Blue;
		my $alpha = "255";
		$alpha = $style->Color->Alpha if ref($style->Color) =~ /RGBA/;
		my $newStyle = "mat solid $outColour $alpha";
		if ($newStyle ne $prevStyle)
		{
			$$finalGeoTris .= "$newStyle\n";
			$prevStyle = $newStyle;
		}
		GenerateLine($style->Width, $endA, $endB, $points, $finalGeoPoints, $finalGeoTris, $pointCurrentBase);
	}
}

sub premult($$)
{
	my $c = shift;
	my $a = shift;
	$c = int(unpack('C', $c)) / 255.0;
	$a = int(unpack('C', $a)) / 255.0;
	return pack('C', (($c * $a) * 255.0));
}

sub prediv($$)
{
	my $c = shift;
	my $a = shift;
	$c = int(unpack('C', $c)) / 255.0;
	$a = int(unpack('C', $a)) / 255.0;
	if ($a == 0.0)
	{
		return pack('C', 255);
	}
	return pack('C', (($c / $a) * 255.0));
}

sub GetPalette($$$)
{
	my $colourTableSize = shift;
	my $data = shift;
	my $alpha = shift;
	my @palette;
	
	my $pos = 0;
	my $elementSize = $alpha ? 4 : 3;
	for (my $i = 0; $i < $colourTableSize; ++$i)
	{
		my $elem = substr($data, $pos, $elementSize);
		if (not $alpha)
		{
			$elem = pack('C', 255) . $elem;
		}

		my $a = substr($elem, 0, 1);
		my $r = substr($elem, 1, 1);
		my $g = substr($elem, 2, 1);
		my $b = substr($elem, 3, 1);
		my $result = prediv($b,$a) . prediv($g,$a) . prediv($r,$a) . $a;
		push @palette, $result;
		$pos += $elementSize;
	}

	return (\@palette, substr($data, $pos));
}

sub data
{
	my ($self, $tag, $length, $stream)=@_;
	my $t = SWF::Element::Tag->new(Tag=>$tag, Length=>$length);
	my ($tagname) = $t->tag_name;

	eval {
		$t->unpack($stream);
	};
	if ($@) {
		my $mes = $@;
		$t->dumper;
		Error($mes);
	}

	if ($tagname eq 'JPEGTables')
	{
		#print STDERR "JPEGTables\n";
		my $jpegData = $t->JPEGData;
		$jpegData = substr($jpegData, 4) if (substr($jpegData, 0, 4) eq "\xff\xd9\xff\xd8");
		$jpegData = substr($jpegData, 2) if (substr($jpegData, 0, 2) eq "\xff\xd8");
		$jpegData = substr($jpegData, 0, -2) if (substr($jpegData, -2) eq "\xff\xd9");
		$::JpegTables = $jpegData;
	}
	elsif ($tagname eq 'PathsArePostscript')
	{
		$PathsArePostscript = 1;
	}
	elsif ($tagname eq 'DefineBits')
	{
		#print STDERR "Bits\n";
		my $fn = "$::OutDir\\" . $t->CharacterID . ".jpg";
		open OUT, ">$fn" or Error "couldn't open $fn";
		binmode OUT;
		my $jpegData = $t->JPEGData;
		$jpegData = substr($jpegData, 4) if (substr($jpegData, 0, 4) eq "\xff\xd9\xff\xd8");
		my $insertOffset = unpack('n', substr($jpegData, 4, 2)) + 4;
		print OUT (substr($jpegData, 0, $insertOffset) . $::JpegTables . substr($jpegData, $insertOffset));
		close OUT;
	}
	elsif ($tagname eq 'DefineBitsJPEG2')
	{
		#print STDERR "BitsJPEG2\n";
		my $fn = "$::OutDir\\" . $t->CharacterID . ".jpg";
		open OUT, ">$fn" or Error "couldn't open $fn";
		binmode OUT;
		my $jpegData = $t->JPEGData;
		$jpegData = substr($jpegData, 4) if (substr($jpegData, 0, 4) eq "\xff\xd9\xff\xd8");
		print OUT $jpegData;
		close OUT;
	}
	elsif ($tagname eq 'DefineBitsJPEG3')
	{
		Error("Haven't implemented JPEG with Alpha yet. You can avoid this by setting Properties->Compression to Lossless (PNG/GIF).");
	}
	#elsif ($tagname eq 'DefineEditText')
	#{
	#	&$outputsub("<WordWrap>" . $t->WordWrap . "</WordWrap>\n", 0);
	#	&$outputsub("<Multiline>" . $t->Multiline . "</Multiline>\n", 0);
	#}
	elsif ($tagname eq 'DefineBitsLossless' or $tagname eq 'DefineBitsLossless2')
	{
		#print STDERR "BitsLossless\n";
		my $w = $t->BitmapWidth;
		my $h = $t->BitmapHeight;

		my $haveAlpha = 0;
		$haveAlpha = 1 if $tagname eq 'DefineBitsLossless2';

		#print STDERR ($t->BitmapFormat . "\n$w x $h\n");
		my $compressed = $t->ZlibBitmapData->value;
		my $uncomp = uncompress($compressed);
		#print STDERR length($uncomp);
		my $imageData = '';

		if ($t->BitmapFormat == 3)
		{
			my $colourTableSize = $t->BitmapColorTableSize;
			my ($palette,$image) = GetPalette($colourTableSize + 1, $uncomp, $haveAlpha);
			my $i = 0;
			for (my $y = 0; $y < $h; ++$y)
			{
				for (my $x = 0; $x < $w; ++$x)
				{
					$imageData .= $palette->[unpack('C', substr($image, $i, 1))];
					++$i;
				}
			}
		}
		elsif ($t->BitmapFormat == 4)
		{
			Error "Haven't implemented lossless 15 bit images yet";
		}
		elsif ($t->BitmapFormat == 5)
		{
			for (my $i = 0; $i < length($uncomp); $i += 4)
			{
				my $a = substr($uncomp, $i, 1);
				my $r = substr($uncomp, $i + 1, 1);
				my $g = substr($uncomp, $i + 2, 1);
				my $b = substr($uncomp, $i + 3, 1);
				$imageData .= prediv($b,$a) . prediv($g,$a) . prediv($r,$a) . $a;
			}
		}

		my $fn = "$::OutDir\\" . $t->CharacterID . ".tga";
		open OUT, ">$fn" or Error "couldn't open $fn";
		binmode OUT;
		print OUT pack('CCCssCSSSSCC', 0, 0, 2, 0, 0, 0, 0, 0, $w, $h, 32, 32 + 8);
		print OUT $imageData;
		print OUT pack('sx493C', 495, 3);
		print OUT pack('LL', length($imageData) + 18, 0);
		print OUT "TRUEVISION-XFILE.\0";
		close OUT;
	}
	elsif ($tagname eq 'DefineSound')
	{
		my $fn = "$::OutDir\\" . $t->SoundID() . ".raw";
		my $convfn = "$::OutDir\\" . $t->SoundID() . ".wav";
		open OUT, ">$fn" or Error "couldn't open $fn";
		binmode OUT;
		print OUT $t->SoundData();
		close OUT;

		my $rate = '-r 5512';
		$rate = '-r 11025' if ($t->SoundRate == 1);
		$rate = '-r 22050' if ($t->SoundRate == 2);
		$rate = '-r 44100' if ($t->SoundRate == 3);

		my $size = '-b';
		$size = '-w' if ($t->SoundSize == 1);

		my $format = '-s';
		$format = '-a' if ($t->SoundFormat == 1);
		$format = '-s' if ($t->SoundFormat == 3);

		my $type = '-c 1';
		$type = '-c 2' if ($t->SoundType == 1);

		my $selfPath = GetSelfPath();
		if (system("\"$selfPath\\soxw.exe\" $rate $size $format $type \"$fn\" \"$convfn\"") != 0)
		{
			Error("couldn't convert audio: $!");
		}
		unlink($fn);
	}
	elsif ($tagname eq 'DefineShape' or $tagname eq 'DefineShape2' or $tagname eq 'DefineShape3')
	{
		my $is2 = $tagname eq 'DefineShape2';
		my $fs = $t->Shapes()->FillStyles;
		my $ls = $t->Shapes()->LineStyles;
		my $shapeRecords = $t->Shapes()->ShapeRecords;
		#print ref($fs) . "\n";
		#print ref($ls) . "\n";
		my $posX = $LastShapePointX;
		my $posY = $LastShapePointY;
		my $fillStyle0 = 0;
		my $fillStyle1 = 0;
		my $lineStyle = 0;
		my @points;
		my @edges;
		my %HavePoints;
		my $lastPoint = addPoint($LastShapePointX, $LastShapePointY, \@points, \%HavePoints);
		my $curShape = 0;
		my $pointCurrentBase = 0;
		my $finalGeoPoints = '';
		my $finalGeoTris = '';
		my $justDidFlush = 0;
		foreach my $sr (@$shapeRecords)
		{
			$justDidFlush = 0;
			my $didMove = 0;
			my $flushShape = 0;
			if (ref($sr) =~ m/STYLECHANGERECORD/)
			{
				$fillStyle0 = $sr->FillStyle0 if defined $sr->FillStyle0;
				$fillStyle1 = $sr->FillStyle1 if defined $sr->FillStyle1;
				$lineStyle = $sr->LineStyle if defined $sr->LineStyle;
				if (defined $sr->MoveDeltaX)
				{
					$posX = $sr->MoveDeltaX;
					$didMove = 1;
				}
				if (defined $sr->MoveDeltaY)
				{
					$posY = $sr->MoveDeltaY;
					$didMove = 1;
				}
				if (defined $sr->MoveDeltaX and defined $sr->MoveDeltaY and $sr->MoveDeltaX == 0 and $sr->MoveDeltaY == 0)
				{
					$flushShape = 1;
				}
				$lastPoint = addPoint($posX, $posY, \@points, \%HavePoints) if $didMove;

				#print Dumper($sr);
				if ($is2 and $sr->FillStyles->defined)
				{
					$fs = $sr->FillStyles;
				}
				if ($is2 and $sr->LineStyles->defined)
				{
					$ls = $sr->LineStyles;
				}
			}
			elsif (ref($sr) =~ m/STRAIGHTEDGERECORD/)
			{
				$posX += $sr->DeltaX if defined $sr->DeltaX;
				$posY += $sr->DeltaY if defined $sr->DeltaY;
				my $curPoint = addPoint($posX, $posY, \@points, \%HavePoints);
				if ($curPoint != $lastPoint)
				{
					addEdge($lastPoint, $curPoint, \@edges, $fillStyle0, $fillStyle1, $lineStyle, $fs, $ls);
					$lastPoint = $curPoint;
				}
			}
			elsif (ref($sr) =~ m/CURVEDEDGERECORD/)
			{
				# approximate curves by N straight lines
				my $controlX = $posX + $sr->ControlDeltaX;
				my $controlY = $posY + $sr->ControlDeltaY;
				my $anchorX = $controlX + $sr->AnchorDeltaX;
				my $anchorY = $controlY + $sr->AnchorDeltaY;

				# todo; pick number of points based on world size
				my $numPoints = 8;
				for (my $i = 0; $i <= $numPoints; $i++)
				{
					my $evaledPoint = evaluateQuadraticBezier($posX, $posY, $controlX, $controlY, $anchorX, $anchorY, $i / $numPoints);
					my $curPoint = addPoint($evaledPoint->[0], $evaledPoint->[1], \@points, \%HavePoints);
					if ($curPoint != $lastPoint)
					{
						addEdge($lastPoint, $curPoint, \@edges, $fillStyle0, $fillStyle1, $lineStyle, $fs, $ls);
						$lastPoint = $curPoint;
					}
				}
				$posX = $anchorX;
				$posY = $anchorY;
			}
			else
			{
				die "unhandled shaperecord type";
			}
			if ($flushShape)
			{
				FlushShape($t, \$curShape, \@points, \@edges, \$finalGeoPoints, \$finalGeoTris, \$pointCurrentBase);
				$justDidFlush = 1;
				$flushShape = 0;
				@points = ();
				@edges = ();
				%HavePoints = ();
				$lastPoint = addPoint($posX, $posY, \@points, \%HavePoints) if $didMove;
			}
		}
		if (not $justDidFlush)
		{
			FlushShape($t, \$curShape, \@points, \@edges, \$finalGeoPoints, \$finalGeoTris, \$pointCurrentBase);
		}

		$LastShapePointX = $posX;
		$LastShapePointY = $posY;

		my $finalfn = "$::OutDir\\" . $t->ShapeID . ".geo";
		open GEO, ">$finalfn" or Error "couldn't open $finalfn";
		print GEO $finalGeoPoints;
		print GEO $finalGeoTris;
		close GEO;
	}
	elsif ($tagname eq 'DefineSound')
	{
	}
	$t->dumperxml(\&outputToFile);
	print XML "\n";
}


package SWF::Element;
use URI::Escape;
sub dumperxml
{
    my ($self, $outputsub, $indent)=@_;
    my @names=$self->element_names;

    $indent ||= 0;
    $outputsub||=\&_default_output;

	my $n = ref($self);
	$n =~ s/.*::(.*)$/$1/;

    &$outputsub("<$n>\n", 0);

    for my $key (@names) {
	no warnings 'uninitialized';
	if ($self->element_type($key) =~/^\$/) {
	    my $p = $self->$key;
	    $p = "\"$p\"" unless $p=~/^[-\d.]+$/;
		&$outputsub("<$key>$p</$key>\n", $indent+1) if defined($self->$key);
	} elsif ($self->$key->defined) {
		if ($key eq 'FontName')
		{
			my $noNulName = $self->$key->value;
			$noNulName =~ s/\x00$//g;
			&$outputsub("<$key>$noNulName</$key>\n", $indent+1);
		}
		elsif ($key eq 'InitialText')
		{
			my $escaped = uri_escape($self->$key->value);
			&$outputsub("<$key>$escaped</$key>\n", $indent+1);
		}
		elsif ($key ne 'JPEGData' && $key ne 'ZlibBitmapData' && $key ne 'SoundData')
		{
			&$outputsub("<$key>", $indent+1);
			$self->$key->dumperxml($outputsub, $indent+1);
			&$outputsub("</$key>\n", 0);
		}
	}
    }
    &$outputsub("</$n>", $indent);
}


package SWF::Element::Scalar;
use URI::Escape;
sub dumperxml
{
    my ($self, $outputsub,$indent,$inarr)=@_;
    $outputsub||=\&SWF::Element::_default_output;
	my $name = ref($self);
	$name =~ s/.*::(.*)$/$1/;
	&$outputsub("<$name>",0) if defined $inarr;
	if ($name eq 'NULL' or $name eq 'UNDEF')
	{
		&$outputsub('0', 0);
	}
	elsif ($name eq 'STRING' or $name eq 'String')
	{
		&$outputsub(uri_escape($self->value), 0);
	}
	else
	{
		&$outputsub($self->value, 0);
	}
	&$outputsub("</$name>\n",0) if defined $inarr;
}

package SWF::Element::Array;
sub dumperxml
{
    my ($self, $outputsub, $indent) = @_;

    $indent ||= 0;
    $outputsub||=\&SWF::Element::_default_output;

	my $name = ref($self);
	$name =~ s/.*::(.*)$/$1/;

    &$outputsub("<$name>\n", 0);
    my $n = 0;
    for my $i (@$self) {
	&$outputsub('', $indent+1);
	if (ref($i) eq '')
	{
		&$outputsub("<Value>$i</Value>\n", $indent);
	}
	else
	{
		$i->dumperxml($outputsub, $indent+1, 1);
	}
	$n++;
    }
    &$outputsub("</$name>", $indent);
}


package PerlApp;
1;
