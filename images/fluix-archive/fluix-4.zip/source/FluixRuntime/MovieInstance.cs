using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;
using System.Reflection;
using Fluix.Impl;

namespace Fluix
{
    internal class IntervalData
    {
        internal FunctionAndEnvironment Func;
        internal double ResetTime;
        internal double TimeLeft;
        internal object[] Params;
        internal IntervalData(FunctionAndEnvironment f, double time, object p0, object p1, object p2, object p3)
        {
            Func = f;
            ResetTime = time;
            TimeLeft = time;
            Params = new object[Func.Func.GetParameters().Length];
            if (Params.Length >= 1) Params[0] = f.Env;
            if (Params.Length >= 2) Params[1] = f.Env;
            if (Params.Length >= 3) Params[2] = p0;
            if (Params.Length >= 4) Params[3] = p1;
            if (Params.Length >= 5) Params[4] = p2;
            if (Params.Length >= 6) Params[5] = p3;
        }
    }


    public class FSCommandEventArgs
    {
        public string Command;
        public string Parameters;
        public FSCommandEventArgs(string command, string parameters)
        {
            Command = command;
            Parameters = parameters;
        }
    }
    public delegate void FSCommandEventDelegate(object sender, FSCommandEventArgs fse);

    public class MovieInstance : CharacterSpriteInstance
    {
        Movie mMovie;
        internal TimeSpan TimePerFrame;
        internal GeometryBatch GeomBatch;
        public bool UseMovieBackgroundColor = false;
        GraphicsDevice mGraphics;
        ContentManager mContent;
        internal int UnnamedInstanceCounter = 1;
        internal ScriptSupport.Object mGlobals;
        internal ScriptSupport.Key mKeyHandler;
        InputHandler mInputHandler;
        internal Dictionary<int, IntervalData> mIntervals = new Dictionary<int,IntervalData>();
        internal int mIntervalCounter = 0;
        public event FSCommandEventDelegate OnFSCommand;

        class MethodAndObject
        {
            public CharacterSpriteInstance Obj;
            public MethodInfo Method;
            public MethodAndObject(MethodInfo mi, CharacterSpriteInstance csi)
            {
                Method = mi;
                Obj = csi;
            }
        }
        List<MethodAndObject> mQueuedActions = new List<MethodAndObject>();

        private MovieInstance(Movie movie, GraphicsDevice graphics, ContentManager content, InputHandler input)
            : base(movie.mMain)
        {
            mMovie = movie;
            mGraphics = graphics;
            mContent = content;
            mInputHandler = input;
            mTransform = Matrix.Identity;
            mCxform = Cxform.Identity;
            TimePerFrame = new TimeSpan((1000000000 / mMovie.mFrameRate) / 100);
            GeomBatch = new GeometryBatch(graphics, content);
            mGlobals = new ScriptSupport.Object();
            Variables["_global"] = mGlobals;
            mGlobals.GetVariables()["_level0"] = this;
            mKeyHandler = new ScriptSupport.Key();
            mGlobals.GetVariables()["Key"] = mKeyHandler;
            mGlobals.GetVariables()["Math"] = new ScriptSupport.Math();
            mGlobals.GetVariables()["String"] = new ScriptSupport.String("");
            mGlobals.GetVariables()["setInterval"] = new FunctionAndEnvironment(typeof(MovieInstance).GetMethod("SetInterval_S"), this);
            mGlobals.GetVariables()["clearInterval"] = new FunctionAndEnvironment(typeof(MovieInstance).GetMethod("ClearInterval_S"), this);

            base.SetMovieInst(this);
        }

        public void SetVariable(string variable, object value)
        {
            IScriptObject cur = mGlobals;
            string[] parts = variable.Split(new char[] { '.' });
            for (int i = 0; i < parts.Length - 1; ++i)
            {
                string part = parts[i];
                if (!cur.GetVariables().ContainsKey(part))
                {
                    throw new Exception("'" + part + "' doesn't exist in trying to set '" + variable + "'");
                }
                if (!(cur.GetVariables()[part] is IScriptObject))
                {
                    throw new Exception("'" + part + "' isn't a container for variables in trying to set '" + variable + "'");
                }
                cur = cur.GetVariables()[part] as IScriptObject;
            }
            if (value is double || value is int || value is float)
            {
                cur.GetVariables()[parts[parts.Length - 1]] = (double)value;
            }
            else if (value is string)
            {
                cur.GetVariables()[parts[parts.Length - 1]] = (string)value;
            }
            else
            {
                throw new Exception("was expecting number or string for variable value");
            }
        }

        public override string ToString()
        {
            return "_level0"; // todo; level support. are they movieinstances? or csis?
        }

        protected override void AdvanceFrame()
        {
            base.AdvanceFrame();
            FlushActions();
        }

        internal void SendFSCommand(string command, string parameters)
        {
            OnFSCommand(this, new FSCommandEventArgs(command, parameters));
        }

        public override void Update(GameTime dt)
        {
            mKeyHandler.Process(mInputHandler.GetQueuedInputs());
            foreach (IntervalData id in mIntervals.Values)
            {
                id.TimeLeft -= dt.ElapsedGameTime.TotalMilliseconds;
                if (id.TimeLeft < 0)
                {
                    id.Func.Func.Invoke(id.Func.Env, id.Params);
                    id.TimeLeft += id.ResetTime;
                }
            }
            base.Update(dt);
        }

        public void FlushActions()
        {
            for (; ; )
            {
                List<MethodAndObject> cur = mQueuedActions;
                if (cur.Count == 0) break;
                mQueuedActions = new List<MethodAndObject>();
                foreach (MethodAndObject mao in cur)
                {
                    mao.Method.Invoke(null, new object[] { mao.Obj });
                }
            }
        }

        // mostly for test running
        public void UpdateAdvanceExactlyOneFrame()
        {
            Update(new GameTime(new TimeSpan(0), TimePerFrame, new TimeSpan(0), TimePerFrame));
        }

        public void Draw()
        {
            if (UseMovieBackgroundColor)
            {
                mGraphics.Clear(mMovie.mBackgroundColour);
                //mGraphics.Clear(Color.CornflowerBlue);
            }
            mInputHandler.ReadData();
            base.Draw(Matrix.Identity, Cxform.Identity);
            GeomBatch.Draw();
        }

        internal MethodInfo FindMethodInfoByName(string name)
        {
            if (mMovie.mASClass != null)
            {
                return mMovie.mASClass.GetMethod(name);
            }
            return null;
        }

        internal SoundBank GetSoundBank() { return mMovie.mSoundBank; }

        public int NumFrames { get { return mMovie.mNumFrames; } }

        internal void QueueAction(CharacterSpriteInstance csi, MethodInfo mi)
        {
            mQueuedActions.Add(new MethodAndObject(mi, csi));
        }

        public CharacterInstance MakeInstanceOf(int id, CharacterSpriteInstance parent)
        {
            Character ch = mMovie.mCharacters[id];
            if (ch is CharacterSprite)
            {
                return new CharacterSpriteInstance((CharacterSprite)ch, this, parent);
            }
            else if (ch is CharacterShape)
            {
                return new CharacterShapeInstance((CharacterShape)ch, this);
            }
            else if (ch is CharacterText)
            {
                return new CharacterTextInstance((CharacterText)ch, this, parent);
            }
            return null;
        }

        public static MovieInstance Create(string name, GraphicsDevice graphics, ContentManager content, InputHandler input)
        {
            Movie movie = content.Load<Movie>(name);
            return new MovieInstance(movie, graphics, content, input);
        }

        public static MovieInstance Create(string name, GraphicsDevice graphics, ContentManager content)
        {
            Movie movie = content.Load<Movie>(name);
            DefaultInputHandler dih = new DefaultInputHandler();
            return new MovieInstance(movie, graphics, content, dih);
        }

        public static object SetInterval_S(MovieInstance mov, IScriptObject context, object func, object timeout, object param0, object param1, object param2, object param3)
        {
            IntervalData id = new IntervalData((FunctionAndEnvironment)func, ScriptSupport.AsNumber(timeout), param0, param1, param2, param3);
            int ret = mov.mIntervalCounter++;
            mov.mIntervals[ret] = id;
            return (double)ret;
        }

        public static object ClearInterval_S(MovieInstance mov, IScriptObject context, object id)
        {
            mov.mIntervals.Remove((int)ScriptSupport.AsNumber(id));
            return ScriptSupport.undefined;
        }
    }
}
