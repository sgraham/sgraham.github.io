using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Input;

namespace Fluix
{
    internal class DefaultInputHandler : InputHandler
    {
        List<KeyAction> mQueued = new List<KeyAction>();
        GamePadState mLastPadState;
        KeyboardState mLastKeyState;
        
        public DefaultInputHandler()
        {
            mLastPadState = GamePad.GetState(0, GamePadDeadZone.Circular);
            mLastKeyState = Keyboard.GetState();
        }

        public List<KeyAction> GetQueuedInputs()
        {
            List<KeyAction> ret = mQueued;
            mQueued = new List<KeyAction>();
            return ret;
        }

        private void AddStateChange(ButtonState prev, ButtonState cur, int code)
        {
            if (prev == cur) return;
            mQueued.Add(new KeyAction(cur == ButtonState.Pressed, code));
        }
        
        private void AddPadStateChanges(GamePadState prev, GamePadState cur)
        {
            AddStateChange(prev.Buttons.A, cur.Buttons.A, 65);
            AddStateChange(prev.Buttons.B, cur.Buttons.B, 66);
            AddStateChange(prev.Buttons.X, cur.Buttons.X, 88);
            AddStateChange(prev.Buttons.Y, cur.Buttons.Y, 89);
            AddStateChange(prev.Buttons.LeftShoulder, cur.Buttons.LeftShoulder, 81);
            AddStateChange(prev.Buttons.RightShoulder, cur.Buttons.RightShoulder, 87);
            // 49, 50 for 1,2
            AddStateChange(prev.DPad.Up, cur.DPad.Up, 38);
            AddStateChange(prev.DPad.Down, cur.DPad.Down, 40);
            AddStateChange(prev.DPad.Left, cur.DPad.Left, 37);
            AddStateChange(prev.DPad.Right, cur.DPad.Right, 39);
        }

        private void AddKeyStateChanges(KeyboardState prev, KeyboardState cur)
        {
            foreach (Keys k in prev.GetPressedKeys())
            {
                if (cur.IsKeyUp(k))
                {
                    mQueued.Add(new KeyAction(false, (int)k));
                }
            }
            foreach (Keys k in cur.GetPressedKeys())
            {
                if (prev.IsKeyUp(k))
                {
                    mQueued.Add(new KeyAction(true, (int)k));
                }
            }
        }

        public void ReadData()
        {
            GamePadState padState = GamePad.GetState(0, GamePadDeadZone.Circular);
            AddPadStateChanges(mLastPadState, padState);
            mLastPadState = padState;

            KeyboardState keyState = Keyboard.GetState();
            AddKeyStateChanges(mLastKeyState, keyState);
            mLastKeyState = keyState;
        }
    }
}
