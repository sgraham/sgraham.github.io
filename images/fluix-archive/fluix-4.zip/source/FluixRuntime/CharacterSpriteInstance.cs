using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System.Diagnostics;

namespace Fluix
{
    namespace Impl
    {
        public class CharacterSpriteInstance : CharacterInstance, IScriptObject
        {
            CharacterSprite mData;
            internal DisplayList DisplayList;
            int mCurFrame;
            TimeSpan mLeftOverTime;
            internal MovieInstance MovieInstance;
            internal Dictionary<string, object> Variables = new Dictionary<string, object>();
            internal Dictionary<string, FunctionAndEnvironment> Functions = new Dictionary<string, FunctionAndEnvironment>();
            internal string InstanceName;
            internal CharacterSpriteInstance Parent;
            bool Playing = true;

            public Dictionary<string, object> GetVariables() { return Variables; }

            public bool SpecialGet(string key, out object value)
            {
                if (key == "_x")
                {
                    value = (double)mTransform.Translation.X;
                    return true;
                }
                else if (key == "_y")
                {
                    value = (double)mTransform.Translation.Y;
                    return true;
                }
                else if (key == "_alpha")
                {
                    value = (double)(mCxform.mul.W * 100.0);
                    return true;
                }
                value = null;
                return false;
            }

            public bool SpecialSet(string key, object value)
            {
                if (key == "_x")
                {
                    Vector3 old = mTransform.Translation;
                    old.X = (float)ScriptSupport.AsNumber(value);
                    mTransform.Translation = old;
                    return true;
                }
                else if (key == "_y")
                {
                    Vector3 old = mTransform.Translation;
                    old.Y = (float)ScriptSupport.AsNumber(value);
                    mTransform.Translation = old;
                    return true;
                }
                else if (key == "_alpha")
                {
                    mCxform.mul.W = (float)(ScriptSupport.AsNumber(value) / 100.0);
                    return true;
                }
                // todo; name, and removal of other one
                else
                {
                    return false;
                }
            }

            public override string ToString()
            {
                string str = "";
                if (Parent != null) str = Parent.ToString() + ".";
                if (InstanceName == null) str += "instance";
                else str += InstanceName;
                return str;
            }

            private void ProcessFrame(int frame)
            {
                Frame f = mData.Frames[frame];
                for (int i = 0; i < f.Display.Count; ++i)
                {
                    f.Display[i].Apply(this);
                }
            }

            protected virtual void AdvanceFrame()
            {
                if (Playing)
                {
                    int origFrame = mCurFrame;
                    ++mCurFrame;
                    if (mCurFrame == mData.Frames.Count)
                        mCurFrame = 0;
                    if (origFrame != mCurFrame)
                    {
                        if (mCurFrame == 0)
                        {
                            /*    foreach (CharacterInstance ci in DisplayList.Entries.Values)
                                {
                                    if (ci is IScriptObject) MovieInstance.mKeyHandler.RemoveInternal((IScriptObject)ci);
                                }*/
                            DisplayList.Entries.Clear();
                        }
                        ProcessFrame(mCurFrame);
                    }
                }
            }

            public CharacterSpriteInstance(CharacterSprite data, MovieInstance movieInst, CharacterSpriteInstance parent)
            {
                mData = data;
                DisplayList = new DisplayList();
                mCurFrame = 0;
                MovieInstance = movieInst;
                Parent = parent;
                InitFunctions();
                ProcessFrame(mCurFrame);
            }

            public CharacterSpriteInstance(CharacterSprite data)
            {
                mData = data;
                DisplayList = new DisplayList();
                mCurFrame = 0;
            }

            public void SetMovieInst(MovieInstance movieInst)
            {
                Debug.Assert(MovieInstance == null);
                MovieInstance = movieInst;
                InitFunctions();
                ProcessFrame(mCurFrame); // todo; emulation; this is almost definitely on the initial displaylist add, not here
            }

            private void InitFunctions()
            {
                Variables["play"] = new FunctionAndEnvironment(typeof(CharacterSpriteInstance).GetMethod("Play_S"), this);
                Variables["stop"] = new FunctionAndEnvironment(typeof(CharacterSpriteInstance).GetMethod("Stop_S"), this);
                Variables["gotoAndPlay"] = new FunctionAndEnvironment(typeof(CharacterSpriteInstance).GetMethod("GotoAndPlay_S"), this);
            }

            public override void Update(GameTime dt)
            {
                foreach (CharacterInstance ci in DisplayList.Entries.Values)
                {
                    ci.Update(dt);
                }

                Debug.Assert(MovieInstance != null);
                mLeftOverTime += dt.ElapsedGameTime;
                TimeSpan timePerFrame = MovieInstance.TimePerFrame;
                while (mLeftOverTime >= timePerFrame)
                {
                    AdvanceFrame();

                    mLeftOverTime -= timePerFrame;
                }

                // todo; emulation; action queue flush is probably at end of update frame of main movie? or some other time?
            }

            public override void Draw(Matrix xform, Cxform cxform)
            {
                Debug.Assert(MovieInstance != null);
                Matrix tempx = mTransform * xform;
                Cxform tempc = mCxform * cxform;
                foreach (CharacterInstance ci in DisplayList.Entries.Values)
                {
                    ci.Draw(tempx, tempc);
                }
            }

            public static void Stop_S(CharacterSpriteInstance env, IScriptObject context) { env.Stop(); }
            public void Stop()
            {
                Playing = false;
            }

            public static void Play_S(CharacterSpriteInstance env, IScriptObject context) { env.Play(); }
            public void Play()
            {
                Playing = true;
            }

            public static void GotoAndPlay_S(CharacterSpriteInstance env, IScriptObject context, object o) { env.GotoAndPlay(o); }
            public void GotoAndPlay(object o)
            {
                int origFrame = mCurFrame;
                int newFrame = (int)(double)o - 1;
                if (newFrame < 0 || newFrame >= mData.Frames.Count) return;
                mCurFrame = newFrame;
                if (origFrame != mCurFrame)
                {
                    ProcessFrame(mCurFrame);
                }
                Playing = true;
            }
        }

    }
}
