using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Audio;

namespace Fluix
{
    namespace Impl
    {
        public partial class Sound : IScriptObject
        {
            private SoundBank mSoundBank;
            private string mAttachedSound;
            private List<Cue> mCues = new List<Cue>();
            public Dictionary<string, object> Variables = new Dictionary<string, object>();
            public Dictionary<string, object> GetVariables() { return Variables; }
            public bool SpecialSet(string key, object value) { return false; }
            public bool SpecialGet(string key, out object value) { value = null; return false; }
            public override string ToString()
            {
                return "[object Sound]";
            }

            public static object AttachSound(object def, object context, object o)
            {
                Sound sound = def as Sound;
                sound.mAttachedSound = o as string;
                return ScriptSupport.undefined;
            }

            public static object Start(object def, object context, object secondOffset, object loops)
            {
                Sound sound = def as Sound;
                if (sound.mAttachedSound == null) return null;

                Cue cue = sound.mSoundBank.GetCue(sound.mAttachedSound);
                sound.mCues.Add(cue);
                // todo; second offset, loops
                cue.Play();

                return ScriptSupport.undefined;
            }

            public static object Stop(object def, object context)
            {
                Sound sound = def as Sound;
                foreach (Cue cue in sound.mCues)
                {
                    cue.Stop(AudioStopOptions.Immediate);
                }
                sound.mCues.Clear();
                return ScriptSupport.undefined;
            }
            
            public Sound(SoundBank sb)
            {
                mSoundBank = sb;
                Variables["attachSound"] = new FunctionAndEnvironment(typeof(Sound).GetMethod("AttachSound"), this);
                Variables["start"] = new FunctionAndEnvironment(typeof(Sound).GetMethod("Start"), this);
                Variables["stop"] = new FunctionAndEnvironment(typeof(Sound).GetMethod("Stop"), this);
            }
        }
    }
}
