using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;
using System.Reflection;
using System.Threading;

namespace Fluix
{
    namespace Impl
    {
        public class FunctionAndEnvironment
        {
            public MethodInfo Func;
            public IScriptObject Env;
            public FunctionAndEnvironment(MethodInfo mi, IScriptObject env)
            {
                Func = mi;
                Env = env;
            }
        }

        public enum PropertyIndex
        {
            _x = 0,
            _y,
            _xscale,
            _yscale,
            _currentframe,
            _totalframes,
            _alpha,
            _visible,
            _width,
            _height,
            _rotation,
            _target,
            _framesloaded,
            _name,
            _droptarget,
            _url,
            _highquality,
            _focusrect,
            _soundbuftime,
            _quality,
            _xmouse,
            _ymouse
        }

        public abstract class CharacterInstance
        {
            public abstract void Update(GameTime dt);
            public abstract void Draw(Matrix xform, Cxform cxform);
            public Matrix mTransform = Matrix.Identity;
            public Cxform mCxform = Cxform.Identity;
        }

        public interface IScriptObject
        {
            Dictionary<string, object> GetVariables();
            bool SpecialSet(string key, object value);
            bool SpecialGet(string key, out object value);
        }

        internal class Movie
        {
            internal Color mBackgroundColour;
            internal int mFrameRate;
            internal int mNumFrames;
            internal Dictionary<int, Character> mCharacters;
            internal CharacterSprite mMain;
            internal Assembly mAssembly;
            internal Type mASClass;
            internal Dictionary<int, string> mExports;
            internal AudioEngine mAudioEngine;
            internal WaveBank mWaveBank;
            internal SoundBank mSoundBank;
            internal List<Font> mFonts;

            void ResolveMethodsForSprite(CharacterSprite cs)
            {
                int count = 0;
                foreach (Frame f in cs.Frames)
                {
                    foreach (ControlCommand cc in f.Display)
                    {
                        if (cc is ControlCommandAction)
                        {
                            ControlCommandAction cca = (ControlCommandAction)cc;
                            cca.Method = mASClass.GetMethod(cca.MethodName);
                        }
                    }
                    ++count;
                }
            }

            internal Movie(
                Color bg,
                int frameRate,
                int numFrames,
                Dictionary<int, Character> chars,
                CharacterSprite main,
                Dictionary<int, Texture2D> textures,
                Dictionary<int, TextureData> texData,
                Assembly assembly,
                string moduleName,
                Dictionary<int, string> exports,
                AudioEngine audioEngine,
                WaveBank waveBank,
                SoundBank soundBank,
                List<Font> fonts
                )
            {
                mBackgroundColour = bg;
                mFrameRate = frameRate;
                mNumFrames = numFrames;
                mCharacters = chars;
                mMain = main;
                mAssembly = assembly;
                mExports = exports;
                mASClass = null;
                if (mAssembly != null)
                {
                    mASClass = mAssembly.GetModule(moduleName).GetType("FluixAS_" + moduleName);
                }
                mAudioEngine = audioEngine;
                mWaveBank = waveBank;
                mSoundBank = soundBank;
                mFonts = fonts;

                foreach (Character c in mCharacters.Values)
                {
                    if (c is CharacterShape)
                    {
                        CharacterShape cs = (CharacterShape)c;
                        foreach (VertexSet vs in cs.VertexSets)
                        {
                            if (vs.MatType == VertexSet.MaterialType.TextureClamped || vs.MatType == VertexSet.MaterialType.TextureWrapped)
                            {
                                vs.Texture = textures[vs.TexID];
                                float widthScale = 1.0f / (float)vs.Texture.Width;
                                //widthScale *= (float)texData[vs.TexID].OrigWidth / (float)vs.Texture.Width;
                                float heightScale = 1.0f / (float)vs.Texture.Height;
                                //heightScale *= (float)texData[vs.TexID].OrigHeight / (float)vs.Texture.Height;
                                Matrix pixelOffset = vs.TextureMatrix * Matrix.CreateTranslation(0.5f, 0.5f, 0.0f);
                                Matrix inv = Matrix.Invert(pixelOffset);
                                Matrix invscaled = inv * Matrix.CreateScale(widthScale, heightScale, 1.0f);
                                vs.TextureMatrix = invscaled;
                            }
                        }
                    }
                    else if (c is CharacterText)
                    {
                        CharacterText ct = (CharacterText)c;
                        ct.Font = mFonts[ct.FontId];
                    }
                    else if (mASClass != null && c is CharacterSprite)
                    {
                        ResolveMethodsForSprite((CharacterSprite)c);
                    }
                }
                ResolveMethodsForSprite(main);
            }
        }
    }
}
