using System;
using System.Collections.Generic;
using System.Text;

namespace Fluix
{
    namespace Impl
    {
        public partial class ScriptSupport
        {
            public class Key : IScriptObject
            {
                public Dictionary<string, object> Variables = new Dictionary<string, object>();
                public Dictionary<string, object> GetVariables() { return Variables; }
                public Dictionary<IScriptObject, bool> mListeners = new Dictionary<IScriptObject, bool>();
                private int CurCode = -1;
                private bool[] State = new bool[256];

                public bool SpecialSet(string key, object value) { return false; } // todo; are key 'define's readonly?
                public bool SpecialGet(string key, out object value) { value = null; return false; }

                public static object AddListener(IScriptObject iso, object k, object listener)
                {
                    if (!(k is Key)) return undefined;
                    Key key = (Key)k;
                    key.mListeners[(IScriptObject)listener] = true;
                    return undefined;
                }

                public static object RemoveListener(IScriptObject iso, object k, object listener)
                {
                    if (!(k is Key)) return false;
                    Key key = (Key)k;
                    return key.mListeners.Remove((IScriptObject)listener);
                }

                internal void RemoveInternal(IScriptObject iso)
                {
                    mListeners.Remove(iso);
                }

                public static object GetAscii(IScriptObject iso, object k)
                {
                    if (!(k is Key)) return 0;
                    Key key = (Key)k;
                    return 0;
                }

                public static object GetCode(IScriptObject iso, object k)
                {
                    if (!(k is Key)) return 0;
                    Key key = (Key)k;
                    return (double)key.CurCode;
                }

                public static object IsDown(IScriptObject iso, object k, object code)
                {
                    if (!(k is Key)) return false;
                    Key key = (Key)k;
                    int c = (int)(double)code;
                    if (c < 0 || c >= key.State.Length) return false;
                    return key.State[c];
                }

                public Key()
                {
                    Variables["BACKSPACE"] = 8;
                    Variables["CAPSLOCK"] = 20;
                    Variables["CONTROL"] = 17;
                    Variables["DELETEKEY"] = 46;
                    Variables["DOWN"] = 40;
                    Variables["END"] = 35;
                    Variables["ENTER"] = 13;
                    Variables["ESCAPE"] = 27;
                    Variables["HOME"] = 36;
                    Variables["INSERT"] = 45;
                    Variables["LEFT"] = 37;
                    Variables["PGDN"] = 34;
                    Variables["PGUP"] = 33;
                    Variables["RIGHT"] = 39;
                    Variables["SHIFT"] = 16;
                    Variables["SPACE"] = 32;
                    Variables["TAB"] = 9;
                    Variables["UP"] = 38;

                    Variables["addListener"] = new FunctionAndEnvironment(typeof(Key).GetMethod("AddListener"), null);
                    Variables["removeListener"] = new FunctionAndEnvironment(typeof(Key).GetMethod("RemoveListener"), null);
                    Variables["getAscii"] = new FunctionAndEnvironment(typeof(Key).GetMethod("GetAscii"), null);
                    Variables["getCode"] = new FunctionAndEnvironment(typeof(Key).GetMethod("GetCode"), null);
                    Variables["isDown"] = new FunctionAndEnvironment(typeof(Key).GetMethod("IsDown"), null);
                }

                internal void Process(List<KeyAction> keys)
                {
                    foreach (KeyAction ka in keys)
                    {
                        if (ka.Code >= 0 && ka.Code < State.Length)
                        {
                            State[ka.Code] = ka.Pressed;
                        }
                        foreach (IScriptObject iso in mListeners.Keys)
                        {
                            CurCode = ka.Code;
                            string name = ka.Pressed ? "onKeyDown" : "onKeyUp";
                            if (iso.GetVariables().ContainsKey(name))
                            {
                                object handler = iso.GetVariables()[name];
                                if (handler is FunctionAndEnvironment)
                                {
                                    FunctionAndEnvironment fae = (FunctionAndEnvironment)handler;
                                    fae.Func.Invoke(null, new object[] { fae.Env, fae.Env });
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
