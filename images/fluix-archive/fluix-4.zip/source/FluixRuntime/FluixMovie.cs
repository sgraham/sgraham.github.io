using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline.Processors;

namespace Fluix
{
    [Serializable]
    public class DisplayCommand { }

    [Serializable]
    public class DisplayCommandPlace : DisplayCommand
    {
        public int Depth;
        public Matrix2D Matrix;
        public int ID;
        public DisplayCommandPlace(int depth)
        {
            Depth = depth;
        }
    }

    [Serializable]
    public class Frame
    {
        public List<DisplayCommand> Display = new List<DisplayCommand>();
    }

    [Serializable]
    public class Character
    {
        public int ID;
        public Character(int id) { ID = id; }
    }

    [Serializable]
    public class CharacterButton : Character
    {
        public CharacterButton(int id) : base(id) { }
    }

    [Serializable]
    public class CharacterSprite : Character
    {
        public CharacterSprite(int id) : base(id) { }
        public List<Frame> Frames = new List<Frame>();
    }

    [Serializable]
    public class CharacterShape : Character
    {
        public CharacterShape(int id) : base(id) {}
    }

    [Serializable]
    public class Matrix2D
    {
        public double m00, m01, m10, m11;
        public double tx, ty;
    }

    public class SwfCompiled
    {
        public Color BackgroundColour;
        public Dictionary<int, Character> Characters = new Dictionary<int, Character>();
        public CharacterSprite Main;
        public Dictionary<int, ModelContent> Models = new Dictionary<int, ModelContent>();
    }
}
