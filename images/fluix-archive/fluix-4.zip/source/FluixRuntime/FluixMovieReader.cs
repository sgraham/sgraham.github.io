using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using System.Reflection;
using System.Threading;
using System.IO;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;

namespace Fluix
{
    namespace Impl
    {
        internal class FluixMovieReader : ContentTypeReader<Movie>
        {
            protected override Movie Read(ContentReader input, Movie existingInstance)
            {
                byte r = input.ReadByte();
                byte g = input.ReadByte();
                byte b = input.ReadByte();
                byte a = input.ReadByte();
                Color bg = new Color(r, g, b, a);
                int frameRate = input.ReadInt32();
                int numFrames = input.ReadInt32();
                BinaryFormatter bf = new BinaryFormatter();
                Dictionary<int, Character> chars = (Dictionary<int, Character>)bf.Deserialize(input.BaseStream);
                CharacterSprite main = (CharacterSprite)bf.Deserialize(input.BaseStream);
                Dictionary<int, TextureData> texData = (Dictionary<int, TextureData>)bf.Deserialize(input.BaseStream);
                Dictionary<int, string> exports = (Dictionary<int, string>)bf.Deserialize(input.BaseStream);
                Assembly assembly = null;
                string moduleName = null;
                int numBytesInCodeAssembly = input.ReadInt32();
                if (numBytesInCodeAssembly > 0)
                {
                    moduleName = input.ReadString();
                    byte[] codeAssembly = input.ReadBytes(numBytesInCodeAssembly);
                    assembly = Thread.GetDomain().Load(codeAssembly);
                }
                Dictionary<int, Texture2D> textures = new Dictionary<int, Texture2D>();
                int numTextures = input.ReadInt32();
                for (int i = 0; i < numTextures; ++i)
                {
                    int id = input.ReadInt32();
                    Texture2D tex = input.ReadObject<Texture2D>();
                    textures.Add(id, tex);
                }
                int xgsLength = input.ReadInt32();
                int xwbLength = input.ReadInt32();
                int xsbLength = input.ReadInt32();
                AudioEngine audioEngine = null;
                WaveBank waveBank = null;
                SoundBank soundBank = null;
                if (xgsLength != 0)
                {
                    string xgsFilename = StorageContainer.TitleLocation + "\\" + moduleName + ".xgs";
                    string xwbFilename = StorageContainer.TitleLocation + "\\" + moduleName + ".xwb";
                    string xsbFilename = StorageContainer.TitleLocation + "\\" + moduleName + ".xsb";
                    File.WriteAllBytes(xgsFilename, input.ReadBytes(xgsLength));
                    File.WriteAllBytes(xwbFilename, input.ReadBytes(xwbLength));
                    File.WriteAllBytes(xsbFilename, input.ReadBytes(xsbLength));
                    if (false) // I don't know what's arsed in the XACT build right now, but.. yah :(
                    {
                        audioEngine = new AudioEngine(xgsFilename);
                        waveBank = new WaveBank(audioEngine, xwbFilename);
                        soundBank = new SoundBank(audioEngine, xsbFilename);
                    }
                    File.Delete(xgsFilename);
                    File.Delete(xwbFilename);
                    File.Delete(xsbFilename);
                }
                int numFonts = input.ReadInt32();
                List<Font> fonts = new List<Font>();
                for (int i = 0; i < numFonts; ++i)
                {
                    Texture2D tex = input.ReadObject<Texture2D>();
                    char min = input.ReadChar();
                    char max = input.ReadChar();
                    List<Rectangle> rects = input.ReadObject<List<Rectangle>>();
                    fonts.Add(new Font(tex, min, max, rects));
                }
                return new Movie(bg, frameRate, numFrames, chars, main, textures, texData, assembly, moduleName, exports, audioEngine, waveBank, soundBank, fonts);
            }
        }
    }
}
