using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Fluix
{
    namespace Impl
    {
        public class CharacterShapeInstance : CharacterInstance
        {
            CharacterShape mData;
            MovieInstance mMovieInstance;

            internal CharacterShapeInstance(CharacterShape data, MovieInstance movieInst)
            {
                mData = data;
                mMovieInstance = movieInst;
            }

            public override void Update(GameTime dt)
            {
            }

            public override void Draw(Matrix xform, Cxform cxform)
            {
#if false // other version that uses "real" models
            for (int i = 0; i < mData.Model.Meshes.Count; ++i)
            {
                ModelMesh mesh = mData.Model.Meshes[i];
                for (int j = 0; j < mesh.Effects.Count; ++j)
                {
                    BasicEffect effect = (BasicEffect)mesh.Effects[j];
                 
                    effect.LightingEnabled = false;
                    
                    effect.View = Matrix.Identity;
                    effect.Projection = mMovieInstance.GetProjectionMatrix();
                    effect.World = xform * mTransform;

                }
                mesh.Draw();
            }
#else
                for (int i = 0; i < mData.VertexSets.Count; ++i)
                {
                    mMovieInstance.GeomBatch.AddVertexSet(mData.VertexSets[i], mTransform * xform, mCxform * cxform);
                }
#endif
            }
        }
    }
}
