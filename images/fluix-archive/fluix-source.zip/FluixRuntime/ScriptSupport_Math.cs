using System;
using System.Collections.Generic;
using System.Text;

namespace Fluix
{
    namespace Impl
    {
        public partial class ScriptSupport
        {
            public class Math : IScriptObject
            {
                public Dictionary<string, object> Variables = new Dictionary<string, object>();
                public Dictionary<string, object> GetVariables() { return Variables; }
                private Random mRandom = new Random(0xc0ffee);

                public bool SpecialSet(string key, object value) { return false; }
                public bool SpecialGet(string key, out object value) { value = null; return false; }

                // wrappers for, ahem, efficiency.
                public static object Abs(object def, object context, object o) { return System.Math.Abs(AsNumber(o)); }
                public static object Acos(object def, object context, object o) { return System.Math.Acos(AsNumber(o)); }
                public static object Asin(object def, object context, object o) { return System.Math.Asin(AsNumber(o)); }
                public static object Atan(object def, object context, object o) { return System.Math.Atan(AsNumber(o)); }
                public static object Atan2(object def, object context, object o, object p) { return System.Math.Atan2(AsNumber(o), AsNumber(p)); }
                public static object Ceiling(object def, object context, object o) { return System.Math.Ceiling(AsNumber(o)); }
                public static object Cos(object def, object context, object o) { return System.Math.Cos(AsNumber(o)); }
                public static object Exp(object def, object context, object o) { return System.Math.Exp(AsNumber(o)); }
                public static object Floor(object def, object context, object o) { return System.Math.Floor(AsNumber(o)); }
                public static object Ln(object def, object context, object o) { return System.Math.Log(AsNumber(o), System.Math.E); }
                public static object Max(object def, object context, object o, object p) { return System.Math.Max(AsNumber(o), AsNumber(p)); }
                public static object Min(object def, object context, object o, object p) { return System.Math.Min(AsNumber(o), AsNumber(p)); }
                public static object Pow(object def, object context, object o, object p) { return System.Math.Pow(AsNumber(o), AsNumber(p)); }
                public static object Random(Math def, object context)
                {
                    return def.mRandom.NextDouble();
                }
                public static object Round(object def, object context, object o) { return System.Math.Round(AsNumber(o)); }
                public static object Sin(object def, object context, object o) { return System.Math.Sin(AsNumber(o)); }
                public static object Sqrt(object def, object context, object o) { return System.Math.Sqrt(AsNumber(o)); }
                public static object Tan(object def, object context, object o) { return System.Math.Tan(AsNumber(o)); }

                public Math()
                {
                    Variables["E"] = System.Math.E;
                    Variables["LN10"] = System.Math.Log(10, System.Math.E);
                    Variables["LN2"] = System.Math.Log(2, System.Math.E);
                    Variables["LN10E"] = System.Math.Log10(System.Math.E);
                    Variables["LN2E"] = System.Math.Log(System.Math.E, 2.0);
                    Variables["PI"] = System.Math.PI;
                    Variables["SQRT1_2"] = System.Math.Sqrt(0.5);
                    Variables["SQRT2"] = System.Math.Sqrt(2);

                    Variables["abs"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Abs"), null);
                    Variables["acos"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Acos"), null);
                    Variables["asin"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Asin"), null);
                    Variables["atan"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Atan"), null);
                    Variables["atan2"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Atan2"), null);
                    Variables["ceil"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Ceiling"), null);
                    Variables["cos"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Cos"), null);
                    Variables["exp"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Exp"), null);
                    Variables["floor"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Floor"), null);
                    Variables["log"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Ln"), null);
                    Variables["max"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Max"), null);
                    Variables["min"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Min"), null);
                    Variables["pow"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Pow"), null);
                    Variables["random"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Random"), this);
                    Variables["round"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Round"), null);
                    Variables["sin"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Sin"), null);
                    Variables["sqrt"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Sqrt"), null);
                    Variables["tan"] = new FunctionAndEnvironment(typeof(Math).GetMethod("Tan"), null);
                }
            }
        }
    }
}
