using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;

namespace Fluix
{
    namespace Impl
    {
        [Serializable]
        public struct VertexPositionChunk
        {
            static public VertexElement[] VertexElements;
            public Vector2 Position;
            public Vector3 Chunk;

            public VertexPositionChunk(Vector2 pos)
            {
                Position = pos;
                Chunk = new Vector3(0, 0, 0);
            }

            static VertexPositionChunk()
            {
                VertexElement element = new VertexElement();
                VertexElement element2 = new VertexElement();

                VertexElements = new VertexElement[2];
                element.Stream = 0;
                element.Offset = 0;
                element.VertexElementFormat = VertexElementFormat.Vector2;
                element.VertexElementMethod = VertexElementMethod.Default;
                element.VertexElementUsage = VertexElementUsage.Position;
                element.UsageIndex = 0;
                VertexElements[0] = element;

                element2.Stream = 0;
                element2.Offset = 8;
                element2.VertexElementFormat = VertexElementFormat.Vector3;
                element2.VertexElementMethod = VertexElementMethod.Default;
                element2.VertexElementUsage = VertexElementUsage.Normal;
                element2.UsageIndex = 0;
                VertexElements[1] = element2;
            }

            public static int SizeInBytes = 20;
        }

        internal class GeometryBatch : IDisposable
        {
            GraphicsDevice mDevice;

            Effect mBatchEffect;

            EffectParameter mEffectParam_WorldViewProj;
            EffectParameter[] mEffectParam_Xforms;
            EffectParameter[] mEffectParam_Colours;
            EffectParameter[] mEffectParam_CxformMuls;
            EffectParameter[] mEffectParam_CxformAdds;
            EffectParameter[] mEffectParam_Textures;
            EffectParameter[] mEffectParam_TextureMatrices;

            Matrix[] mXforms;
            Vector4[] mColours;
            Vector4[] mCxformMuls;
            Vector4[] mCxformAdds;
            Texture2D[] mTextures;
            Matrix[] mTextureMatrices;

            VertexDeclaration mVertexDecl;
            VertexPositionChunk[] mVertices;
            VertexBuffer mVertexBuffer;

            List<int> mBatchesData;

            int mCurIndex;
            int mAllocatedChunks;
            int mVertexAddPoint;

            private bool disposed = false;

            const int CHUNKS_PER_BATCH = 8;


            private void ReallocChunkBuffers()
            {
                Array.Resize(ref mXforms, mAllocatedChunks);
                Array.Resize(ref mColours, mAllocatedChunks);
                Array.Resize(ref mCxformMuls, mAllocatedChunks);
                Array.Resize(ref mCxformAdds, mAllocatedChunks);
                Array.Resize(ref mTextures, mAllocatedChunks);
                Array.Resize(ref mTextureMatrices, mAllocatedChunks);
            }

            internal GeometryBatch(GraphicsDevice device, ContentManager content)
            {
                mDevice = device;

#if false
                mBatchEffect = content.Load<Effect>("FluixBatch");

#else
                mBatchEffect = new Effect(device, Effects.FluixBatchByteArray, CompilerOptions.None, null);
#endif
                mBatchEffect.CurrentTechnique = mBatchEffect.Techniques[0];

                mEffectParam_WorldViewProj = mBatchEffect.Parameters["WorldViewProj"];
                mEffectParam_Xforms = new EffectParameter[CHUNKS_PER_BATCH];
                mEffectParam_Colours = new EffectParameter[CHUNKS_PER_BATCH];
                mEffectParam_CxformMuls = new EffectParameter[CHUNKS_PER_BATCH];
                mEffectParam_CxformAdds = new EffectParameter[CHUNKS_PER_BATCH];
                mEffectParam_Textures = new EffectParameter[CHUNKS_PER_BATCH];
                mEffectParam_TextureMatrices = new EffectParameter[CHUNKS_PER_BATCH];
                for (int i = 0; i < CHUNKS_PER_BATCH; ++i)
                {
                    mEffectParam_Xforms[i] = mBatchEffect.Parameters["Xforms"].Elements[i];
                    mEffectParam_Colours[i] = mBatchEffect.Parameters["Colours"].Elements[i];
                    mEffectParam_CxformMuls[i] = mBatchEffect.Parameters["CxformMuls"].Elements[i];
                    mEffectParam_CxformAdds[i] = mBatchEffect.Parameters["CxformAdds"].Elements[i];
                    mEffectParam_Textures[i] = mBatchEffect.Parameters["Texture" + i];
                    mEffectParam_TextureMatrices[i] = mBatchEffect.Parameters["TextureMatrices"].Elements[i];
                }

                mVertexDecl = new VertexDeclaration(mDevice, VertexPositionChunk.VertexElements);

                mCurIndex = 0;
                mAllocatedChunks = 16;
                mVertexAddPoint = 0;

                ReallocChunkBuffers();

                mVertices = new VertexPositionChunk[10000];

                Matrix proj = Matrix.CreateOrthographicOffCenter(0, device.Viewport.Width, device.Viewport.Height, 0, 1000, -1000);
                mEffectParam_WorldViewProj.SetValue(proj);

                mBatchesData = new List<int>();
                mBatchesData.Add(0);
            }

            public void Dispose()
            {
                Dispose(true);
            }

            protected virtual void Dispose(bool dispose)
            {
                if (!this.disposed)
                {
                    if (dispose)
                    {
                        if (mVertexBuffer != null && !mVertexBuffer.IsDisposed)
                        {
                            mVertexBuffer.Dispose();
                        }
                    }
                    disposed = true;
                }
            }

            internal void Draw()
            {
                FinishBatch();

                if (mBatchesData.Count <= 1) return;

                if (mVertexBuffer == null || mVertexBuffer.IsDisposed || mVertexAddPoint > mVertexBuffer.SizeInBytes / VertexPositionChunk.SizeInBytes)
                {
                    if (mVertexBuffer != null && !mVertexBuffer.IsDisposed)
                    {
                        Debug.Assert(false, "not implemented yet (vertex overflow)");
                        mVertexBuffer.Dispose();
                    }
                    mVertexBuffer = new VertexBuffer(mDevice, typeof(VertexPositionChunk), mVertices.Length, ResourceUsage.Dynamic | ResourceUsage.WriteOnly, ResourceManagementMode.Manual);
                }
                mVertexBuffer.SetData<VertexPositionChunk>(mVertices, 0, mVertexAddPoint, SetDataOptions.NoOverwrite);

                for (int b = 0; b < mBatchesData.Count - 1; ++b)
                {
                    for (int i = b * CHUNKS_PER_BATCH; i < (b + 1) * CHUNKS_PER_BATCH; ++i)
                    {
                        mEffectParam_Xforms[i % CHUNKS_PER_BATCH].SetValue(mXforms[i]);
                        mEffectParam_Colours[i % CHUNKS_PER_BATCH].SetValue(mColours[i]);
                        mEffectParam_CxformMuls[i % CHUNKS_PER_BATCH].SetValue(mCxformMuls[i]);
                        mEffectParam_CxformAdds[i % CHUNKS_PER_BATCH].SetValue(mCxformAdds[i]);
                        mEffectParam_Textures[i % CHUNKS_PER_BATCH].SetValue(mTextures[i]);
                        mEffectParam_TextureMatrices[i % CHUNKS_PER_BATCH].SetValue(mTextureMatrices[i]);
                    }
                    mBatchEffect.CommitChanges();

                    mBatchEffect.Begin();
                    EffectPass pass = mBatchEffect.CurrentTechnique.Passes[0];
                    pass.Begin();
                    mDevice.VertexDeclaration = mVertexDecl;
                    mDevice.Vertices[0].SetSource(mVertexBuffer, 0, VertexPositionChunk.SizeInBytes);
                    mDevice.DrawPrimitives(PrimitiveType.TriangleList, mBatchesData[b], (mBatchesData[b + 1] - mBatchesData[b]) / 3);
                    pass.End();
                    mBatchEffect.End();
                }

                mVertexAddPoint = 0;
                mCurIndex = 0;
                mBatchesData.Clear();
                mBatchesData.Add(0);
            }

            private void FinishBatch()
            {
                if (mCurIndex > 0)
                {
                    mBatchesData.Add(mVertexAddPoint);
                }
            }

            private void AppendVertices(VertexPositionChunk[] vertices, Matrix xform, Vector3 chunk)
            {
                AppendVertices(vertices, xform, chunk, true);
            }

            private void AppendVertices(VertexPositionChunk[] vertices, Matrix xform, Vector3 chunk, bool fillFullChunk)
            {
                if (mCurIndex >= mAllocatedChunks)
                {
                    mAllocatedChunks *= 2;
                    ReallocChunkBuffers();
                }

                if (mCurIndex % CHUNKS_PER_BATCH == 0)
                {
                    FinishBatch();
                }

                while (vertices.Length + mVertexAddPoint >= mVertices.Length)
                {
                    Array.Resize(ref mVertices, mVertices.Length * 2);
                }
                Array.Copy(vertices, 0, mVertices, mVertexAddPoint, vertices.Length);
                mXforms[mCurIndex] = xform;
                if (fillFullChunk)
                {
                    for (int i = mVertexAddPoint; i < vertices.Length + mVertexAddPoint; ++i)
                    {
                        mVertices[i].Chunk = chunk;
                    }
                }
                else
                {
                    for (int i = mVertexAddPoint; i < vertices.Length + mVertexAddPoint; ++i)
                    {
                        mVertices[i].Chunk.Y = chunk.Y;
                    }
                }
                mVertexAddPoint += vertices.Length;
            }

            internal void AddVertices(VertexPositionChunk[] vertices, Matrix xform, Cxform cxform, Vector4 colour)
            {
                AppendVertices(vertices, xform, new Vector3(mCurIndex % CHUNKS_PER_BATCH, -1.0f, 1.0f));
                mColours[mCurIndex] = colour;
                mCxformMuls[mCurIndex] = cxform.mul;
                mCxformAdds[mCurIndex] = cxform.add;
                ++mCurIndex;
            }

            internal void AddVertices(VertexPositionChunk[] vertices, Matrix xform, Cxform cxform, Texture2D texture, Matrix textureMatrix, VertexSet.MaterialType matType)
            {
                AppendVertices(vertices, xform, new Vector3(mCurIndex % CHUNKS_PER_BATCH, matType == VertexSet.MaterialType.TextureClamped ? 1.0f : 0.0f, 1.0f));
                mCxformMuls[mCurIndex] = cxform.mul;
                mCxformAdds[mCurIndex] = cxform.add;
                mTextures[mCurIndex] = texture;
                mTextureMatrices[mCurIndex] = textureMatrix;
                ++mCurIndex;
            }

            internal void AddFontVertices(VertexPositionChunk[] vertices, Matrix xform, Cxform cxform, Texture2D texture)
            {
                AppendVertices(vertices, xform, new Vector3(0, -(mCurIndex % CHUNKS_PER_BATCH) - 2, 0), false);
                mCxformMuls[mCurIndex] = cxform.mul;
                mCxformAdds[mCurIndex] = cxform.add;
                mTextures[mCurIndex] = texture;
                mTextureMatrices[mCurIndex] = Matrix.Identity;
                ++mCurIndex;
            }

            internal void AddVertexSet(VertexSet vs, Matrix xform, Cxform cxform)
            {
                if ((vs.MatType & VertexSet.MaterialType.Color) == VertexSet.MaterialType.Color)
                {
                    AddVertices(vs.Vertices, xform, cxform, vs.Color);
                }
                else // todo; w/c
                {
                    AddVertices(vs.Vertices, xform, cxform, vs.Texture, vs.TextureMatrix, vs.MatType);
                    //vs.Texture.Save("c:\\desktop\\" + vs.TexID + ".png", ImageFileFormat.Png);
                 
                }
            }
        }
    }
}
