using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using System.Reflection;

namespace Fluix
{
    namespace Impl
    {
        internal class DisplayList
        {
            public Dictionary<int, CharacterInstance> Entries = new Dictionary<int, CharacterInstance>();
        }

        public class Font
        {
            public Texture2D Texture;
            public char MinChar;
            public char MaxChar;
            public Rectangle[] Rectangles;
            public Font(Texture2D tex, char min, char max, List<Rectangle> rects)
            {
                Texture = tex;
                MinChar = min;
                MaxChar = max;
                Rectangles = new Rectangle[rects.Count];
                rects.CopyTo(Rectangles);
            }
        }

        [Serializable]
        public abstract class ControlCommand
        {
            public abstract void Apply(CharacterSpriteInstance spriteInst);
        }

        [Serializable]
        public class ControlCommandRemove : ControlCommand
        {
            public int Depth;
            public ControlCommandRemove(int depth)
            {
                Depth = depth;
            }
            public override void Apply(CharacterSpriteInstance si)
            {
                CharacterInstance ci = si.DisplayList.Entries[Depth];
                if (ci is CharacterSpriteInstance)
                {
                    CharacterSpriteInstance csi = ci as CharacterSpriteInstance;
                    if (si.Variables.ContainsKey(csi.InstanceName))
                    {
                        si.Variables.Remove(csi.InstanceName);
                    }
                }
                si.DisplayList.Entries.Remove(Depth);
            }
        }

        [Serializable]
        public class ControlCommandPlace : ControlCommand
        {
            [Flags]
            public enum Has
            {
                Move = 0x01,
                Character = 0x02,
                Matrix = 0x04,
                ColorTransform = 0x08,
                Name = 0x20,
                ClipDepth = 0x40,
                ClipActions = 0x80
            }
            public Has HasData;

            public int Depth;
            public Matrix2D Matrix;
            public Cxform ColorMatrix;
            public string Name;
            public int ID;

            public ControlCommandPlace(int depth)
            {
                Depth = depth;
            }
            public override void Apply(CharacterSpriteInstance si)
            {
                if ((HasData & Has.Character) == Has.Character)
                {
                    CharacterInstance temp = si.MovieInstance.MakeInstanceOf(ID, si);
                    si.DisplayList.Entries[Depth] = temp;
                    if (temp is CharacterSpriteInstance)
                    {
                        CharacterSpriteInstance csi = temp as CharacterSpriteInstance;
                        if ((HasData & Has.Name) == Has.Name)
                        {
                            csi.InstanceName = Name;
                        }
                        else
                        {
                            csi.InstanceName = "instance" + si.MovieInstance.UnnamedInstanceCounter++;
                        }
                        si.Variables[csi.InstanceName] = temp;
                    }
                }
                CharacterInstance charInst = si.DisplayList.Entries[Depth];
                if ((HasData & Has.Matrix) == Has.Matrix)
                {
                    charInst.mTransform = new Matrix(
                        Matrix.m00, Matrix.m01, 0.0f, 0.0f,
                        Matrix.m10, Matrix.m11, 0.0f, 0.0f,
                        0.0f, 0.0f, 1.0f, 0.0f,
                        Matrix.tx / 20.0f, Matrix.ty / 20.0f, 0.0f, 1.0f);
                }
                if ((HasData & Has.ColorTransform) == Has.ColorTransform)
                {
                    charInst.mCxform = ColorMatrix;
                }
            }
        }
            
        [Serializable]
        public class ControlCommandAction : ControlCommand
        {
            [NonSerialized]
            public MethodInfo Method;
            public string MethodName;
            public ControlCommandAction(string name)
            {
                MethodName = name;
            }
            public override void Apply(CharacterSpriteInstance si)
            {
                if (Method != null)
                {
                    si.MovieInstance.QueueAction(si, Method);
                }
            }
        }

        [Serializable]
        public class Frame
        {
            public List<ControlCommand> Display = new List<ControlCommand>();
        }

        [Serializable]
        public class Character
        {
            public int ID;
            public Character(int id) { ID = id; }
        }

        [Serializable]
        public class CharacterButton : Character
        {
            public CharacterButton(int id) : base(id) { }
        }

        [Serializable]
        public class CharacterSprite : Character
        {
            public CharacterSprite(int id) : base(id) { }
            public List<Frame> Frames = new List<Frame>();
        }

        [Serializable]
        public class CharacterShape : Character
        {
            public CharacterShape(int id) : base(id) { }
            public List<VertexSet> VertexSets;
        }

        [Serializable]
        public class CharacterSound : Character
        {
            public CharacterSound(int id) : base(id) { }
        }

        [Serializable]
        public class CharacterText : Character
        {
            public enum Align
            {
                Left = 0,
                Right = 1,
                Centre = 2,
                Justify = 3
            }

            public int FontId;
            public string InitialText;
            public string Variable;
            public Rectangle Bounds;
            public bool WordWrap;
            public bool Multiline;
            public Vector4 Colour;
            public Align Alignment;
            [NonSerialized]
            public Font Font;

            public CharacterText(int id, int fontid, string initialText, string variable, Rectangle bounds, bool wordWrap, bool multiline, Vector4 colour, Align align)
                : base(id)
            {
                FontId = fontid;
                InitialText = initialText;
                Variable = variable;
                Bounds = bounds;
                WordWrap = wordWrap;
                Multiline = multiline;
                Colour = colour;
                Alignment = align;
            }
        }

        [Serializable]
        public class Matrix2D // todo; replace with regular Matrix
        {
            public float m00, m01, m10, m11;
            public float tx, ty;
        }

        [Serializable]
        public class TextureData
        {
            public int OrigWidth;
            public int OrigHeight;
            public TextureData(int ow, int oh)
            {
                OrigWidth = ow;
                OrigHeight = oh;
            }
        }

        [Serializable]
        public struct Cxform
        {
            public Vector4 mul;
            public Vector4 add;

            public Cxform(Vector4 m, Vector4 a)
            {
                mul = m;
                add = a;
            }

            private static Cxform _identity = new Cxform(new Vector4(1, 1, 1, 1), new Vector4(0, 0, 0, 0));
            public static Cxform Identity { get { return _identity; } }

            public static Cxform operator *(Cxform a, Cxform b)
            {
                return new Cxform(a.mul * b.mul, a.add + b.add);
            }
        }

        [Serializable]
        public class VertexSet
        {
            public VertexSet(Vector4 color)
            {
                MatType = MaterialType.Color;
                Color = color;
            }
            public VertexSet(int texID, Matrix textureMatrix, MaterialType wrapClamp)
            {
                Debug.Assert(wrapClamp == MaterialType.TextureClamped || wrapClamp == MaterialType.TextureWrapped);
                MatType = wrapClamp;
                TexID = texID;
                Texture = null;
                TextureMatrix = textureMatrix;
            }
            [Flags]
            public enum MaterialType
            {
                Color = 0x1,
                TextureWrapped = 0x2,
                TextureClamped = 0x4
            }
            public MaterialType MatType;
            public Vector4 Color;
            public int TexID;
            [NonSerialized]
            public Texture2D Texture;
            public Matrix TextureMatrix;
            public VertexPositionChunk[] Vertices;
        }
    }
}
