using System;
using System.Collections.Generic;
using System.Text;

namespace Fluix
{
    namespace Impl
    {
        public partial class ScriptSupport
        {
            public class String : IScriptObject
            {
                private string Value;
                public Dictionary<string, object> Variables = new Dictionary<string, object>();
                public Dictionary<string, object> GetVariables() { return Variables; }
                public bool SpecialSet(string key, object value) { return false; }
                public bool SpecialGet(string key, out object value)
                {
                    if (key == "length")
                    {
                        value = Value.Length;
                        return true;
                    }
                    value = null;
                    return false;
                }
                public override string ToString()
                {
                    return Value;
                }

                public static object CharAt(object def, object context, object index)
                {
                    String st = def as String;
                    return st.Value.Substring((int)ScriptSupport.AsNumber(index), 1);
                }

                public static object CharCodeAt(object def, object context, object index)
                {
                    String st = def as String;
                    return (double)(int)st.Value[(int)ScriptSupport.AsNumber(index)];
                }

                public static object Concat(object def, object context, object toAdd)
                {
                    String st = def as String;
                    return st.Value + toAdd.ToString();
                }

                public static object IndexOf(object def, object context, object value, object startAt)
                {
                    String st = def as String;
                    return (double)st.Value.IndexOf((string)value, (int)ScriptSupport.AsNumber(startAt));
                }

                public static object LastIndexOf(object def, object context, object value, object startAt)
                {
                    String st = def as String;
                    int start = st.Value.Length - 1;
                    if (!(startAt is Undefined)) start = (int)ScriptSupport.AsNumber(startAt);
                    return (double)st.Value.LastIndexOf(value as string, start);
                }

                public static object Slice(object def, object context, object start, object end)
                {
                    String st = def as String;
                    int sta = (int)ScriptSupport.AsNumber(start);
                    int len = (int)ScriptSupport.AsNumber(end) - sta;
                    return st.Value.Substring(sta, len);
                }

                public static object Split(object def, object context, object on)
                {
                    String st = def as String;
                    ScriptArray ret = new ScriptArray();
                    string[] split = st.Value.Split(new string[] { (string)on }, StringSplitOptions.None);
                    foreach (string s in split)
                    {
                        ret.Contents.Add(s);
                    }
                    return ret;
                }

                public static object Substr(object def, object context, object start, object length)
                {
                    String st = def as String;
                    int sta = (int)ScriptSupport.AsNumber(start);
                    int len = (int)ScriptSupport.AsNumber(length);
                    return st.Value.Substring(sta, len);
                }

                public static object Substring(object def, object context, object start, object end)
                {
                    String st = def as String;
                    int sta = (int)ScriptSupport.AsNumber(start);
                    int len = (int)ScriptSupport.AsNumber(end) - sta;
                    return st.Value.Substring(sta, len);
                }

                public static object ToLowerCase(object def, object context)
                {
                    String st = def as String;
                    return st.Value.ToLowerInvariant();
                }

                public static object ToUpperCase(object def, object context)
                {
                    String st = def as String;
                    return st.Value.ToUpperInvariant();
                }

                public static object FromCharCode(object def, object context, object val)
                {
                    int code = (int)ScriptSupport.AsNumber(val);
                    return "" + (char)code;
                }

                public String(object value)
                {
                    Value = value as string;

                    Variables["charAt"] = new FunctionAndEnvironment(typeof(String).GetMethod("CharAt"), this);
                    Variables["charCodeAt"] = new FunctionAndEnvironment(typeof(String).GetMethod("CharCodeAt"), this);
                    Variables["concat"] = new FunctionAndEnvironment(typeof(String).GetMethod("Concat"), this);
                    Variables["indexOf"] = new FunctionAndEnvironment(typeof(String).GetMethod("IndexOf"), this);
                    Variables["lastIndexOf"] = new FunctionAndEnvironment(typeof(String).GetMethod("LastIndexOf"), this);
                    Variables["slice"] = new FunctionAndEnvironment(typeof(String).GetMethod("Slice"), this);
                    Variables["slice"] = new FunctionAndEnvironment(typeof(String).GetMethod("Slice"), this);
                    Variables["split"] = new FunctionAndEnvironment(typeof(String).GetMethod("Split"), this);
                    Variables["substr"] = new FunctionAndEnvironment(typeof(String).GetMethod("Substr"), this);
                    Variables["substring"] = new FunctionAndEnvironment(typeof(String).GetMethod("Substring"), this);
                    Variables["toUpperCase"] = new FunctionAndEnvironment(typeof(String).GetMethod("ToUpperCase"), this);
                    Variables["toLowerCase"] = new FunctionAndEnvironment(typeof(String).GetMethod("ToLowerCase"), this);
                    
                    Variables["fromCharCode"] = new FunctionAndEnvironment(typeof(String).GetMethod("FromCharCode"), null);
                }
            }
        }
    }
}
