using System;
using System.Collections.Generic;
using System.Text;

namespace Fluix
{
    /// <summary>
    /// Represents a key press or release for the global "Key" Flash object.
    /// </summary>
    public struct KeyAction
    {
        /// <summary>
        /// Whether this is a press (true) or a release (false).
        /// </summary>
        public bool Pressed;

        /// <summary>
        /// The key code for the key being pressed or released. This key
        /// code should correspond to the Flash values. These are fairly typical values
        /// (corresponding to the VK_ #defines in the Win32 API).
        /// </summary>
        public int Code;

        /// <summary>
        /// Construct a new KeyAction.
        /// </summary>
        public KeyAction(bool pressed, int code)
        {
            Pressed = pressed;
            Code = code;
        }
    }

    /// <summary>
    /// The interface for an input handler. ReadData() is called frequently to update or
    /// poll the hardware state, and should queue KeyActions to an internal buffer. When it's
    /// time to process the next frame of Flash, Fluix will request the queued inputs by using
    /// GetQueuedInputs(). GetQueuedInputs should return all pending inputs, and clear the
    /// internal queue.
    /// </summary>
    public interface InputHandler
    {
        /// <summary>
        /// Should return all the KeyActions that have been queued since the 
        /// </summary>
        /// <returns></returns>
        List<KeyAction> GetQueuedInputs();
        void ReadData();
    }
}
