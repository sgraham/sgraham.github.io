using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Reflection;

namespace Fluix
{
    namespace Impl
    {
        public partial class ScriptSupport
        {
            public class Undefined
            {
                public override string ToString()
                {
                    return "undefined";
                }
            }
            public static Undefined undefined = new Undefined();

            public class ScriptArray : IScriptObject
            {
                public Dictionary<string, object> Variables = new Dictionary<string, object>();
                public Dictionary<string, object> GetVariables() { return Variables; }

                public List<object> Contents = new List<object>();

                public override string ToString()
                {
                    string ret = "";
                    for (int i = 0; i < Contents.Count - 1; ++i)
                    {
                        ret += Contents[i] + ",";
                    }
                    if (Contents.Count > 0) ret += Contents[Contents.Count - 1];
                    return ret;
                }

                public bool SpecialSet(string key, object value)
                {
                    if (key == "_listeners") return true;
                    return false;
                }

                public bool SpecialGet(string key, out object value)
                {
                    if (key == "length")
                    {
                        value = (double)Contents.Count;
                        return true;
                    }
                    value = null;
                    return false;
                }
            }

            public static object InitializeArray(__arglist)
            {
                ScriptArray ret = new ScriptArray();
                ArgIterator ai = new ArgIterator(__arglist);
                ret.Contents = new List<object>(ai.GetRemainingCount() - 1);
                while (ai.GetRemainingCount() > 1) // ignore count
                {
                    ret.Contents.Add( __refvalue(ai.GetNextArg(), object));
                }
                ret.Contents.Reverse();
                return ret;
            }


            public class Object : IScriptObject
            {
                public Dictionary<string, object> Variables = new Dictionary<string, object>();
                public Dictionary<string, object> GetVariables() { return Variables; }
                public override string ToString()
                {
                    return "[object Object]";
                }
                public bool SpecialSet(string key, object value) { return false; }
                public bool SpecialGet(string key, out object value) { value = null; return false; }
            }

            public static object InitializeObject(__arglist)
            {
                ArgIterator ai = new ArgIterator(__arglist);
                int count = ai.GetRemainingCount();
                object[] all = new object[count];
                for (int i = 0; i < count; ++i)
                {
                    all[i] = __refvalue( ai.GetNextArg(),object);
                }

                if (all[count - 2] is string && (string)all[count - 2] == "Object")
                {
                    return new Object();
                }
                else if (all[count - 2] is string && (string)all[count - 2] == "Sound")
                {
                    if (count != 3) throw new Exception("wasn't expecting arguments to Sound constructor");
                    return new Sound(((MovieInstance)all[count - 1]).GetSoundBank());
                }
                else if (all[count - 2] is string && (string)all[count - 2] == "String")
                {
                    if ((double)all[count - 3] == 0.0)
                    {
                        return new ScriptSupport.String("");
                    }
                    else
                    {
                        return new ScriptSupport.String((string)all[count - 4]);
                    }
                }
                throw new Exception("unhanded constructor type");
            }

            // todo; some sort of magic map that determines if it's supposed to have a "nice" tostring or empty... (undef, null, function don't)
            public static object Add(object a, object b)
            {
                if (!(a is string) && !(a is double) && !(a is ScriptArray))
                {
                    if (b is double) a = 0.0;
                    else a = "";
                }
                if (!(b is string) && !(b is double) && !(b is ScriptArray))
                {
                    if (a is double) b = 0.0;
                    else b = "";
                }
                if (a is ScriptArray) a = a.ToString();
                if (b is ScriptArray) b = b.ToString();
                if (a is string && b is string) return (string)a + (string)b;
                if (a is double && b is double) return (double)a + (double)b;
                if (a is string && b is double) return (string)a + (double)b;
                if (a is double && b is string) return (double)a + (string)b;
                throw new Exception("unhandled case in Add");
            }

            public static object And(object a, object b)
            {
                throw new Exception("todo;");
            }

            public static object Or(object a, object b)
            {
                throw new Exception("todo;");
            }

            public static object Not(object a)
            {
                if (a is bool)
                {
                    bool b = (bool)a;
                    return (object)!b;
                }
                else if (a is double)
                {
                    bool b = ((double)a) != 0.0;
                    return (object)!b;
                }
                throw new Exception("unhandled case in Not");
            }

            public static object LessThanTyped(object a, object b)
            {
                if (a is Undefined) a = 0.0;
                if (b is Undefined) b = 0.0;
                if (a is double && b is double)
                {
                    return ((double)a < (double)b);
                }
                if (a is string && b is string)
                {
                    return System.String.Compare((string)a, (string)b) < 0;
                }
                throw new Exception("unhandled case in LessThanTyped");
            }

            public static object EqualTyped(object b, object a)
            {
                if (a is Undefined && b is Undefined) return true;
                if (a is Undefined || b is Undefined) return false;
                if (a is double && b is double)
                {
                    return ((double)a == (double)b) ? 1.0 : 0.0;
                }
                if (a is string && b is string)
                {
                    return System.String.Compare((string)a, (string)b) == 0 ? 1.0 : 0.0;
                }
                throw new Exception("unhandled case in EqualTyped");
            }

            public static object GreaterThan(object a, object b)
            {
                if (a is double && b is double)
                {
                    return ((double)a > (double)b);
                }
                if (a is string && b is string)
                {
                    return System.String.Compare((string)a, (string)b) > 0;
                }
                throw new Exception("unhandled case in GreaterThan");
            }

            public static double AsNumber(object o)
            {
                if (o == null) return 0.0;
                if (o is double) return (double)o;
                if (o is Undefined) return 0.0;
                if (o is int) return (double)(int)o;
                if (o is bool) return (bool)o ? 1.0 : 0.0;
                if (o is string) return double.Parse((string)o);
                throw new Exception("can't convert to number");
            }

            public static object Subtract(object a, object b)
            {
                return AsNumber(a) - AsNumber(b);
            }

            public static object Multiply(object a, object b)
            {
                return AsNumber(a) * AsNumber(b);
            }

            public static object Divide(object a, object b)
            {
                double first = AsNumber(a);
                double second = AsNumber(b);
                if (second == 0.0) return undefined;
                return first / second;
            }

            public static object Modulo(object a, object b)
            {
                double first = AsNumber(a);
                double second = AsNumber(b);
                if (second == 0.0) return undefined;
                return first % second;
            }

            public static void SetVariable(object a, object b, IScriptObject context, Dictionary<string, object> locals)
            {
                if (a.GetType() != typeof(string)) throw new Exception("Expecting string as first parameter to SetVariable");
                string key = a as string;
                if (key.Contains("/")) throw new Exception("haven't handled pathed SetVariable yet");
                if (locals != null && locals.ContainsKey(key))
                {
                    locals[key] = b;
                }
                else
                {
                    context.GetVariables()[key] = b;
                }
            }

            public static void SetLocalVariable(object a, object b, CharacterSpriteInstance csi, Dictionary<string, object> locals)
            {
                if (a.GetType() != typeof(string)) throw new Exception("Expecting string as first parameter to SetVariable");
                string key = a as string;
                if (key.Contains("/")) throw new Exception("haven't handled pathed SetVariable yet");
                if (locals != null)
                {
                    locals[key] = b;
                }
                else
                {
                    csi.Variables[key] = b;
                }
            }

            public static object GetVariable(object a, object context, Dictionary<string, object> locals, Dictionary<string, FunctionAndEnvironment> localFunctions)
            {
                if (!(a is string)) return undefined;
                string key = a as string;
                if (key.Contains("/")) throw new Exception("haven't handled pathed GetVariable yet");
                if (locals != null && locals.ContainsKey(key))
                {
                    return locals[key];
                }
                if (localFunctions != null && localFunctions.ContainsKey(key))
                {
                    return localFunctions[key];
                }
                if (context is IScriptObject && ((IScriptObject)context).GetVariables().ContainsKey(key))
                {
                    return ((IScriptObject)context).GetVariables()[key];
                }
                if (context is CharacterSpriteInstance && ((CharacterSpriteInstance)context).Functions.ContainsKey(key))
                {
                    return ((CharacterSpriteInstance)context).Functions[key];
                }
                if (context is CharacterSpriteInstance && key == "_parent" && ((CharacterSpriteInstance)context).Parent != null)
                {
                    return ((CharacterSpriteInstance)context).Parent.ToString();
                }
                if (context is CharacterSpriteInstance && ((CharacterSpriteInstance)context).MovieInstance.mGlobals.GetVariables().ContainsKey(key))
                {
                    return ((CharacterSpriteInstance)context).MovieInstance.mGlobals.GetVariables()[key];
                }
                return undefined;
            }

            public static object GetMember(object so, object o)
            {
                if (o is double)
                {
                    if (!(so is ScriptArray)) throw new Exception("expecting ScriptArray for indexing");
                    ScriptArray sa = (ScriptArray)so;
                    int index = (int)(double)o;
                    if (index < 0 || index >= sa.Contents.Count) return undefined;
                    return sa.Contents[index];
                }
                else if (o is string)
                {
                    if (!(so is IScriptObject)) throw new Exception("expecting IScriptObject as second parameter to GetMember");
                    IScriptObject iso = so as IScriptObject;
                    string key = o as string;
                    object retval = null;
                    if (iso.SpecialGet(key, out retval))
                    {
                        return retval;
                    }
                    if (iso.GetVariables().ContainsKey(key))
                    {
                        return iso.GetVariables()[key];
                    }
                    return undefined;
                }
                throw new Exception("unhandled indexing type for GetMember");
            }

            public static object GetProperty(object so, object index, object context)
            {
                if (!(index is double)) throw new Exception("expecting number for property index");
                CharacterSpriteInstance csi;
                if (so is CharacterSpriteInstance)
                {
                    csi = so as CharacterSpriteInstance;
                }
                else if (so is string)
                {
                    if ((string)so == "")
                    {
                        csi = context as CharacterSpriteInstance;
                    }
                    else
                    {
                        csi = (context as IScriptObject).GetVariables()[(string)so] as CharacterSpriteInstance;
                    }
                }
                else
                {
                    throw new Exception("couldn't get target for property get");
                }

                PropertyIndex prop = (PropertyIndex)(int)(double)index;
                switch (prop)
                {
                    case PropertyIndex._name:
                        return csi.InstanceName;

                    default:
                        throw new Exception("unhandled property get");
                }
            }

            public static void SetMember(object so, object name, object val)
            {
                if (name.GetType() != typeof(string)) throw new Exception("Expecting string as second parameter to SetMember");
                if (!(so is IScriptObject)) throw new Exception("expecting IScriptObject as first parameter to SetMember");
                IScriptObject iso = so as IScriptObject;
                string key = name as string;
                if (!iso.SpecialSet(key, val))
                {
                    iso.GetVariables()[key] = val;
                }
            }

            public static void GetURL(CharacterSpriteInstance csi, object urlTarget, object targetString)
            {
                string surl = urlTarget.ToString();
                string starget = targetString.ToString();
                const string fscommandPrefix = "FSCommand:";
                if (surl.StartsWith(fscommandPrefix))
                {
                    csi.MovieInstance.SendFSCommand(surl.Substring(fscommandPrefix.Length), starget);
                }
                else
                {
                    Debug.WriteLine("Unrecognized GetURL: '" + surl + "', '" + starget + "'");
                }
            }

            public static void FunctionDefinitionHelper(CharacterSpriteInstance csi, Dictionary<string, FunctionAndEnvironment> localFunctions, string internalFunctionName, string inLanguageName)
            {
                FunctionDefinitionHelperExpr(csi, localFunctions, internalFunctionName, inLanguageName);
                // discard "return" value; not pushed onto stack
            }

            public static object FunctionDefinitionHelperExpr(CharacterSpriteInstance csi, Dictionary<string, FunctionAndEnvironment> localFunctions, string internalFunctionName, string inLanguageName)
            {
                System.Reflection.MethodInfo mi = csi.MovieInstance.FindMethodInfoByName(internalFunctionName);
                FunctionAndEnvironment fae = new FunctionAndEnvironment(mi, csi);
                if (inLanguageName != "")
                {
                    if (localFunctions != null)
                    {
                        localFunctions[inLanguageName] = fae;
                    }
                    else if (csi.Variables.ContainsKey(inLanguageName))
                    {
                        csi.Variables[inLanguageName] = fae;
                    }
                    else
                    {
                        csi.Functions[inLanguageName] = fae;
                    }
                }
                return fae;
            }

            public static object CallMethodTrampoline(__arglist)
            {
                ArgIterator ai = new ArgIterator(__arglist);
                int pushed = ai.GetRemainingCount() - 3; // 3 is count, context, function
                object[] args = new object[pushed + 2];
                for (int i = 0; i < pushed; ++i)
                {
                    args[pushed - i + 1] = __refvalue( ai.GetNextArg(),object);
                }
                object count = __refvalue( ai.GetNextArg(),object);
                Debug.Assert((int)(double)count == pushed);
                object context = __refvalue( ai.GetNextArg(),object);
                object funcName = __refvalue( ai.GetNextArg(),object);
                IScriptObject iso = context as IScriptObject;
                object func = iso.GetVariables()[(string)funcName];
                if (func is FunctionAndEnvironment)
                {
                    FunctionAndEnvironment fae = func as FunctionAndEnvironment;
                    args[0] = fae.Env;
                    args[1] = context;
                    int actualLength = fae.Func.GetParameters().Length;
                    if (args.Length == actualLength)
                    {
                        return fae.Func.Invoke(null, args);
                    }
                    else
                    {
                        object[] fixedArgs = new object[actualLength];
                        int i = 0;
                        for (; i < actualLength && i < args.Length; ++i)
                        {
                            fixedArgs[i] = args[i];
                        }
                        for (; i < actualLength; ++i)
                        {
                            fixedArgs[i] = undefined;
                        }
                        return fae.Func.Invoke(null, fixedArgs);
                    }
                }
                else
                {
                    return undefined;
                }
            }

            public static object CallFunctionTrampoline(__arglist)
            {
                ArgIterator ai = new ArgIterator(__arglist);
                int pushed = ai.GetRemainingCount() - 2; // 2 is count, function
                object[] args = new object[pushed + 2];
                for (int i = 0; i < pushed; ++i)
                {
                    args[pushed - i + 1] = __refvalue( ai.GetNextArg(),object);
                }
                object count = __refvalue( ai.GetNextArg(),object);
                Debug.Assert((int)(double)count == pushed);
                object func = __refvalue( ai.GetNextArg(),object);

                if (func is FunctionAndEnvironment)
                {
                    FunctionAndEnvironment fae = func as FunctionAndEnvironment;
                    args[0] = fae.Env;
                    args[1] = fae.Env; // 'this' is the same as where it was defined for functions (vs. methods)
                    MethodInfo mi = fae.Func;
                    int actualLength = mi.GetParameters().Length;
                    if (args.Length == actualLength)
                    {
                        return mi.Invoke(null, args);
                    }
                    else
                    {
                        object[] fixedArgs = new object[actualLength];
                        int i = 0;
                        for (; i < actualLength && i < args.Length; ++i)
                        {
                            fixedArgs[i] = args[i];
                        }
                        for (; i < actualLength; ++i)
                        {
                            fixedArgs[i] = undefined;
                        }
                        return mi.Invoke(null, fixedArgs);
                    }
                }
                else
                {
                    return undefined;
                }
            }

            public static void Trace(object o)
            {
                if (o is FunctionAndEnvironment)
                {
                    MethodInfo mi = (o as FunctionAndEnvironment).Func;
                    string noGuidName = mi.Name;
                    if (mi.Name.Length > 33)
                        noGuidName = mi.Name.Substring(0, mi.Name.Length - 33);
                    Debug.WriteLine("[type Function: '" + noGuidName + "']");
                }
                else
                {
                    Debug.WriteLine(o);
                }
            }
        }
    }
}
