using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Fluix
{
    namespace Impl
    {
        class CharacterTextInstance : CharacterInstance
        {
            CharacterText mData;
            MovieInstance mMovieInstance;
            string mCurText;
            VertexPositionChunk[] mVerts;
            Cxform mTextColourCxform;
            CharacterSpriteInstance mParent;

            struct LineData
            {
                public char[] Chars;
                public float TotalWidth;
                public LineData(char[] chars, float tw)
                {
                    Chars = chars;
                    TotalWidth = tw;
                }
                static public LineData MakeFor(string text, CharacterTextInstance cti)
                {
                    char[] chars = text.ToCharArray();
                    float w = 0.0f;
                    foreach (char c in chars)
                    {
                        w += cti.GetRect(c).Width;
                    }
                    return new LineData(chars, w);
                }
            }

            Rectangle GetRect(char srcc)
            {
                char c = (char)(srcc - mData.Font.MinChar);
                if (c < 0 || c >= mData.Font.Rectangles.Length)
                {
                    c = (char)0;
                }
                return mData.Font.Rectangles[c];
            }

            List<LineData> BreakIntoLines(string text, out int numLetters)
            {
                List<LineData> ret = new List<LineData>();
                numLetters = 0;
                if (mData.Multiline)
                {
                    char[] allchars = text.ToCharArray();
                    string line = "";
                    float remainingInLine = mData.Bounds.Right - mData.Bounds.Left;
                    for (int i = 0; i < allchars.Length; ++i)
                    {
                        if (allchars[i] == '\r')
                        {
                            ret.Add(LineData.MakeFor(line, this));
                            numLetters += line.Length;
                            line = "";
                            remainingInLine = mData.Bounds.Right - mData.Bounds.Left;
                        }
                        else
                        {
                            Rectangle r = GetRect(allchars[i]);
                            if (mData.WordWrap && r.Width > remainingInLine)
                            {
                                ret.Add(LineData.MakeFor(line, this));
                                numLetters += line.Length;
                                if (Char.IsWhiteSpace(allchars[i]))
                                {
                                    line = "";
                                    remainingInLine = mData.Bounds.Right - mData.Bounds.Left;
                                }
                                else
                                {
                                    line = allchars[i].ToString();
                                    remainingInLine = mData.Bounds.Right - mData.Bounds.Left - r.Width; // might be negative, but that means the textbox is too skinny; have to do something, so just put one per line
                                }
                            }
                            else
                            {
                                line += allchars[i];
                                remainingInLine -= r.Width;
                            }
                        }
                    }

                    ret.Add(LineData.MakeFor(line, this));
                    numLetters += line.Length;
                }
                else
                {
                    ret.Add(LineData.MakeFor(text, this));
                    numLetters += text.Length;
                }
                return ret;
            }

            void UpdateText(string s)
            {
                if (s != mCurText)
                {
                    mCurText = s;
                    float x;
                    float y = mData.Bounds.Top;
                    int numLetters;
                    List<LineData> lines = BreakIntoLines(mCurText, out numLetters);
                    mVerts = new VertexPositionChunk[numLetters * 6];

                    float wscale = 1.0f / mData.Font.Texture.Width;
                    float hscale = 1.0f / mData.Font.Texture.Height;
                    int count = 0;

                    foreach (LineData line in lines)
                    {
                        char[] chars = line.Chars;

                        CharacterText.Align align = mData.Alignment;
                        if (mData.Bounds.Right - mData.Bounds.Left < line.TotalWidth)
                        {
                            align = CharacterText.Align.Left;
                        }

                        if (align == CharacterText.Align.Left)
                        {
                            x = mData.Bounds.Left;
                        }
                        else if (align == CharacterText.Align.Right)
                        {
                            x = mData.Bounds.Right - line.TotalWidth;
                        }
                        else if (align == CharacterText.Align.Centre)
                        {
                            x = (mData.Bounds.Right - mData.Bounds.Left - line.TotalWidth) / 2.0f + mData.Bounds.Left;
                        }
                        else// if (align == CharacterText.Align.Justify)
                        {
                            throw new Exception("haven't implemented Justify alignment yet");
                        }

                        for (int i = 0; i < chars.Length; ++i)
                        {
                            Rectangle rect = GetRect(chars[i]);

                            VertexPositionChunk tl = new VertexPositionChunk(new Vector2(x, y));
                            tl.Chunk.X = rect.Left * wscale; tl.Chunk.Z = rect.Top * hscale;

                            VertexPositionChunk tr = new VertexPositionChunk(new Vector2(x + rect.Width, y));
                            tr.Chunk.X = rect.Right * wscale; tr.Chunk.Z = rect.Top * hscale;

                            VertexPositionChunk bl = new VertexPositionChunk(new Vector2(x, y + rect.Height));
                            bl.Chunk.X = rect.Left * wscale; bl.Chunk.Z = rect.Bottom * hscale;

                            VertexPositionChunk br = new VertexPositionChunk(new Vector2(x + rect.Width, y + rect.Height));
                            br.Chunk.X = rect.Right * wscale; br.Chunk.Z = rect.Bottom * hscale;


                            mVerts[count * 6 + 0] = tl;
                            mVerts[count * 6 + 1] = tr;
                            mVerts[count * 6 + 2] = br;
                            mVerts[count * 6 + 3] = tl;
                            mVerts[count * 6 + 4] = br;
                            mVerts[count * 6 + 5] = bl;
                            ++count;
                            x += rect.Width;
                        }

                        y += mData.Font.Rectangles[0].Height;
                    }
                }
            }

            internal CharacterTextInstance(CharacterText data, MovieInstance movieInst, CharacterSpriteInstance parent)
            {
                mData = data;
                mMovieInstance = movieInst;
                mParent = parent;
                UpdateText(data.InitialText);
                mTextColourCxform = new Cxform(mData.Colour, Vector4.Zero);
                GetVariableText();
            }

            void GetVariableText()
            {
                if (mParent.GetVariables().ContainsKey(mData.Variable))
                {
                    UpdateText(mParent.GetVariables()[mData.Variable].ToString());
                }
            }

            public override void Update(GameTime dt)
            {
                GetVariableText();
            }

            public override void Draw(Matrix xform, Cxform cxform)
            {
                mMovieInstance.GeomBatch.AddFontVertices(mVerts, mTransform * xform, mCxform * mTextColourCxform * cxform, mData.Font.Texture);
            }
        }
    }
}
