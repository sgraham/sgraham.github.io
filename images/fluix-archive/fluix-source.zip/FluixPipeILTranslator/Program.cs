using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Threading;
using System.Reflection;
using System.Reflection.Emit;
using Fluix;
using Fluix.Impl;
using FluixPipe;

namespace FluixPipeILTranslator
{
    class Program
    {
        static void Main(string[] args)
        {
            ILTranslator iltrans = new ILTranslator("temp", "FluixAS_type", "c:\\desktop\\temp.dll");
            XmlDocument doc = new XmlDocument();
            doc.Load("test.xml");
            XPathNavigator nav = doc.CreateNavigator();
            XPathNavigator actions = nav.SelectSingleNode("Tags/DoAction");
            iltrans.GenerateMethod(actions, "Actions/ACTIONRECORDARRAY", "testfunc");
            iltrans.Finish();

            byte[] ab = File.ReadAllBytes("temp.dll");
            Assembly a = Thread.GetDomain().Load(ab);
            CharacterSpriteInstance csi = new CharacterSpriteInstance(null);
            Module mod = a.GetModule("temp");
            Type cl = mod.GetType("FluixAS_type");
            MethodInfo met = cl.GetMethod("testfunc");
            object ret = met.Invoke(null, new object[] { csi });
        }
    }
}
