using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline.Serialization.Compiler;
using Fluix;
using FluixPipe;

namespace FluixPipe
{
    class Program
    {
        static void Main(string[] args)
        {
            SwfImport imp = new SwfImport();
            SwfProcessorImpl proc = new SwfProcessorImpl();
            SwfContentItem content = imp.Import(@"c:\\code\fluix\\tests\\test0.swf", null);
            SwfCompiled built = proc.Process(content, null);
        }
    }
}
