using System;
using System.Collections.Generic;
using System.Text;
using FluixPipe;

namespace FluixPipeFontGenTest
{
    class Program
    {
        static void Main(string[] args)
        {
            FontGenerator gen = new FontGenerator("Arial", 40, null);
            gen.Generate(' ', '~');
        }
    }
}
