using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline.Processors;
using Microsoft.Xna.Framework.Content.Pipeline.Serialization.Compiler;
using Fluix;
using Fluix.Impl;

namespace FluixPipe
{
    public class SoundBankData
    {
        public byte[] xgs;
        public byte[] xsb;
        public byte[] xwb;
        public SoundBankData(byte[] g, byte[] w, byte[] s)
        {
            xgs = g;
            xsb = s;
            xwb = w;
        }
    }

    public class SwfCompiled
    {
        public Color BackgroundColour;
        public int FrameRate;
        public int NumFrames;
        public Dictionary<int, Character> Characters = new Dictionary<int, Character>();
        public CharacterSprite Main;
        public Dictionary<int, TextureData> TextureData = new Dictionary<int, TextureData>();
        public string AssemblyTypeName;
        public byte[] CodeAssembly;
        public Dictionary<int, Texture2DContent> Textures = new Dictionary<int, Texture2DContent>();
        public Dictionary<int, string> Exports = new Dictionary<int, string>();
        public SoundBankData SoundData = null;
        public List<FontContent> Fonts = new List<FontContent>();
    }

    [ContentTypeWriter]
    class FluixMovieWriter : ContentTypeWriter<SwfCompiled>
    {
        protected override void Write(ContentWriter output, SwfCompiled value)
        {
            BinaryFormatter bf = new BinaryFormatter();
            output.Write(value.BackgroundColour.R);
            output.Write(value.BackgroundColour.G);
            output.Write(value.BackgroundColour.B);
            output.Write(value.BackgroundColour.A);
            output.Write(value.FrameRate);
            output.Write(value.NumFrames);
            bf.Serialize(output.BaseStream, value.Characters);
            bf.Serialize(output.BaseStream, value.Main);
            bf.Serialize(output.BaseStream, value.TextureData);
            bf.Serialize(output.BaseStream, value.Exports);
            if (value.CodeAssembly != null)
            {
                output.Write(value.CodeAssembly.Length);
                output.Write(value.AssemblyTypeName);
                output.Write(value.CodeAssembly);
            }
            else
            {
                output.Write((int)0);
            }
            output.Write(value.Textures.Count);
            foreach (KeyValuePair<int, Texture2DContent> kvp in value.Textures)
            {
                output.Write(kvp.Key);
                output.WriteObject(kvp.Value);
            }
            if (value.SoundData == null)
            {
                output.Write((int)0);
                output.Write((int)0);
                output.Write((int)0);
            }
            else
            {
                output.Write(value.SoundData.xgs.Length);
                output.Write(value.SoundData.xwb.Length);
                output.Write(value.SoundData.xsb.Length);
                output.Write(value.SoundData.xgs);
                output.Write(value.SoundData.xwb);
                output.Write(value.SoundData.xsb);
            }
            output.Write(value.Fonts.Count);
            foreach (FontContent fc in value.Fonts)
            {
                output.WriteObject(fc.Tex);
                output.Write(fc.MinChar);
                output.Write(fc.MaxChar);
                output.WriteObject(fc.Rectangles);
            }
        }

        public override string GetRuntimeReader(Microsoft.Xna.Framework.TargetPlatform targetPlatform)
        {
            return "Fluix.Impl.FluixMovieReader, FluixRuntime, Version=1.0.0.0, Culture=neutral";
        }
    }
}
