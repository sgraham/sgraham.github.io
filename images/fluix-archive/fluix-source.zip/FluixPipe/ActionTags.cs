namespace Fluix
{
    class Actions
    {
        // converted with a Vim macro (badly) from http://sswf.sourceforge.net/SWFalexref.html
        public enum Tag
        {
            End = 0x00,
            /*
            Operands: <i>&lt;n.a.&gt;</i>
            Data and op: End a record of actions
            Comments: 1
            */


            Next_Frame = 0x04,
            /*
            Operands: 0
            Data and op: <i>&lt;n.a.&gt;</i>
            Comments: Go to the next frame
            Version: 1
            */


            Previous_Frame = 0x05,
            /*
            Operands: 0
            Data and op: <i>&lt;n.a.&gt;</i>
            Comments: Go to the previous frame
            Version: 1
            */


            Play = 0x06,
            /*
            Operands: 0
            Data and op: <i>&lt;n.a.&gt;</i>
            Comments: Enter the standard (default) auto-loop playback
            Version: 1
            */


            Stop = 0x07,
            /*
            Operands: 0
            Data and op: <i>&lt;n.a.&gt;</i>
            Comments: Stop playing. Only a button (or the plugin menu) can be used to restart the movie
            Version: 1
            */


            Toggle_Quality = 0x08,
            /*
            Operands: 0
            Data and op: <i>&lt;n.a.&gt;</i>
            Change the quality level from low to high and vice versa. At this time, not sure what
            Comments: happens if you use medium!
            Version: 1
            */


            Stop_Sound = 0x09,
            /*
            Operands: 0
            Data and op: <i>&lt;n.a.&gt;</i>
            Comments: Stop playing any sound effect.
            Version: 2
            */


            Add = 0x0A,
            /*
            Operands: 0 (<i>n</i>)
            Data and op: <pre>operation: n2 <b>+</b> n1</pre>
            Comments: Pops two values, add them and put the result back on the stack.
            Version: 4 only
            */


            Subtract = 0x0B,
            /*
            Operands: 0 (<i>n</i>)
            Data and op: <pre>operation: n2 <b>-</b> n1</pre>
            Comments: Pops two values, subtract them and put the result back on the stack.
            Version: 4
            */


            Multiply = 0x0C,
            /*
            Operands: 0 (<i>n</i>)
            Data and op: <pre>operation: n2 <b>*</b> n1</pre>
            Comments: Pops two values, multiply them and put the result back on the stack.
            Version: 4
            */


            Divide = 0x0D,
            /*
            Operands: 0 (<i>f</i>)
            Data and op: <pre>operation: n2 <b>/</b> n1</pre>
            Comments: Pops two values, divide them and put the result back on the stack.
            Version: 4
            */


            Equal = 0x0E,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: n2 <b>==</b> n1</pre>
            Pops two values, compare them for equality and put the boolean result back on the stack.
                <p>The <code><b>!=</b></code> is created by adding a <a href="#action_logical_not"><b>Logical_Not</b></a>
                Comments: after the <b>Equal</b></p>
            Version: 4 only
            */


            Less_Than = 0x0F,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: n2 <b>&lt;</b> n1</pre>
            Pops two values, compare them for inequality and put the boolean result back on the stack.
                <p>Other comparison operators:</p>
                <ul>
                  <li><b>Less_Than_or_Equal</b> (n2 <b>&lt;=</b> n1)</li>
                </ul>
                <pre><a href="#action_swap"><b>Swap</b></a> + <b>Less Than</b> + <a href="#action_logical_not"><b>Logical_Not</b></a></pre>
                <ul>
                  <li><b>Greater_Than_or_Equal</b> (n2 <b>&gt;=</b> n1)</li>
                </ul>
                <pre><b>Less Than</b> + <a href="#action_logical_not"><b>Logical_Not</b></a></pre>
                <ul>
                  <li><b>Greater_Than</b> (n2 <b>&gt;</b> n1)</li>
                </ul>
                <pre><a href="#action_swap"><b>Swap</b></a> + <b>Less Than</b></pre>
                Comments: 
            Version: 4 only
            */


            Logical_And = 0x10,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: b2 <b>&amp;&amp;</b> b1</pre>
            Pops two values, compute the Logical AND and put the boolean result back on the stack.
            <p>
            Comments: Note: if b2 is a function call and b1 is false, then b2 is not called.</p>
            Version: 4
            */


            Logical_Or = 0x11,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: b2 <b>||</b> b1</pre>
            Pops two values, compute the Logical OR and put the boolean result back on the stack.
            <p>
            Comments: Note: if b2 is a function call and b1 is true, then b2 is not called.</p>
            Version: 4
            */


            Logical_Not = 0x12,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: <b>!</b> b1</pre>
            Comments: Pops one value, compute the Logical NOT and put the result back on the stack.
            Version: 4
            */


            String_Equal = 0x13,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: s2 <b>==</b> s1</pre>
            Comments: Pops two strings, compute the equality and put the boolean result back on the stack.
            Version: 4 only?
            */


            String_Length = 0x14,
            /*
            Operands: 0 (<i>n</i>)
            Data and op: <pre>operation: <b>strlen(</b>s1<b>)</b></pre>
            Comments: Pops two strings, compute the equality and put the boolean result back on the stack.
            Version: 4
            */


            SubString = 0x15,
            /*
            Operands: 0 (<i>s</i>)
            Data and op: <pre>operation: s3<b>[</b>i2 <b>..</b> i2 <b>+</b> i1 <b>-</b> 1<b>]</b></pre>
            Pops two values and one string, the first value is the new
                    string size (at most that many characters) and the second
                    value is the index (1 based) of the first character to start
                    the copy from. The resulting string is pushed back on the
                    Comments: stack.
            Version: 4
            */


            Pop = 0x17,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: a1</pre>
            Comments: Pops one value from the stack and forget it.
            Version: 4
            */


            Integral_Part = 0x18,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: <b>floor(</b>n1<b>)</b></pre>
            Comments: Pops one value, transform in an integer, and push the result back on the stack.
            Version: 4
            */


            Get_Variable = 0x1C,
            /*
            Operands: 0 (<i>a</i>)
            Data and op: <pre>operation: <b>GetVariable(</b>s1<b>)</b></pre>
            Pops one string, search for a variable of that name, and push its value on the stack.
            The variable name can include sprite names separated by slashes and finished by a colon as in:
            <pre>/Sprite1/Sprite2:MyVar</pre>
            This gets the variable named <code>MyVar</code> from the sprite named <code>Sprite2</code>
            which resides in <code>Sprite1</code>. Note that in a browser you can add variables
            at the end of the movie URL (as defined in the W3C docs) and these will automatically
            be accessible via the <b>GetVariable</b> instruction.
            <pre>my_movie?language=jp</pre>
            <p>
            Since Flash V5.x, there are
            <a href="#action_internal_functions">internal variables</a> available to you. These can
            Comments: be read with the <code>Get_Variable</code> instruction.</p>
            Version: 4
            */


            Set_Variable = 0x1D,
            /*
            Operands: 0
            Data and op: <pre>operation: s2 <b>=</b> v1</pre>
            Pops one value and one string, set the variable of that name with that value.
            Nothing is pushed back on the stack. The names can be full paths as defined in the
            Comments: <a href="#action_get_variable"><b>GetVariable</b></a> action.
            Version: 4
            */


            Set_Target_Dynamic = 0x20,
            /*
            Operands: 0
            Data and op: <pre>operation: <b>SetTarget(</b>s1<b>)</b></pre>
            Pops one string from the stack. If the string is the empty string, then
                    the next actions apply to the main movie. Otherwise it is the name of a
                    Comments: sprite and the followings actions apply to that sprite only.
            Version: 3
            */


            Concatenate_Strings = 0x21,
            /*
            Operands: 0 (<i>s</i>)
            Data and op: <pre>operation: s2 <b>&amp;</b> s1</pre>
            Comments: Pops two strings, concatenate them, push the result on the stack.
            Version: 4
            */


            Get_Property = 0x22,
            /*
            Operands: 0 (<i>a</i>)
            Data and op: <pre>operation: s2<b>.</b>n1</pre>
            Query the property 'n1' of the object named 's2' (a field in a structure
            if you wish), and push the result on the stack. See the table below for a list of possible
            Comments: <a href="#action_properties">properties (or fields)</a> values.
            Version: 4
            */


            Set_Property = 0x23,
            /*
            Operands: 0
            Data and op: <pre>operation: s3<b>.</b>n2 <b>=</b> a1</pre>
            Pop a value from the stack and use it to set the specified
            named object at the specified field property. See the table below for a list
            Comments: of possible <a href="#action_properties">properties (or fields)</a> values.
            Version: 4
            */


            Duplicate_Sprite = 0x24,
            /*
            Operands: 0
            Data and op: <pre>operation: s3 s2 i1 <b>Duplicate</b></pre>
            's3' is the name of a sprite which is copied. The new sprite
            has the name 's2' and is placed at depth 'i1'. The depth
            isn't used the same way in Flash 4 and Flash 5. The depth isn't clearly
            documented anywhere, but it looks like you need to have a depth of
            Comments: 16384 or more for a duplicated sprite to work properly.
            Version: 4
            */


            Remove_Sprite = 0x25,
            /*
            Operands: 0
            Data and op: <pre>operation: s1 <b>Remove</b></pre>
            Comments: Pop the string 's1' with the name of the sprite to be removed from view.
            Version: 4
            */


            Trace = 0x26,
            /*
            Operands: 0
            Data and op: <pre>operation: s1 <b>Trace</b></pre>
            Comments: Print out string s1 in debugger output window. Ignored otherwise.
            Version: 4
            */


            Start_Drag = 0x27,
            /*
            Operands: 0
            Data and op: <pre>operation: <i>[</i>n7 n6 n5 n4<i>]</i> b3 b2 s1 <b>StartDrag</b></pre>
            Pop a target name (s1), a first boolean (b2) &mdash; (un)lock the center of the object
            to the mouse pointer, a second boolean (b3) &mdash; constrained the mouse in the following rectangle
            (n4 to n7, representing y2, x2, y1, x1 &mdash; NOTE: the rectangle is not defined if (b3) is False).
            The object will follow the mouse until a <a href="#action_stop_drag">Stop_Drag</a> is
            Comments: applied or another object is defined as the object to be dragged.
            Version: 4
            */


            Stop_Drag = 0x28,
            /*
            Operands: 0
            Data and op: <pre>operation: <b>StopDrag</b></pre>
            Comments: Stop a drag operation.
            Version: 4
            */


            String_Less_Than = 0x29,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: s2 <b>&lt;</b> s1</pre>
            Comments: Pops two strings, compare them, push the result back on the stack.
            Version: 4 only?
            */


            Throw = 0x2A,
            /*
            Operands: 0 (<i>a</i>)
            Data and op: <pre>operation: <b>throw</b> a1</pre>
            This action pops one item and returns it as an exceptional result.
                    You can catch exceptions using the <a href="#action_try">Try</a>
                    Comments: action.
            Version: 7
            */


            Cast_Object = 0x2B,
            /*
            Operands: 0 (<i>o</i>)
            Data and op: <pre>operation: (s2) o1</pre>
            The <b>Cast_Object</b> action makes sure that the
                    object <b>o1</b> is an instance of the class <b>s2</b>.
                    If it is the case, then <b>o1</b> is pushed back onto
                    the stack. Otherwise <b>Null</b> is pushed back onto
                    the stack. The comparison is identical to the one
                    applied by the <a href="#action_instance_of">Instance_Of</a>
                    Comments: action.
            Version: 7
            */


            Implements = 0x2C,
            /*
            Operands: 0 (<i>o</i>)
            <pre>operation: o1 <b>implements</b> i2, o3, o4 ... o<i>n</i>
        Data and op: <small>(where <i>n is i2</i>)</small></pre>
            This action declares an object as a sub-class of one or
                    more interfaces. The syntax here is simple, the real
                    implementation is quite unbelivibly difficult to fathom.<br/>
                    <br/>
                    The following shows you how you can add an <b>implements</b>
                    of interfaces "A" and "B" to the class "C". Notice that
                    class "C" needs to already exist. Here we assume that all
                    classes are defined in the global scope.<br/>
                    <br/>
        <pre>	push data "_global"
            get variable
            push data "A"
            get member
            push data "_global"
            get variable
            push data "B"
            get member
            push data 2
            push data "_global"
            get variable
            push data "C"
            get member
            implements</pre>
                    Comments: 
            Version: 7
            */


            FSCommand2 = 0x2D,
            /*
            Operands: 0 (<i>a</i>)
            <pre>operation: <b>fscommand2</b> i1, s2, s3, s4 ... s<i>n</i>
        Data and op: <small>(where <i>n is i1</i>)</small></pre>
            NOTE: Ammar Mardawi sent a correction for this action
                    and it looks like it works the way it is described now.
                    <br/>
                    <br/>
                    Execute the named command (s2) passing on parameters
                    (s3, s4 ... s<i>n</i>.)
                    Comments: 
            Version: 7
            */


            Random = 0x30,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: <b>random(</b>n1<b>)</b></pre>
            Pops one number which is the maximum value (not included) that the
            <b>random()</b> function will return, push the generated value on the stack. 'n1'
            Comments: should not be zero.
            Version: 4
            */


            String_Length_MB = 0x31,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: <b>mbslen(</b>s1<b>)</b></pre>
            Comments: Pops one multi-byte string, push it's length in actual character on the stack.
            Version: 4
            */


            Ord_MB = 0x32,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: s1<b>[</b>0<b>]</b></pre>
            Comments: Pops one string, compute the ASCII value of its first character and put it back on the stack.
            Version: 4
            */


            Chr_MB = 0x33,
            /*
            Operands: 0 (<i>s</i>)
            Data and op: <pre>operation: i1</pre>
            Comments: Pops one integer, use it as a ASCII character and push the newly created string on the stack.
            Version: 4
            */


            Get_Timer = 0x34,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: <b>movie_time()</b></pre>
            Get the current movie timer in milliseconds and push it on the stack.
            Comments: This is equivalent to the number of frames which have been played so far.
            Version: 4
            */


            SubString_MB = 0x35,
            /*
            Operands: 0 (<i>s</i>)
            Data and op: <pre>operation: s3<b>[</b>i2 <b>..</b> i2 <b>+</b> i1 <b>-</b> 1<b>]</b></pre>
            Comments: Pops a multi-byte string, get i1 characters from the position i2 (1 based) and push the result back on the stack.
            Version: 4
            */


            Ord = 0x36,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: s1<b>[</b>0<b>]</b></pre>
            Comments: Pops one string, compute the multi-byte value of its first character and put it back on the stack.
            Version: 4
            */


            Chr = 0x37,
            /*
            Operands: 0 (<i>s</i>)
            Data and op: <pre>operation: i1</pre>
            Pops one integer, use it as a multi-byte string
            Comments: character and push the newly created string on the stack.
            Version: 4
            */


            Delete = 0x3A,
            /*
            Operands: 0 (<i>undefined</i>)
            Data and op: <pre>operation: <b>delete</b>(s1, o2)</pre>
            Pops one string which is the name of the property
            to be deleted. Then pop the object from which the property is to
            be deleted.
            <p>
            It is necessary to <b><a href="#action_push_data">Push_Data</a>
            type <i>undefined</i> (0x03)</b> before the string as in:
            </p>
            <pre>96 04 00 03 00 'a' 00 3A
        <b>delete("a");</b></pre>
            <p>
            to delete a global variable. According to some movies I have
            Comments: looked at, the delete instruction returns some undefined value.</p>
            Version: 5
            */


            Delete_All = 0x3B,
            /*
            Operands: 0
            Data and op: <pre>operation: <b>delete</b>(s1, o2)</pre>
            Pops one string which is the name of the thread
            Comments: which will get all of its variables deleted.
            Version: 5
            */


            Set_Local_Variable = 0x3C,
            /*
            Operands: 0
            Data and op: <pre>operation: s2 <b>=</b> a1</pre>
            Pops a value and a variable name. Create or set a local
            variable of that name with the (initial) value as specified. The same
            local variable can safely be set in this way multiple times. To only declare a
            local variable, use the
            <a href="#action_declare_local_variable">Declare_Local_Variable</a>
            Comments: instead.
            Version: 5
            */


            Call_Function = 0x3D,
            /*
            Operands: 0 (<i>a</i>)
            Data and op: <pre>operation: s1(i2, [a3, a4, a5...])</pre>
            Pops one string which is the name of the function to call, pop
            one integer which indicates the number of arguments following, pop each argument,
            call the named function, push the result of the function on the stack. There is
            always a result. The idea of the concept is that the function being called will
            use its own stack, however, that's not really the case. In other words, if a
            function stacks multiple results, they all are returned.
            <p>
            Flash V5.x offers a set of internal functions available to the end user via
            this <code>Call Function</code> instruction. Please, see the table below
            for a complete list of these
            Comments: <a href="#action_internal_functions">internal functions</a>.</p>
            Version: 5
            */


            Return = 0x3E,
            /*
            Operands: 0 (<i>a</i>)
            Data and op: <pre>operation: <b>return</b> a1</pre>
            Pops one object and return it to the caller. The result is stacked on the caller
            Comments: stack, not the stack of the function being executed.
            Version: 5
            */


            Modulo = 0x3F,
            /*
            Operands: 0 (<i>i</i>)
            <pre>operation: i2 <b>%</b> i1
                   or
               Data and op: f2 % f1</pre>
            Comments: Pops two numbers, computes the modulo and push the result back on the stack.
            Version: 5
            */


            New = 0x40,
            /*
            Operands: 0 (<i>o</i>)
            <pre>operation: o = <b>new</b> s1
                   Data and op: o<b>.</b>s1<b>(</b>i2, [a3, a4, a5 ...]<b>)</b></pre>
            Pop the class name for the new object to create.
                    Pop the number of arguments. Pop each argument.
                    Create an object of class <b>s1</b>. Call the
                    constructor function (which has the same name
                    as the object class: <b>s1</b>).
                    The result of the constructor is discarded.
                    Push the created object on the stack.
                    The object should then be saved in a variable
                    Comments: or object method.
            Version: 5
            */


            Declare_Local_Variable = 0x41,
            /*
            Operands: 0
            Data and op: <pre>operation: s1</pre>
            Pops a variable name and marks it as a local variable. If the
            variable doesn't exist yet, then its value is undefined. To declare and set a
            local variable, use the <a href="#action_set_local_variable">Set_Local_Variable</a>
            Comments: instead.
            Version: 5
            */


            Declare_Array = 0x42,
            /*
            Operands: 0 (t)
            <pre>operation: <b>new</b> array<b>[</b>i1<b>]</b>
        array<b>[</b>0<b>] =</b> a2
        array<b>[</b>1<b>] =</b> a3
        ...
        array<b>[</b>i1 <b>-</b> 1<b>] =</b> a<i>n</i>
        Data and op: <small>(where <i>n = i1 + 1</i>)</small></pre>
            Pops the number of elements in the array. Pop one value per
                    element and set the corresponding entry in the array. The array is pushed
                    Comments: on the stack. It can later be sent to a function or set in a variable.
            Version: 5
            */


            Declare_Object = 0x43,
            /*
            Operands: 0 (o)
            <pre>operation: <b>new</b> Object
        count <b>=</b> i1
        object<b>.</b>a3 <b>=</b> a2
        object<b>.</b>a5 <b>=</b> a4
        ...
        object<b>.</b>a<i>n</i> <b>=</b> a<i>m</i>
        Data and op: <small>(where <i>n = i1 * 2 + 1</i> and <i>m = i1 * 2</i>)</small></pre>
            Pops the number of members in the object. Pop one value and one name per
                    member and set the corresponding member in the object. The resulting object
                    is pushed on the stack. It can later be sent to a function or set in a
                    variable.
                    <p>
                    Note: the member names are converted to strings; they certainly should
                    Comments: be strings thought <i>anything</i> is supported.</p>
            Version: 5
            */


            Type_Of = 0x44,
            /*
            Operands: 0 (<i>s</i>)
            Data and op: <pre>operation: <b>typeof(</b>a1<b>)</b></pre>
            Pops some data, define its type and push the name of its type back on the stack.
            The currently supported types are as follow:
            <pre>number
        boolean
        string
        object
        movieclip
        null
        undefined
        Comments: function</pre>
            Version: 5
            */


            Get_Target = 0x45,
            /*
            Operands: 0 (<i>s</i>)
            Data and op: <pre>operation: <b>target_of(</b>o1<b>)</b></pre>
            Pops an object, if it is a valid sprite, push it's path on the stack.
                    A sprite path can be used by different other actions such as the
                    Comments: <a href="#action_goto_expression">Goto Expression</a>.
            Version: 5
            */


            Enumerate = 0x46,
            /*
            Operands: 0 (<i>v</i>)
            Data and op: <pre>operation: s1</pre>
            Pop the name of a thread (can it only be the root?) and push all
                    of its children (objects &amp; variables) back on the stack. The
                    Comments: list is null terminated.
            Version: 5
            */


            Add_Typed = 0x47,
            /*
            Operands: 0<br/>(<i>a</i>)
            <pre>operation: i2 <b>+</b> i1
               <i>or</i>
               f2 <b>+</b> f1
               <i>or</i>
               Data and op: s2 <b>+</b> s1</pre>
            Pops two numbers or two strings, computes the sum or concatenation
                    Comments: and push the result back on the stack.
            Version: 5
            */


            Less_Than_Typed = 0x48,
            /*
            Operands: 0 (<i>b</i>)
            <pre>operation: i2 <b>&lt;</b> i1
               <i>or</i>
               f2 <b>&lt;</b> f1
               <i>or</i>
               Data and op: s2 <b>&lt;</b> s1</pre>
            Pops two integers or two strings, computes whether they are ordered
                    Comments: from smaller to larger and push the result back on the stack.
            Version: 5
            */


            Equal_Typed = 0x49,
            /*
            Operands: 0 (<i>b</i>)
            <pre>operation: i2 <b>==</b> i1
                <i>or</i> f2 <b>==</b> f1
                Data and op: <i>or</i> s2 <b>==</b> s1</pre>
            Pops two integers, floats or strings, computes whether they are equal
                    and push the result back on the stack. If a mix of types is found, then
                    convertions occur. Strings may be transformed in numbers and numbers in
                    Comments: strings as with the untyped <a href="#action_equal">Equal</a> operator.
            Version: 5
            */


            Number = 0x4A,
            /*
            Operands: 0 (<i>n</i>)
            Data and op: <pre>operation: a1<b>.valueOf()</b></pre>
            Pops one item and transform it into a number. For strings it works as
                    expected (see the strtof(3C) manual pages). For a user defined object,
                    Comments: the method named <code>valueOf()</code> is called.
            Version: 5
            */


            String = 0x4B,
            /*
            Operands: 0 (<i>n</i>)
            Data and op: <pre>operation: a1<b>.toString()</b></pre>
            Pops one item and transform it into a string. For numbers it works as
                    expected (see the sprintf(3C) manual pages). For a user defined object,
                    Comments: the method named <code>toString()</code> is called.
            Version: 5
            */


            Duplicate = 0x4C,
            /*
            Operands: 0 (<i>a1 a1</i>)
            Data and op: <pre>operation: a1</pre>
            Comments: Pops one item and push it back twice.
            Version: 5
            */


            Swap = 0x4D,
            /*
            Operands: 0<br/>(<i>a1 a2</i>)
            Data and op: <pre>operation: a2 &lt;-&gt; a1</pre>
            Comments: Pops two items and push them back the other way around.
            Version: 5
            */


            Get_Member = 0x4E,
            /*
            Operands: 0 (<i>a</i>)
            Data and op: <pre>operation: o2<b>[</b>a1<b>]</b></pre>
            Pops one string or an integer (member name), pop an object reference,
                    Comments: defines the value of that object member and push the result back on the stack.
            Version: 5
            */


            Set_Member = 0x4F,
            /*
            Operands: 0
            Data and op: <pre>operation: o3<b>[</b>a2<b>]</b> <b>=</b> a1</pre>
            Pops a value 'a1' which will be the new member value, then one string
                    or integer 'a2' (the name of the member to modified or create),
                    and finally pop an object reference 'o3'. If the member doesn't
                    exists yet, create it. Finally, sets the object member to the
                    Comments: value 'a1'.
            Version: 5
            */


            Increment = 0x50,
            /*
            Operands: 0 (<i>n</i>)
            Data and op: <pre>operation: n1 <b>+</b> 1</pre>
            Comments: Pops one number, add 1 to it and push it back on the stack.
            Version: 5
            */


            Decrement = 0x51,
            /*
            Operands: 0 (<i>n</i>)
            Data and op: <pre>operation: n1 <b>-</b> 1</pre>
            Comments: Pops one number, substract 1 to it and push it back on the stack.
            Version: 5
            */


            Call_Method = 0x52,
            /*
            Operands: 0 (<i>a</i>)
            <pre>operation: o2<b>.</b>s1<b>(</b>i3<b>,</b> <i>[</i>a4<b>,</b> a5<b>,</b> a6<i>...]</i><b>)</b>
        <i>or</i>
        Data and op: o2<b>(</b>i3<b>,</b> <i>[</i>a4<b>,</b> a5<b>,</b> a6<i>...]</i><b>)</b></pre>
            Pops the name of a method (can be the empty string), pop an object, pop the number
                    of arguments, pop each argument, call the method (function) of the object, push
                    Comments: the returned value on the stack.
            Version: 5
            */


            New_Method = 0x53,
            /*
            Operands: 0 (<i>o</i>)
            <pre>operation: o = <b>new</b> s2
                   o<b>.</b>s1<b>(</b>i3<b>,</b> <i>[</i>a4<b>,</b> a5<b>,</b> a6<i>...]</i><b>)</b>
                   <i>or</i>
                   Data and op: o<b>.</b>s2<b>(</b>i3<b>,</b> <i>[</i>a4<b>,</b> a5<b>,</b> a6<i>...]</i><b>)</b></pre>
            Pops the name of a method (can be the empty string), pop an object (created with
                    the <a href="#action_declare_object">Declare_Object</a>,)
                    pop the number of arguments, pop each argument, create a new object, then call
                    the specified method (function) as the constructor function of the object, push
                    Comments: the returned value on the stack. This allows for overloaded constructors as in C++.
            Version: 5
            */


            Instance_Of = 0x54,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: o2 <b>is_instance_of</b> s1</pre>
            Pops the name of a constructor (<b>s1</b> - ie. <i>"Color"</i>) then
                    the name of an object (<b>s2</b>). Checks whether the named object is
                    part of the class defined by the constructor. If so, then true
                    is push on the stack, otherwise false.
                    <p>
                    Since SWF version 7, it is possible to cast an object to
                    another using the <a href="#action_cast_object">Cast_Object</a>
                    action. This action returns a copy of the object or <b>Null</b>,
                    Comments: which in many cases can be much more practical.</p>
            Version: 6
            */


            Enumerate_Object = 0x55,
            /*
            Operands: 0 (<i>v</i>)
            Data and op: <pre>operation: o1</pre>
            Pops an object from the stack, push a null, then push the
                    Comments: name of each member on the stack.
            Version: 6
            */


            And = 0x60,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: i2 <b>&amp;</b> i1</pre>
            Comments: Pops two integers, computes the bitwise AND and push the result back on the stack.
            Version: 5
            */


            Or = 0x61,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: i2 <b>|</b> i1</pre>
            Comments: Pops two integers, computes the bitwise OR and push the result back on the stack.
            Version: 5
            */


            XOr = 0x62,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: i2 <b>^</b> i1</pre>
            Pops two integers, computes the bitwise XOR and push the result back on the stack.
                    <p>
                    Comments: This operator is also used to generate a bitwise NOT with an immediate value of -1.</p>
            Version: 5
            */


            Shift_Left = 0x63,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: i2 <b>&lt;&lt;</b> i1</pre>
            Pops two integers, shift the 2nd one by the number of bits specified by the first integer
                    Comments: and push the result back on the stack.
            Version: 5
            */


            Shift_Right = 0x64,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: i2 <b>&gt;&gt;</b> i1</pre>
            Pops two integers, shift the 2nd signed integer by the number of bits specified by
                    Comments: the first integer and push the result back on the stack.
            Version: 5
            */


            Shift_Right_Unsigned = 0x65,
            /*
            Operands: 0 (<i>i</i>)
            Data and op: <pre>operation: i2 <b>&gt;&gt;&gt;</b> i1</pre>
            Pops two integers, shift the 2nd unsigned integer by the number of bits specified by
                    Comments: the first integer and push the result back on the stack.
            Version: 5
            */


            Strict_Equal = 0x66,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: a1 === a2</pre>
            Pops two parameters and return whether they are strictly
                    equal. No cast is applied to either s1 or s2. Thus two
                    items of different type are not equal (<code>0 == "0"</code>
                    Comments: is true, but <code>0 === "0"</code> is false.)
            Version: 6
            */


            Greater_Than = 0x67,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: a2 &gt; a1</pre>
            Similar to <i>Swap + Less Than</i>. It checks whether the second
                    parameter is greater than the first and return the boolean
                    Comments: result on the stack.
            Version: 6
            */


            String_Greater_Than = 0x68,
            /*
            Operands: 0 (<i>b</i>)
            Data and op: <pre>operation: s2 &gt; s1</pre>
            Similar to <i>Swap + String Less Than</i>. It checks whether the second
                    string is greater than the first and return the boolean
                    Comments: result on the stack.
            Version: 6
            */


            Extends = 0x69,
            /*
            Operands: 0 (<i>o</i>)
            <pre>operation: super_class = s1
        sub_class = s2
        sub_class.prototype = <b>new</b> object
        sub_class.prototype.__proto__ = super_class.prototype;
        Data and op: sub_class.prototype.__constructor__ = super_class;</pre>
            The <b>Extends</b> action will be used to define a new object
                    which extends another object. The declaration in ActionScript
                    is: <pre>class A extends B;</pre>
                    In an SWF action script, you don't exactly declare objects,
                    you actually instantiate them and define their functions.
                    This action creates a new object named <b>s2</b> which is
                    an extension of the object <b>s1</b>.
                    <p>
                    Use this action whenever you need to inherit an object
                    Comments: without calling its constructor.</p>
            Version: 7
            */


            Goto_Frame = 0x81,
            /*
            Operands: 2
            Data and op: <pre>unsigned short	f_frame_no;</pre>
            Comments: The playback continues at the specified frame
            Version: 1
            */


            Get_URL = 0x83,
            /*
            Operands: <i>variable</i>
            <pre>string	f_url;
        Data and op: string	f_target;</pre>
            Load the specified URL in the specified target window.
            <p>
            When the target is set as <b>"_level0"</b>, the current SWF file is replaced
            by the file specified in the <code>f_url</code> field. The name in the
            <code>f_url</code> field should be a proper SWF file or the area will
            simply become black.
            </p>
            <p>
            When the target is set as <b>"_level1"</b>, something
            special is supposed to happen. I still don't know what it is...
            <br/>
            <small>Also the effect of _level1 + an empty URL is ... (to remove
            level1?)</small>
            </p>
            <p>The URL can be a javascript command when the protocol
            is set to "javascript:". For instance, you can call your function
            as follow: "javascript:MyFunction(5)". If you want to use dynamic
            values, you will need to concatenate strings and use
            <a href="#action_get_url2">Get URL2</a> instead.
            </p>
            <p>
            The target can also be set to the regular HTML names such as
            <b>"_top"</b> or a frame name.
            </p>
            Comments: 
            Version: 1
            */


            Store_Register = 0x87,
            /*
            Operands: 1 (a)
            <pre>unsigned char	f_register;
        Data and op: operation: regs<b>[</b>f_register<b>] =</b> a1</pre>
	
              <p>
              Pop one value from the stack, push it back on the stack
              and also store it in one of four or 256 registers which
              number is specified in the tag (0, 1, 2 or 3 only if
              not in a
              <a href="#action_declare_function2">Declare_Function_(V7)</a>.
              I tried other numbers and they don't work in SWF version 6 or older.)
              Until set a register has the value <i>undefined</i>. The value
              of a register can be retrieved with a
              <a href="#action_push_data">Push_Data</a> action
              and the register type with the matching register
              number.
              </p>
              <p>
              (To be tested) It is likely that trying to read a register
              which is not legal in a <b>Declare_Function_(V7)</b>
              will generate an exception (Yes! A <a href="#throw">Throw</a>!)
              but I wouldn't be surprised if you just get <i>undefined</i>.
              </p>
            Comments: 
            Version: 5
            */


            Declare_Dictionary = 0x88,
            /*
            Operands: <i>variable</i><br/>(s)
            <pre>unsigned short	f_count;
        Data and op: string		f_dictionary[<i>f_count</i>];</pre>
            Declare an array of strings which can later be retrieved
            using the <a href="#action_push_data">Push_Data</a> action with a
            dictionary lookup. There can be a maximum of 65534 strings. The visibility of
            a dictionary is within its <a class="tagname" href="#tag_doaction">DoAction</a> or other
            Comments: similar block of actions.
            Version: 5
            */


            Strict_Mode = 0x89,
            /*
            Operands: 1
            Data and op: <pre>unsigned char	f_strict;</pre>
            Set the strict mode (f_strict != 0) or reset the
            Comments: strict mode (f_strict == 0).
            Version: 5
            */


            Wait_For_Frame = 0x8A,
            /*
            Operands: 3
            <pre>unsigned short	f_frame;
        Data and op: unsigned char	f_skip;</pre>
            Wait until the frame specified in <i>f_frame</i> is
            fully loaded to execute actions right after this one. Otherwise skip
            the specified number of actions. This is usually used with a
            <a href="#action_goto_frame">Goto_Frame</a> like in:<pre>
        Next Frame
        Wait for Frame #10
          (otherwise skip 1 action)
        Goto Frame #5
        Play
        End
        </pre> This will usually be used to display some <i><u>Loading...</u></i> info
        Comments: before the complete movie is loaded.
            Version: 1
            */


            Set_Target = 0x8B,
            /*
            Operands: <i>variable</i>
            Data and op: <pre>string	f_target;</pre>
            If the string <i>f_target</i> is the empty string, then
                    the next actions apply to the main movie. Otherwise it is the name of a
                    Comments: sprite and the followings actions apply to that sprite only.
            Version: 1
            */


            Goto_Label = 0x8C,
            /*
            Operands: <i>variable</i>
            Data and op: <pre>string	f_label;</pre>
            Go to a named frame. Frames are given names with the use of the
            Comments: <a class="tagname" href="#tag_framelabel">FrameLabel</a> tag.
            Version: 3
            */


            Wait_For_Frame_Dynamic = 0x8D,
            /*
            Operands: <i>1</i>
            <pre>unsigned char	f_skip;
        Data and op: operation: a1 <b>WaitForFrame</b></pre>
            Pop a value or a string used as the frame
            number to wait for. The frame can be specified as with the
            <a href="#action_goto_expression"><b>Goto Expression</b></a>. If the
            Comments: frame was not reached yet, skip the following <i>f_skip</i> actions
            Version: 4
            */


            Declare_Function_V7 = 0x8E,
            /*
            Operands: <i>variable</i>
            <pre>string		f_name;
        unsigned short	f_arg_count;
        unsigned char	f_reg_count;
        unsigned short	f_declare_function2_reserved : 7;
        unsigned short	f_preload_global : 1;
        unsigned short	f_preload_parent : 1;
        unsigned short	f_preload_root : 1;
        unsigned short	f_suppress_super : 1;
        unsigned short	f_preload_super : 1;
        unsigned short	f_suppress_arguments : 1;
        unsigned short	f_preload_arguments : 1;
        unsigned short	f_suppress_this : 1;
        unsigned short	f_preload_this : 1;
        <a href="#swf_params">swf_params</a>	f_params[<i>f_arg_count</i>];
        unsigned short	f_function_length;</pre>
            <p><font color="red">WARNING: the preload/suppress flags are defined
            on a short and thus the bytes in a Flash file will look swapped.</font></p>
            Data and op: 
	
            Declare a function which can later be called with the
            <a href="#action_call_function">Call_Function</a>
            action or
            <a href="#action_call_method">Call_Method</a> action
            (when defined as a function member.) The
            <i>f_function_length</i> defines the number of bytes that the function
            declaration uses after the header (i.e. the size of the actions defined
            in the function). All the actions included in this block are part of
            the function body.
            <p><i>Do not terminate a function with an End action</i></p>
            <p>
            A function should terminate with a <a href="#action_return">Return</a>
            action. The value used by the return statement will be the only value
            left on the caller stack.
            </p>
            <p>
            Functions declared with this action code byte also support the use
            of up to 255 local registers (registers 0 to 254 since the
            f_reg_count byte specifies the last register which can be
            used plus one). To access the local registers, use the
            <a href="#action_push_data">Push Data</a> action with a load register
            and to change a register value use the
            <a href="#action_store_register">Store_Register</a> action.
            </p>
            <p>
            Also, it is possible to control the preloading or suppressing of
            the different internal variables: <b>this</b>, <b>arguments</b>,
            <b>super</b>, <b>_root</b>, <b>_parent</b> and <b>_global</b>.
            All the function arguments can also be ignored. If you write a
            compiler, you should preload only the variables which are used
            in the function body. And you should suppress all the variables
            which are never being accessed in the function body [WARNING: note
            that it is possible to concatenate two strings such as "th" and
            "is" to generate the name "this" and then do a 'get that variable'.
            This means a function can't really know whether any of the internal
            variables are really never going to be used... but who writes code
            like that, really?!]. If you are writing a smart player, then you
            may want to avoid creating the variables until they are actually
            being used (thus when an if() statement ends the function prematurly,
            you may end up not creating many of these variables!).
            </p>
            <p>
            The preloading bits indicate in which register to load the given
            internal variable. The suppressing bits indicate which internal
            variable not to create at all. That is, if the preloading bit is
            not set and the suppressing is not set, then the internal variable
            are supposed to be created by name (i.e. you can access a variable
            named "this" from within the function when bits 0 and 1 are zero).
            </p>
            <p>
            The <i>f_reg_count</i> parameter needs to be specified and it tells
            the player the largest register number in use in this function.
            This way it can allocate up to 255 registers on entry. By default,
            these registers are initialized as <i>undefined</i>. The variables
            automatically loaded in registers are loaded starting at register 1.
            The internal variables are loaded in this order: <b>this</b>,
            <b>arguments</b>, <b>super</b>, <b>_root</b>, <b>_parent</b> and
            <b>_global</b>. Thus, if you call a function which
            accepts three user parameters and wants <b>this</b> and <b>_parent</b>,
            it will load <b>this</b> in register 1, <b>_parent</b> in register
            2 and the user parameters can be loaded in registers 3, 4 and 5.
            User parameters are loaded in registers only if their corresponding
            f_param_register field is not zero (see
            <a href="#swf_params">swf_params</a>). Also, they don't need to be
            defined in order.
            </p>
            <p>
            Note that system variables are loaded AFTER arguments. This means
            if you put an argument in register 3 and this register is also used
            for <b>_root</b>, then within the function the register 3 will be
            equal to the content of <b>_root</b>. Compilers should never do that
            though.
            </p>
            Comments: 
            Version: 7
            */


            Try = 0x8F,
            /*
            Operands: <i>variable</i>
            <pre>unsigned char	f_try_reserved : 5;
        unsigned char	f_catch_in_register : 1;
        unsigned char	f_finally : 1;
        unsigned char	f_catch : 1;
        unsigned short	f_try_size;
        unsigned short	f_catch_size;
        unsigned short	f_finally_size;
        if(f_catch_in_register == 0) {
            string		f_catch_name;
        }
        else {
            unsigned char	f_catch_register;
        Data and op: }</pre>
	
            Declare a try/catch/finally block.
            <p>
            This has the behavior of the action script:
            </p>
            <pre>	try { ... }
            catch(name) { ... }
            finally { ... }</pre>
            <p>
            At this time, there is no definition of exception in the action
            scripts. But you can write a function which
            <a href="#action_throw">Throw</a>s.
            </p>
            <p>
            The sementic of the try/catch/finally block is very well defined
            in <a href="ecma262-3.pdf">ECMA 262 version 3</a> (see pages 87/88).
            </p>
            <p>
            The <b>f_finally</b> and <b>f_catch</b> may not both be null or
            the sementic of the try block would be wrong. The <b>f_try_size</b>,
            <b>f_catch_size</b> and <b>f_finally_size</b> are defined in bytes
            and give the size of each of the block of instructions just like
            a function definition.
            </p>
            <p><i>Do not terminate these blocks with an End action</i></p>
            <p>
            If the <b>f_catch_in_register</b> is set to 1, then a register
            number is specified instead of a variable name. This will usually
            be faster.
            </p>
            Comments: 
            Version: 7
            */


            With = 0x94,
            /*
            Operands: 0
            <pre>unsigned short	f_size;
        Data and op: operation: <b>with</b> o1</pre>
            The variable references within the following <i>f_size</i> bytes
            are taken as names of members of the specified object 'o1'. When no member is
            available in that object, the previous <b>With</b>, or the corresponding global
            variable is queried.
            This is similar to the <i>Pascal</i> language <b>with</b> instruction or a
            <a href="#action_set_target">Set Target</a> (<a href="#action_set_target_dynamic">dynamic</a>).
            Note that the number of <b>With</b> within other <b>With</b> is limited to 7 in version 5
            and 15 since version 6 (note that the official documentation says 8 and 16, but it seems that
            is wrong.) Additional <b>With</b> blocks are ignored.
            The size defines up to where the <b>With</b> has an effect (the <i>f_size</i> is taken
            as a branchment offset except that it is always positive). Note that it is to the
            Comments: creator of the action scripts to ensure the proper nesting of each <b>With</b>.
            Version: 5
            */


            Push_Data = 0x96,
            /*
            Operands: <i>variable</i>
            <pre>struct {
            unsigned char	f_type;
            ...		f_data;
        } f_push_data[<i>&lt;variable&gt;</i>];
        </pre>
            Data and op: 
            Push some immediate data on the stack.
            This action was introduced in V4.0. The supported data types
            vary depending on the version of player that you have. As many
            values as necessary can be pushed at once. The <i>f_push_data</i>
            structure will be repeated multiple times as required. For
            instance, to push two strings on the stack at once, you would
            use the following code:
            <pre>96
        0C 00
        00 't' 'e' 's' 't' 00
        00 'm' 'o' 'r' 'e' 00</pre>
            <p>
            <small>Please, see the
            <a href="#action_pushdata_types">table of data types</a>
            Comments: below for more information.</small></p>
            Version: <i>variable</i>
            */


            Branch_Always = 0x99,
            /*
            Operands: 2
            Data and op: <pre>signed short	f_offset;<a href="#branch_offset"><sup>*</sup></a></pre>
            Comments: Jump to the specified instruction.
            Version: 4
            */

            Get_URL2 = 0x9A,
            /*
            Operands: 1
            <pre>unsigned char	f_method;
        Data and op: operation: s1 s2</pre>
	
            <p>Pop two strings, the URL (s2) and the target name (s1).</p>
            <p>All the usual HTML target names seem to be supported (_top,
            _blank, <i>&lt;frame name&gt;</i>, etc.) You can also use
            the special internal names _level0 to _level10. _level0 is
            the current movie. Other levels, I'm still not too sure how
            these can be used.</p>
            <p>Use
            <i>f_method</i> to tell Flash how to handle the variables (see
            table below).
            The variables of the current SWF context can be forwarded
            to the destination page using GET or POST (this means you can
            create dynamic forms with full HTML conformance).
            </p>
            <p>It seems that in V4.x (or would it be in V6.x?!? &mdash;
            it doesn't seem
            to work in V5.x) you could use URL2 to read a text file (with
            a .txt extension) with a list of variables using something like this:</p>
            <p>Push URL "myvars.txt", Target "_level0"; Get URL2;</p>
            <p>The syntax of the file myvars.txt is lines which are defined
            as a variable name followed by an equal sign and the contents
            for that variable. If contents of a single variable is more than
            one line, start the following line(s) with an ampersand to
            continue that one variable.</p>
            <p>The URL can also start with "javascript:" in which case
            the given browser javascript language receives a call.</p>
            <table border="2" cellpadding="2" cellspacing="2">

              <tr>Version:  = <tr>1,
              Comments: <tr>Version: 2
            </tbody></table> = 
            */


            Declare_Function = 0x9B,
            /*
            Operands: <i>variable</i>
            <pre>string		f_name;
        unsigned short	f_arg_count;
        string		f_arg_name[<i>f_arg_count</i>];
        Data and op: unsigned short	f_function_length;</pre>
            Declare a function which can later be called with the
            <a href="#action_callfunction">Call_Function</a> action. The
            <i>f_function_length</i> defines the number of bytes that the function
            declaration takes. All the actions included in this block are part of the function.
            A function should terminate with a <a href="#action_return">Return</a>
            action. The value used by the return statement should be the only value
            left on the caller stack.
            <p><i>Do not terminate a function with an End action</i></p>
            <p>Prior version 6, the <i>Macromedia</i> player
            would keep all the data pushed in a function as is when the function
            returned whether there is a return statement or not.</p>
            <p>Since version 7, it is preferable to use the new type of functions:
            Comments: <a href="#action_declare_function2">Declare_Function_(V7)</a>.</p>
            Version: 5
            */


            Branch_If_True = 0x9D,
            /*
            Operands: 2
            <pre>signed short	f_offset;<a href="#branch_offset"><sup>*</sup></a>
        Data and op: operation: b1</pre>
            Pop a boolean value; if true then jump to the specified instruction; otherwise
            Comments: continue with the following instructions.
            Version: 4
            */


            Call_Frame = 0x9E,
            /*
            Operands: 0
            <pre><i>nothing</i>
        <small>(this is a bug known by Macromedia)</small>
        Data and op: operation: s1</pre>
            Pop a string or integer and <i>call</i> the corresponding frame.
                This means: (1) search the corresponding frame, (2) execute its
                actions and (3) continue with the action defined after this one.
                The frame can be identified with a name or a number. It is also
                possible to specify a target movie ("&lt;sprite name&gt;.&lt;frame name&gt;?
                Comments: - to be tested...)
            Version: 4
            */


            Goto_Expression = 0x9F,
            /*
            Operands: 2
            <pre>unsigned char	f_play;
        Data and op: operation: a1</pre>
             Pop a value or a string and jump to the specified frame.
             When a string is specified, it can include a path to a sprite as in:
             <pre>/Test:55</pre>
             When <i>f_play</i> is ON (1), the action is to play as soon as that frame is
             Comments: reached. Otherwise, the frame is shown in stop mode.
             Version: 4
             */
        }

    }
}