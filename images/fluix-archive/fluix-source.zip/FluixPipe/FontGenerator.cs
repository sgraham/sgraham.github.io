using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;
using Fluix;

using GdiColor = System.Drawing.Color;
using XnaColor = Microsoft.Xna.Framework.Graphics.Color;
using GdiRectangle = System.Drawing.Rectangle;
using XnaRectangle = Microsoft.Xna.Framework.Rectangle;

namespace FluixPipe
{
    [ContentProcessor(DisplayName = "Texture (Font in Alpha Channel) - Fluix (Internal)")]
    internal class FontTextureProcessorFluix : ContentProcessor<TextureContent, TextureContent>
    {
        public override TextureContent Process(TextureContent input, ContentProcessorContext context)
        {
            input.ConvertBitmapType(typeof(PixelBitmapContent<XnaColor>));
            PixelBitmapContent<XnaColor> bits = (PixelBitmapContent<XnaColor>)input.Faces[0][0];
            for (int y = 0; y < bits.Height; ++y)
            {
                for (int x = 0; x < bits.Width; ++x)
                {
                    XnaColor c = bits.GetPixel(x, y);
                    bits.SetPixel(x, y, new XnaColor(255, 255, 255, c.R));
                }
            }
            return input;
        }
    }

    public class FontContent
    {
        public TextureContent Tex;
        public char MinChar;
        public char MaxChar;
        public List<XnaRectangle> Rectangles;
        public FontContent(Bitmap bm, char min, char max, string tempname, List<XnaRectangle> rects, ContentProcessorContext ctx)
        {
            // insanely, this is the fastest way to get at the data without using unsafe code (bitmap.GetPixel is REAAAAAAAAAAALLY slow)
            bm.Save(tempname, ImageFormat.Png);
            Tex = ctx.BuildAndLoadAsset<TextureContent, TextureContent>(new ExternalReference<TextureContent>(tempname), "FontTextureProcessorFluix");
            MinChar = min;
            MaxChar = max;
            Rectangles = rects;
        }
    }

    public class FontGenerator
    {
        Graphics mGraphics;
        Bitmap mBitmap;
        string mName;
        int mHeight;
        Font mFont;
        StringFormat mFormat;
        SolidBrush mBrush;
        ContentProcessorContext mContext;

        public FontGenerator(string name, int height, ContentProcessorContext ctx)
        {
            mName = name;
            mHeight = height;
            mContext = ctx;
            CreateBitmap(1, 1);

            mFont = new Font(name, height * 72.0f / 96.0f, FontStyle.Regular);

            mFormat = new StringFormat(StringFormat.GenericTypographic);
            mFormat.Alignment = StringAlignment.Near;
            mFormat.LineAlignment = StringAlignment.Near;
            mFormat.FormatFlags = StringFormatFlags.MeasureTrailingSpaces;
            mFormat.SetMeasurableCharacterRanges(new CharacterRange[] { new CharacterRange(0, 1) });

            mBrush = new SolidBrush(GdiColor.White);
        }

        void CreateBitmap(int width, int height)
        {
            if (mGraphics != null) mGraphics.Dispose();
            if (mBitmap != null) mBitmap.Dispose();

            mBitmap = new Bitmap(width, height, PixelFormat.Format32bppRgb);
            mGraphics = Graphics.FromImage(mBitmap);
            mGraphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
        }

        public Bitmap Rasterize(char ch)
        {
            string text = ch.ToString();

            Region[] regs = mGraphics.MeasureCharacterRanges(text, mFont, new RectangleF(0.0f, 0.0f, 1024f, 1024f), mFormat);

            int width = (int)Math.Ceiling(regs[0].GetBounds(mGraphics).Right - regs[0].GetBounds(mGraphics).Left);
            int height = (int)Math.Ceiling(regs[0].GetBounds(mGraphics).Bottom - regs[0].GetBounds(mGraphics).Top);

            // If it is bigger than our current output bitmap,
            // allocate a larger bitmap.
            if ((width > mBitmap.Width) || (height > mBitmap.Height))
            {
                CreateBitmap(width, height);
            }

            mGraphics.Clear(GdiColor.Black);
            mGraphics.DrawString(text, mFont, mBrush, 0, 0, mFormat);
            mGraphics.Flush();

            Bitmap ret = mBitmap.Clone(new GdiRectangle(0, 0, width, height), PixelFormat.Format32bppRgb);
            return ret;
        }

        class TempGlyph
        {
            public char Index;
            public Bitmap Data;
            public int X;
            public int Y;
            public TempGlyph(char index, Bitmap data)
            {
                Index = index;
                Data = data;
                X = 0;
                Y = 0;
            }
        }

        bool PlaceGlyph(List<TempGlyph> glyphs, int w, int h, TempGlyph tg, ref int x, ref int y)
        {
            if (x + tg.Data.Width > w)
            {
                x = 0;
                y += tg.Data.Height + 1;
            }
            if (y + tg.Data.Height > h) return false;
            tg.X = x;
            tg.Y = y;
            x += tg.Data.Width + 1;
            return true;
        }

        List<TempGlyph> AttemptLayout(int w, int h, List<TempGlyph> src)
        {
            int x = 0;
            int y = 0;
            List<TempGlyph> ret = new List<TempGlyph>();
            foreach (TempGlyph tg in src)
            {
                if (!PlaceGlyph(ret, w, h, tg, ref x, ref y)) return null;
                ret.Add(tg);
            }
            return ret;
        }

        void Layout(Dictionary<char, Bitmap> bitmaps, out Bitmap bm, out List<XnaRectangle> rects)
        {
            List<TempGlyph> list = new List<TempGlyph>();
            foreach (KeyValuePair<char, Bitmap> kvp in bitmaps) list.Add(new TempGlyph(kvp.Key, kvp.Value));

            List<XnaRectangle> rectangles = new List<XnaRectangle>();

            for (int dim = 64; ; dim *= 2)
            {
                for (int targetH = dim; targetH <= dim * 3; targetH *= 2)
                {
                    List<TempGlyph> result = AttemptLayout(dim, targetH, list);
                    if (result != null)
                    {
                        Bitmap ret = new Bitmap(dim, targetH, PixelFormat.Format32bppArgb);
                        Graphics retGraphics = Graphics.FromImage(ret);
                        foreach (TempGlyph g in result)
                        {
                            retGraphics.DrawImage(g.Data, g.X, g.Y);
                            rectangles.Add(new XnaRectangle(g.X, g.Y, g.Data.Width, g.Data.Height));
                        }
                        bm = ret;
                        rects = rectangles;
                        return;
                    }
                }
            }
        }

        public FontContent Generate(char min, char max)
        {
            Dictionary<char, Bitmap> bitmaps = new Dictionary<char, Bitmap>();
            for (char c = min; c <= max; ++c)
            {
                bitmaps[c] = Rasterize(c);
            }

            Bitmap result;
            List<XnaRectangle> rects;
            Layout(bitmaps, out result, out rects);
            
            return new FontContent(result, min, max, Path.GetTempPath() + mName + "_" + mHeight + ".png", rects, mContext);
        }
    }
}
