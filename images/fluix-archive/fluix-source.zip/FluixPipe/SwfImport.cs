using System;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Reflection;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline.Serialization.Compiler;

namespace FluixPipe
{
    public class SwfContentItem
    {
        public XPathNavigator Tags;
        public string ExtractedAssetDir;
        public string BaseName;
        public string OrigFileName;
        public SwfContentItem(XPathNavigator tags, string basename, string dir, string origFilename)
        {
            Tags = tags;
            ExtractedAssetDir = dir;
            BaseName = basename;
            OrigFileName = origFilename;
        }
    }

    [ContentImporterAttribute(".swf", DisplayName="SWF - Fluix")]
    public class SwfImport : ContentImporter<SwfContentItem>
    {
        public override SwfContentItem Import(string filename, ContentImporterContext context)
        {
            string basename = Path.GetFileNameWithoutExtension(filename);
            string tmp = Path.GetTempPath();
            if (!tmp.EndsWith("\\")) tmp += "\\";
            string outpath = tmp + basename + "_extracted";
            string errorfn = outpath + "\\errors.txt";
            if (Directory.Exists(outpath))
            {
                Directory.Delete(outpath, true);
            }
            Directory.CreateDirectory(outpath);
            //System.Windows.Forms.MessageBox.Show(codeBase + "\\FluixExtract.exe");
#if true
            Process p = Process.Start("wperl", "c:\\code\\fluix\\extract.pl \"" + filename + "\" \"" + outpath + "\"");
#else
            string codeBase = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase).Substring(6);
            Process p = Process.Start(codeBase + "\\FluixExtract.exe", " \"" + filename + "\" \"" + outpath + "\"");
#endif
            p.WaitForExit();

            if (File.Exists(errorfn))
            {
                string[] errors = File.ReadAllLines(errorfn);
                foreach (string error in errors)
                {
                    throw new InvalidContentException("Error: " + error + ": If you would like this problem fixed, please send a simple .fla demonstrating the bug to fluix@googlegroups.com");
                }
                return null;
            }

            XmlDocument doc = new XmlDocument();
            doc.Load(outpath + "\\tags.xml");
            SwfContentItem ret = new SwfContentItem(doc.CreateNavigator(), basename, outpath, filename);
            return ret;
        }
    }
}
