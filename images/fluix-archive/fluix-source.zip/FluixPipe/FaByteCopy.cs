using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Serialization;
using Microsoft.Xna.Framework.Content.Pipeline.Serialization.Compiler;

//
// this is a dumb hack to get the generated assembly to the output directory since there's
// currently no way exposed in the content pipeline.
//
namespace FluixPipe
{
    public class FaByteCopyContentItem
    {
        public byte[] Bytes;
        public FaByteCopyContentItem(byte[] bytes) { Bytes = bytes; }
    }

    public class FaByteCopyCompiled
    {
        public byte[] Bytes;
        public FaByteCopyCompiled(byte[] bytes) { Bytes = bytes; }
    }

    [ContentImporterAttribute(".fa", DisplayName = "SWF - Assembly (Internal)")]
    public class FaByteCopyImport : ContentImporter<FaByteCopyContentItem>
    {
        public override FaByteCopyContentItem Import(string filename, ContentImporterContext context)
        {
            return new FaByteCopyContentItem(File.ReadAllBytes(filename));
        }
    }

    [ContentProcessor(DisplayName = "SWF - Fluix")]
    public class FaByteCopyProcessor : ContentProcessor<FaByteCopyContentItem, FaByteCopyCompiled>
    {
        public override FaByteCopyCompiled Process(FaByteCopyContentItem input, ContentProcessorContext context)
        {
            return new FaByteCopyCompiled(input.Bytes);
        }
    }

    [ContentTypeWriter]
    class FaByteCopyWriter : ContentTypeWriter<FaByteCopyCompiled>
    {
        protected override void Write(ContentWriter output, FaByteCopyCompiled value)
        {
            output.WriteExternalReference(new ExternalReference<FaByteCopyCompiled>("c:\\this_is_not_the_root_directory.xnb"));
            output.Write(value.Bytes);
        }

        public override string GetRuntimeReader(Microsoft.Xna.Framework.TargetPlatform targetPlatform)
        {
            return "Not loadable by content pipeline";
        }
    }
}
