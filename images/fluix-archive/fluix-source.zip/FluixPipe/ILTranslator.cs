using System;
using System.Collections.Generic;
using System.Threading;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Reflection;
using System.Reflection.Emit;
using Fluix;
using Fluix.Impl;
using System.IO;
using Microsoft.Xna.Framework.Content.Pipeline;

namespace FluixPipe
{
    public class ILTranslator
    {
        private string mAssemblyFileFullPath;
        private AssemblyName mAssemblyName;
        private AssemblyBuilder mAssembly;
        private ModuleBuilder mModule;
        private TypeBuilder mTypeBuilder;
        private bool mGeneratedSomeMethods;

        public ILTranslator(string assemblyName, string typeName, string assemblyFileFullPath)
        {
            mAssemblyFileFullPath = assemblyFileFullPath;

            mAssemblyName = new AssemblyName();
            mAssemblyName.Name = assemblyName;

            mAssembly = Thread.GetDomain().DefineDynamicAssembly(mAssemblyName, AssemblyBuilderAccess.RunAndSave);//, Path.GetDirectoryName(mAssemblyFileFullPath));

            mModule = mAssembly.DefineDynamicModule(mAssemblyName.Name, Path.GetFileName(assemblyFileFullPath), false);

            mTypeBuilder = mModule.DefineType(typeName, TypeAttributes.Public);

            mGeneratedSomeMethods = false;
        }

        public bool Finish()
        {
            if (mGeneratedSomeMethods)
            {
                mTypeBuilder.CreateType();
                mAssembly.Save(Path.GetFileName(mAssemblyFileFullPath));
            }
            return mGeneratedSomeMethods;
        }

        Actions.Tag GetTag(XPathNavigator nav)
        {
            XPathNavigator tag = nav.SelectSingleNode("Tag");
            return (Actions.Tag)int.Parse(tag.InnerXml);
        }

        Type ScanForReturnType(XPathNavigator ops, string endOfFunctionLabel)
        {
            for (; ; )
            {
                XPathNavigator endOfFuncNode = ops.SelectSingleNode("LocalLabel");
                if (endOfFuncNode != null)
                {
                    string label = endOfFuncNode.InnerXml.Substring(1, endOfFuncNode.InnerXml.Length - 2);
                    if (label == endOfFunctionLabel)
                    {
                        return typeof(void);
                    }
                }
                else if (GetTag(ops) == Actions.Tag.Return)
                {
                    return typeof(object);
                }

                if (!ops.MoveToNext())
                {
                    throw new InvalidContentException("was expecting to see end of function searching for return type");
                }

                // invoke recursively to skip over local functions
                if (GetTag(ops) == Actions.Tag.Declare_Function)
                {
                    string codeEndLabel = ops.SelectSingleNode("CodeSize").InnerXml.Substring(1);
                    string eofLabel = codeEndLabel.Substring(0, codeEndLabel.IndexOf('#'));
                    Type returnType = ScanForReturnType(ops.Clone(), eofLabel);
                }
            }
        }

        private void DeclareLocals(ILGenerator il, bool isRoot)
        {
            // 0: temp
            // 1: temp
            // 2: temp
            // 3: local variables
            // 4: local functions
            // 5, 6, 7, 8: flash "registers" 0-3

            il.DeclareLocal(typeof(object));
            il.DeclareLocal(typeof(object));
            il.DeclareLocal(typeof(object));
            il.DeclareLocal(typeof(Dictionary<string, object>));
            il.DeclareLocal(typeof(Dictionary<string, MethodInfo>));
            il.DeclareLocal(typeof(object));
            il.DeclareLocal(typeof(object));
            il.DeclareLocal(typeof(object));
            il.DeclareLocal(typeof(object));

            if (isRoot) il.Emit(OpCodes.Ldnull);
            else il.Emit(OpCodes.Newobj, typeof(Dictionary<string, object>).GetConstructor(new Type[]{}));
            il.Emit(OpCodes.Stloc_3);

            if (isRoot) il.Emit(OpCodes.Ldnull);
            else il.Emit(OpCodes.Newobj, typeof(Dictionary<string, FunctionAndEnvironment>).GetConstructor(new Type[] { }));
            il.Emit(OpCodes.Stloc_S, (byte)4);

        /*    for (int i = 5; i <= 8; ++i)
            {
                il.Emit(OpCodes.Ldnull);
                il.Emit(OpCodes.Stloc_S, (byte)i);
            }*/
        }

        private void ExtractOrdinalities(XPathNavigator ops)
        {
            for (; ; )
            {
                XPathNavigator next = ops.Clone();
                if (!next.MoveToNext()) break;
                Actions.Tag tag = GetTag(next);
                if (tag == Actions.Tag.Call_Function || tag == Actions.Tag.New || tag == Actions.Tag.Declare_Array || tag == Actions.Tag.Call_Method)
                {
                    if (GetTag(ops) != Actions.Tag.Push_Data)
                    {
                        throw new InvalidContentException("extracting ordinality; didn't find push before op");
                    }

                    XPathNavigator data = ops.SelectSingleNode("DataList/ACTIONDATAARRAY");
                    XPathNodeIterator xpni = data.SelectChildren(XPathNodeType.All);

                    int target = 2;
                    if (tag == Actions.Tag.Declare_Array) target = 1;
                    if (tag == Actions.Tag.Call_Method) target = 3;

                    if (xpni.Count < target)
                    {
                        throw new InvalidContentException("expecting more data pushed in extracting ordinalities");
                    }
                    for (int i = 0; i < xpni.Count - (target - 1); ++i)
                    {
                        xpni.MoveNext();
                    }
                    XPathNavigator ordnav = xpni.Current.Clone();
                    if (ordnav.Name != "Integer" && ordnav.Name != "Double")
                    {
                        throw new InvalidContentException("expecting number push for ordinality");
                    }
                    ordnav.MoveToFirstChild();
                    next.AppendChild("<Ordinality>" + ordnav.Value + "</Ordinality>");

                }

                bool ret = ops.MoveToNext();
                if (!ret)
                {
                    throw new InvalidContentException("couldn't move to next op in ExtractFunctionCallOrdinality");
                }
            }
        }

        class LabelMap : Dictionary<string, System.Reflection.Emit.Label> { };

        class SubFunctionData
        {
            public MethodBuilder Method;
            public ILGenerator SavedIL;
            public StackMirror SavedStack;
            public string EndOfFunctionLabel;
            public string InternalFuncName;
            public string InLanguageName;
            public LabelMap SavedLabelMap;

            public SubFunctionData(MethodBuilder method, ILGenerator prevIL, LabelMap labelMap, StackMirror stack, string eofLabel, string internalName, string languageName)
            {
                Method = method;
                SavedIL = prevIL;
                SavedLabelMap = labelMap;
                SavedStack = stack;
                EndOfFunctionLabel = eofLabel;
                InternalFuncName = internalName;
                InLanguageName = languageName;
            }
        }

        LabelMap DefineLocalLabels(XPathNavigator nav, ILGenerator il)
        {
            LabelMap ret = new LabelMap();
            for (; ; )
            {
                XPathNavigator label = nav.SelectSingleNode("LocalLabel");
                if (label != null)
                {
                    string noQuotes = label.Value.Substring(1, label.Value.Length - 2);
                    ret[noQuotes] = il.DefineLabel();
                }

                if (!nav.MoveToNext()) break;
            }
            return ret;
        }

        class StackMirror
        {
            static object unknown = new object();
            List<object> stack = new List<object>();
            public void Push(object o) { stack.Add(o); }
            public void Pop() { stack.RemoveAt(stack.Count - 1); }
            public void Pop(int howMany) { for (int i = 0; i < howMany; ++i) Pop(); }
            public void PushUnknown() { stack.Add(unknown); }
            public object Get(int fromTop)
            {
                return stack[stack.Count - 1 - fromTop];
            }
            public int GetInt(int fromTop)
            {
                object o = stack[stack.Count - 1 - fromTop];
                return (int)(double)o;
            }
            public static bool IsUnknown(object o) { return o == unknown; }
        }

        public void GenerateMethod(XPathNavigator nav, string str, string methodName)
        {
            mGeneratedSomeMethods = true;
            //MessageBox.Show(methodName);
            StackMirror stack = new StackMirror();

            List<SubFunctionData> subFunctionStack = new List<SubFunctionData>();

            MethodBuilder method = mTypeBuilder.DefineMethod(methodName, MethodAttributes.Public | MethodAttributes.Static, typeof(void), new Type[] { typeof(CharacterSpriteInstance) });
            ILGenerator il = method.GetILGenerator();
            DeclareLocals(il, true);

            XPathNavigator ops = nav.SelectSingleNode(str);
            ops.MoveToFirstChild();

            List<string> currentDictionary = new List<string>();

            LabelMap localLabels = DefineLocalLabels(ops.Clone(), il);

            // bind this for main movie
            il.Emit(OpCodes.Ldstr, "this");
            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Ldarg_0); // push context
            il.Emit(OpCodes.Ldloc_3); // locals
            il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("SetLocalVariable"));

            for (; ; )
            {
                XPathNavigator localLabel = ops.SelectSingleNode("LocalLabel");
                if (localLabel != null)
                {
                    string labelName = localLabel.Value.Substring(1, localLabel.Value.Length - 2);
                    il.MarkLabel(localLabels[labelName]);
                    if (subFunctionStack.Count > 0)
                    {
                        SubFunctionData sfd = subFunctionStack[subFunctionStack.Count - 1];
                        if (sfd.EndOfFunctionLabel == labelName)
                        {
                            il.Emit(OpCodes.Ret);
                            il = sfd.SavedIL;
                            localLabels = sfd.SavedLabelMap;
                            stack = sfd.SavedStack;

                            // store it into the current object as a language value
                            // it doesn't appear to be possible to get the method info for the method
                            // while it's being generated, so instead we make a call to support function
                            // passing the string name and the object to setvariable into
                            // could probably do a fixup pass on the assembly instead, and it'd be ever
                            // so slightly faster at runtime, but.. meh.
                            il.Emit(OpCodes.Ldarg_0); // push context
                            il.Emit(OpCodes.Ldloc_S, (byte)4); // function def locals
                            il.Emit(OpCodes.Ldstr, sfd.InternalFuncName);
                            il.Emit(OpCodes.Ldstr, sfd.InLanguageName);
                            if (sfd.InLanguageName != "")
                            {
                                il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("FunctionDefinitionHelper"));
                            }
                            else
                            {
                                il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("FunctionDefinitionHelperExpr"));
                                stack.PushUnknown();
                            }
                            subFunctionStack.RemoveAt(subFunctionStack.Count - 1);
                        }
                    }
                }

                switch (GetTag(ops))
                {
                    case Actions.Tag.Push_Data:
                        XPathNavigator data = ops.SelectSingleNode("DataList/ACTIONDATAARRAY");
                        data.MoveToFirstChild();
                        for (;;)
                        {
                            if (data.Name == "Lookup")
                            {
                                stack.Push(currentDictionary[data.ValueAsInt]);
                                il.Emit(OpCodes.Ldstr, currentDictionary[data.ValueAsInt]);
                                il.Emit(OpCodes.Box, typeof(System.String));
                            }
                            else if (data.Name == "Integer")
                            {
                                stack.Push((double)(data.ValueAsInt));
                                il.Emit(OpCodes.Ldc_R8, (double)(data.ValueAsInt));
                                il.Emit(OpCodes.Box, typeof(System.Double));
                            }
                            else if (data.Name == "Double")
                            {
                                stack.Push((double)(data.ValueAsDouble));
                                il.Emit(OpCodes.Ldc_R8, data.ValueAsDouble);
                                il.Emit(OpCodes.Box, typeof(System.Double));
                            }
                            else if (data.Name == "String")
                            {
                                stack.Push(data.Value);
                                il.Emit(OpCodes.Ldstr, Uri.UnescapeDataString(data.Value));
                                il.Emit(OpCodes.Box, typeof(System.String));
                            }
                            else if (data.Name == "Register")
                            {
                                stack.PushUnknown();
                                il.Emit(OpCodes.Ldloc_S, (byte)(data.ValueAsInt + 5));
                            }
                            else if (data.Name == "Boolean")
                            {
                                if (data.ValueAsInt == 0)
                                {
                                    stack.Push(false);
                                    il.Emit(OpCodes.Ldc_I4_0);
                                }
                                else
                                {
                                    stack.Push(true);
                                    il.Emit(OpCodes.Ldc_I4_1);
                                }
                                il.Emit(OpCodes.Box, typeof(System.Boolean));
                            }
                            else
                            {
                                throw new InvalidContentException("unhandled push type");
                            }
                            if (!data.MoveToNext()) break;
                        }
                        break;

                    case Actions.Tag.Pop:
                        stack.Pop();
                        il.Emit(OpCodes.Pop);
                        break;

                    case Actions.Tag.Set_Variable:
                        // variable, value already on stack
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Ldloc_3); // push locals
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("SetVariable"));
                        stack.Pop(2);
                        break;

                    case Actions.Tag.Set_Local_Variable:
                        // variable, value already on stack
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Ldloc_3); // locals
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("SetLocalVariable"));
                        stack.Pop(2);
                        break;

                    case Actions.Tag.Declare_Local_Variable:
                        // variable already on stack
                        il.Emit(OpCodes.Ldsfld, typeof(ScriptSupport).GetField("undefined"));
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Ldloc_3); // locals
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("SetLocalVariable"));
                        stack.Pop(1);
                        break;

                    case Actions.Tag.Get_Variable:
                        // name already on stack
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Ldloc_3); // push locals
                        il.Emit(OpCodes.Ldloc_S, (byte)4); // push local functions
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("GetVariable"));
                        stack.Pop(1); stack.PushUnknown();
                        break;

                    case Actions.Tag.Get_Property:
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("GetProperty"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Set_Property:
                        throw new InvalidContentException("haven't done SetProperty yet");
                        break;

                    case Actions.Tag.Get_Member:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("GetMember"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Set_Member:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("SetMember"));
                        stack.Pop(3);
                        break;

                    case Actions.Tag.Store_Register:
                        int reg = SwfProcessorImpl.GetInt(ops, "Register");
                        il.Emit(OpCodes.Dup);
                        il.Emit(OpCodes.Stloc_S, (byte)(reg + 5));
                        break;
                        
                    case Actions.Tag.Add_Typed:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Add"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Subtract:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Subtract"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Increment:
                        il.Emit(OpCodes.Ldc_R8, 1.0);
                        il.Emit(OpCodes.Box, typeof(double));
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Add"));
                        stack.Pop(); stack.PushUnknown();
                        break;

                    case Actions.Tag.Decrement:
                        il.Emit(OpCodes.Ldc_R8, 1.0);
                        il.Emit(OpCodes.Box, typeof(double));
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Subtract"));
                        stack.Pop(); stack.PushUnknown();
                        break;

                    case Actions.Tag.Less_Than_Typed:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("LessThanTyped"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Greater_Than:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("GreaterThan"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Logical_Not:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Not"));
                        stack.Pop(); stack.PushUnknown();
                        break;

                    case Actions.Tag.Logical_Or:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Or"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Logical_And:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("And"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Multiply:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Multiply"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Divide:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Divide"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Modulo:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Modulo"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Equal_Typed:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("EqualTyped"));
                        stack.Pop(2); stack.PushUnknown();
                        break;

                    case Actions.Tag.Trace:
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("Trace"));
                        stack.Pop();
                        break;

                    case Actions.Tag.Branch_If_True:
                        {
                            string brOff = ops.SelectSingleNode("BranchOffset").Value;
                            string labelName = brOff.Substring(1, brOff.IndexOf('#') - 1);
                            il.Emit(OpCodes.Unbox_Any, typeof(System.Boolean));
                            il.Emit(OpCodes.Brtrue, localLabels[labelName]);
                            stack.Pop();
                        }
                        break;

                    case Actions.Tag.Branch_Always:
                        {
                            string brOff = ops.SelectSingleNode("BranchOffset").Value;
                            string labelName = brOff.Substring(1, brOff.IndexOf('#') - 1);
                            il.Emit(OpCodes.Br, localLabels[labelName]);
                        }
                        break;

                    case Actions.Tag.Declare_Array:
                        {
                            int ordinality = stack.GetInt(0);
                            Type[] types = new Type[ordinality + 1];
                            for (int i = 0; i < ordinality + 1; ++i) types[i] = typeof(object);
                            il.EmitCall(OpCodes.Call, typeof(ScriptSupport).GetMethod("InitializeArray"), types);
                            stack.Pop(ordinality + 1);
                            stack.PushUnknown();
                        }
                        break;

                    case Actions.Tag.Get_URL:
                        string urlString = Uri.UnescapeDataString(ops.SelectSingleNode("UrlString").Value);
                        string targetString = Uri.UnescapeDataString(ops.SelectSingleNode("TargetString").Value);
                        il.Emit(OpCodes.Ldarg_0);
                        il.Emit(OpCodes.Ldstr, urlString);
                        il.Emit(OpCodes.Ldstr, targetString);
                        il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("GetURL"));
                        break;

                    case Actions.Tag.Declare_Dictionary:
                        XPathNavigator stringArray = ops.SelectSingleNode("ConstantPool/STRINGARRAY");
                        stringArray.MoveToFirstChild();
                        List<string> strings = new List<string>();
                        for (; ; )
                        {
                            strings.Add(Uri.UnescapeDataString(stringArray.Value));
                            if (!stringArray.MoveToNext()) break;
                        }
                        currentDictionary = strings;
                        break;

                    case Actions.Tag.Declare_Function:
                        List<Type> numParams = new List<Type>();
                        List<string> names = new List<string>();
                        XPathNavigator parmsNode = ops.SelectSingleNode("Params/STRINGARRAY");
                        numParams.Add(typeof(CharacterSpriteInstance)); // where it was defined
                        numParams.Add(typeof(IScriptObject)); // 'this'
                        if (parmsNode != null)
                        {
                            parmsNode.MoveToFirstChild();
                            for (;;)
                            {
                                names.Add(parmsNode.Value);
                                numParams.Add(typeof(object));
                                if (!parmsNode.MoveToNext()) break;
                            }
                        }
                        Type[] parms = new Type[numParams.Count];
                        numParams.CopyTo(parms);

                        // unfortunately, this is the only way to tell if the return value should be void, or object
                        // methodbuilder doesn't allow update of return types, and flash doesn't know if there's a return value (until one is returned)
                        // so, we scan down the nodes until the endOfFunctionLabel. if we see a ret opcode we know we have a return
                        // otherwise, we assume it's void.
                        string codeEndLabel = ops.SelectSingleNode("CodeSize").InnerXml.Substring(1);
                        string endOfFunctionLabel = codeEndLabel.Substring(0, codeEndLabel.IndexOf('#'));
                        Type returnType = ScanForReturnType(ops.Clone(), endOfFunctionLabel);

                        string inLanguageName = ops.SelectSingleNode("FunctionName").Value;
                        string internalFuncName = inLanguageName + "_" + Guid.NewGuid().ToString("N");

                        MethodBuilder internalMethod = mTypeBuilder.DefineMethod(internalFuncName, MethodAttributes.Static | MethodAttributes.Public, returnType, parms);

                        subFunctionStack.Add(new SubFunctionData(internalMethod, il, localLabels, stack, endOfFunctionLabel, internalFuncName, inLanguageName));

                        stack = new StackMirror();
                        il = internalMethod.GetILGenerator();
                        DeclareLocals(il, false);
                        localLabels = DefineLocalLabels(ops.Clone(), il);

                        // prolog binding parameters in local context (local3)
                        {
                            il.Emit(OpCodes.Ldloc_3);
                            il.Emit(OpCodes.Ldstr, "this");
                            il.Emit(OpCodes.Ldarg_1);
                            il.Emit(OpCodes.Callvirt, typeof(Dictionary<string, object>).GetMethod("set_Item"));

                            int i = 0;
                            foreach (string name in names)
                            {
                                il.Emit(OpCodes.Ldloc_3);
                                il.Emit(OpCodes.Ldstr, name);
                                il.Emit(OpCodes.Ldarg_S, (byte)(i + 2));
                                il.Emit(OpCodes.Callvirt, typeof(Dictionary<string, object>).GetMethod("set_Item"));
                                ++i;
                            }
                        }

                        break;

                    case Actions.Tag.New:
                        {
                            int ordinality = stack.GetInt(1);
                            Type[] types = new Type[ordinality + 3];
                            for (int i = 0; i < ordinality + 3; ++i) types[i] = typeof(object);
                            il.Emit(OpCodes.Ldarg_0); // push context
                            il.EmitCall(OpCodes.Call, typeof(ScriptSupport).GetMethod("InitializeObject"), types);
                            stack.Pop(ordinality + 2);
                            stack.PushUnknown();
                        }
                        break;

                    case Actions.Tag.Call_Method:
                        {
                            // args, numargs, object, name already on stack
                            int ordinality = stack.GetInt(2);
                            Type[] types = new Type[ordinality + 3];
                            for (int i = 0; i < ordinality + 3; ++i) types[i] = typeof(object);
                            il.EmitCall(OpCodes.Call, typeof(ScriptSupport).GetMethod("CallMethodTrampoline"), types);
                            stack.Pop(ordinality + 3);
                            stack.PushUnknown();
                        }
                        break;

                    case Actions.Tag.Call_Function:
                        {
                            // name already on stack
                            il.Emit(OpCodes.Ldarg_0); // push context
                            il.Emit(OpCodes.Ldloc_3); // push locals
                            il.Emit(OpCodes.Ldloc_S, (byte)4); // push local functions
                            il.Emit(OpCodes.Call, typeof(ScriptSupport).GetMethod("GetVariable"));
                            stack.Pop(1); stack.PushUnknown();

                            int ordinality = stack.GetInt(1);
                            Type[] types = new Type[ordinality + 2];
                            for (int i = 0; i < ordinality + 2; ++i) types[i] = typeof(object);
                            il.EmitCall(OpCodes.Call, typeof(ScriptSupport).GetMethod("CallFunctionTrampoline"), types);
                            stack.Pop(ordinality + 2);
                            stack.PushUnknown();
                        }
                        break;

                    case Actions.Tag.With:
                        {
                        }
                        break;

                    case Actions.Tag.Stop_Sound:
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Call, typeof(CharacterSpriteInstance).GetMethod("Stop")); // todo;
                        break;

                    case Actions.Tag.Stop:
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Call, typeof(CharacterSpriteInstance).GetMethod("Stop"));
                        break;

                    case Actions.Tag.Play:
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Call, typeof(CharacterSpriteInstance).GetMethod("Play"));
                        break;

                    case Actions.Tag.Goto_Frame:
                        il.Emit(OpCodes.Ldarg_0); // push context
                        il.Emit(OpCodes.Call, typeof(CharacterSpriteInstance).GetMethod("GotoAndPlay"));
                        break;

                    case Actions.Tag.Return:
                        il.Emit(OpCodes.Ret);
                        break;

                    case Actions.Tag.End:
                        il.Emit(OpCodes.Ret);
                        break;

                    default:
                        throw new InvalidContentException("unhandled tag in action: " + GetTag(ops).ToString());
                }

                if (!ops.MoveToNext()) break;
            }

            /*
            il.Emit(OpCodes.Ldstr, "weewaa");
            il.Emit(OpCodes.Box, typeof(System.String));
            il.Emit(OpCodes.Ldc_R8, 99.0);
            il.Emit(OpCodes.Box, typeof(System.Double));
            il.Emit(OpCodes.Call, typeof(FluixRuntime).GetMethod("Add"));
            il.Emit(OpCodes.Ret);
             */
        }
    }
}