using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline.Processors;
using Microsoft.Win32;
using Fluix;
using Fluix.Impl;
using System.Reflection;

using System.Xml;
using System.Xml.XPath;

namespace FluixPipe
{
    public class SwfProcessorImpl
    {
        ILTranslator mILTrans;
        struct Wave
        {
            public string Name;
            public string Filename;
            public Wave(string n, string fn)
            {
                Name = n;
                Filename = fn;
            }
        }
        List<Wave> mWaves = new List<Wave>();
        Dictionary<KeyValuePair<string, int>, int> mGeneratedFonts = new Dictionary<KeyValuePair<string,int>,int>();
        List<FontContent> mFonts = new List<FontContent>();

        private SoundBankData GenerateSoundBanks(string mainName, string dir, TargetPlatform platform)
        {
            if (mWaves.Count == 0) return null;

            string wavetemplate = @"
    Wave
    {
        Name = %%%WAVNAME%%%;
        File = %%%WAVFILENAME%%%;
    }
";
            string soundtemplate = @"
    Sound
    {
        Name = %%%SOUNDNAME%%%;
        Volume = -1200;
        Pitch = 0;
        Priority = 0;

        Category Entry
        {
            Name = Default;
        }

        Track
        {
            Volume = 0;

            Play Wave Event
            {
                Wave Entry
                {
                    Bank Name = %%%NAME%%%wb;
                    Bank Index = 0;
                    Entry Name = %%%WAVNAME%%%;
                    Entry Index = %%%WAVINDEX%%%;
                }
            }
        }
    }

";
            string cuetemplate = @"
    Cue
    {
        Name = %%%CUENAME%%%;

        Sound Entry
        {
            Name = %%%SOUNDNAME%%%;
            Index = 0;
            Weight Min = 0;
            Weight Max = 255;
        }
    }
";

            string xaptemplate = @"Signature = XACT2;
Version = 13;

Options
{
}

Global Settings
{
    Xbox File = %%%NAME%%%.xgs;
    Windows File = %%%NAME%%%.xgs;
    Exclude Category Names = 1;
    Exclude Variable Names = 1;
}

Wave Bank
{
    Name = %%%NAME%%%wb;
    Xbox File = %%%NAME%%%.xwb;
    Windows File = %%%NAME%%%.xwb;
    Seek Tables = 1;
    Compression Preset Name = <none>;
%%%WAVES%%%
}

Sound Bank
{
    Name = %%%NAME%%%sb;
    Xbox File = %%%NAME%%%.xsb;
    Windows File = %%%NAME%%%.xsb;
%%%SOUNDS%%%

%%%CUES%%%
}
";

            string waves = "";
            string sounds = "";
            string cues = "";

            int index = 0;
            foreach (Wave w in mWaves)
            {
                waves += wavetemplate.Replace("%%%WAVNAME%%%", w.Name)
                                     .Replace("%%%WAVFILENAME%%%", w.Filename);
                sounds += soundtemplate.Replace("%%%NAME%%%", mainName)
                                       .Replace("%%%SOUNDNAME%%%", w.Name)
                                       .Replace("%%%WAVNAME%%%", w.Name)
                                       .Replace("%%%WAVINDEX%%%", index.ToString());
                cues += cuetemplate.Replace("%%%SOUNDNAME%%%", w.Name)
                                   .Replace("%%%CUENAME%%%", w.Name);
                ++index;
            }

            string xapContents = xaptemplate.Replace("%%%NAME%%%", mainName)
                                            .Replace("%%%WAVES%%%", waves)
                                            .Replace("%%%SOUNDS%%%", sounds)
                                            .Replace("%%%CUES%%%", cues);

            string xapfile = dir + "\\" + mainName + ".xap";
            File.WriteAllText(xapfile, xapContents);

            string codeBase = (string)Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\XNA\Game Studio Express\v1.0", "InstallPath", null);
            if (codeBase == null)
            {
                throw new Exception("couldn't find XactBld location by using registry");
            }
            codeBase += "Tools";
            string platArg = "/windows";
            if (platform == TargetPlatform.Xbox360) platArg = "/xbox360";
            ProcessStartInfo psi = new ProcessStartInfo(codeBase + "\\XactBld.exe", platArg + " " + xapfile);
            psi.CreateNoWindow = true;
            psi.UseShellExecute = false;
            psi.RedirectStandardError = true;
            psi.RedirectStandardOutput = true;
            Process p = new Process();
            p.StartInfo = psi;
            p.Start();
            p.WaitForExit();
            if (p.ExitCode != 0)
            {
                throw new Exception("couldn't build sound bank");
            }

            return new SoundBankData(
                File.ReadAllBytes(dir + "\\" + mainName + ".xgs"),
                File.ReadAllBytes(dir + "\\" + mainName + ".xwb"),
                File.ReadAllBytes(dir + "\\" + mainName + ".xsb"));
        }

        public static int GetInt(XPathNavigator nav, string str)
        {
            return int.Parse(nav.SelectSingleNode(str).InnerXml);
        }

        public static float GetFloat(XPathNavigator nav, string str, float defaultValue)
        {
            XPathNavigator node = nav.SelectSingleNode(str);
            if (node == null) return defaultValue;
            return float.Parse(node.InnerXml);
        }

        public static float GetFloat(XPathNavigator nav, string str)
        {
            return float.Parse(nav.SelectSingleNode(str).InnerXml);
        }

        public static string GetString(XPathNavigator nav, string str)
        {
            return nav.SelectSingleNode(str).Value;
        }

        public static Matrix2D GetMatrix2D(XPathNavigator nav, string startOf, bool fixedPtRotSkew)
        {
            XPathNavigator mat = nav.SelectSingleNode(startOf);
            float sx = GetFloat(mat, "ScaleX");
            float sy = GetFloat(mat, "ScaleY");
            float r0 = GetFloat(mat, "RotateSkew0");
            float r1 = GetFloat(mat, "RotateSkew1");
            float tx = GetFloat(mat, "TranslateX");
            float ty = GetFloat(mat, "TranslateY");
            Matrix2D ret = new Matrix2D();
            ret.m00 = sx;
            ret.m01 = r0;
            ret.m11 = sy;
            ret.m10 = r1;
            ret.tx = tx;
            ret.ty = ty;
            return ret;
        }

        public static Cxform GetColorMatrix(XPathNavigator nav, string startOf)
        {
            XPathNavigator mat = nav.SelectSingleNode(startOf);
            float mr = GetFloat(mat, "RedMultTerm", 256) / 256.0f;
            float mg = GetFloat(mat, "GreenMultTerm", 256) / 256.0f;
            float mb = GetFloat(mat, "BlueMultTerm", 256) / 256.0f;
            float ma = GetFloat(mat, "AlphaMultTerm", 256) / 256.0f;
            float ar = GetFloat(mat, "RedAddTerm", 0) / 255.0f;
            float ag = GetFloat(mat, "GreenAddTerm", 0) / 255.0f;
            float ab = GetFloat(mat, "BlueAddTerm", 0) / 255.0f;
            float aa = GetFloat(mat, "AlphaAddTerm", 0) / 255.0f;
            return new Cxform(new Vector4(mr, mg, mb, ma), new Vector4(ar, ag, ab, aa));
        }

#if false // other version that spits out MeshContent
        private ModelContent LoadGeo(int id, string outpath)
        {
            MeshBuilder builder = MeshBuilder.StartMesh("shape" + id.ToString());
            string[] lines = File.ReadAllLines(outpath + "\\" + id.ToString() + ".geo");
            foreach (string line in lines)
            {
                string[] parts = line.Split(new char[] { ' ' });
                if (parts[0] == "v")
                {
                    builder.CreatePosition(float.Parse(parts[1]) / 20.0f, float.Parse(parts[2]) / 20.0f, 0.0f);
                }
            }

            foreach (string line in lines)
            {
                string[] parts = line.Split(new char[] { ' ' });
                if (parts[0] == "mat")
                {
                    if (parts[1] == "solid")
                    {
                        BasicMaterialContent mat = new BasicMaterialContent();
                        mat.DiffuseColor = new Microsoft.Xna.Framework.Vector3(byte.Parse(parts[2]) / 255.0f, byte.Parse(parts[3]) / 255.0f, byte.Parse(parts[4]) / 255.0f);
                        mat.Alpha = byte.Parse(parts[5]) / 255.0f;
                        builder.SetMaterial(mat);
                    }
                    else
                    {
                        throw new InvalidContentException("unhandled material type");
                    }
                }
                else if (parts[0] == "t")
                {
                    builder.AddTriangleVertex(int.Parse(parts[1]));
                    builder.AddTriangleVertex(int.Parse(parts[2]));
                    builder.AddTriangleVertex(int.Parse(parts[3]));
                }
            }

            MeshContent mesh = builder.FinishMesh();
            return ctx.Convert<MeshContent, ModelContent>(mesh, "ModelProcessor");
        }
#endif
        private List<VertexSet> LoadGeo(int id, string outpath)
        {
            string[] lines = File.ReadAllLines(outpath + "\\" + id.ToString() + ".geo");
            List<Vector2> allVerts = new List<Vector2>();
            foreach (string line in lines)
            {
                string[] parts = line.Split(new char[] { ' ' });
                if (parts[0] == "v")
                {
                    allVerts.Add(new Vector2(float.Parse(parts[1]) / 20.0f, float.Parse(parts[2]) / 20.0f));
                }
            }

            List<VertexSet> ret = new List<VertexSet>();
            List<VertexPositionChunk> verts = null;
            VertexSet curVS = null;
            foreach (string line in lines)
            {
                string[] parts = line.Split(new char[] { ' ' });
                if (parts[0] == "mat")
                {
                    if (verts != null && curVS != null)
                    {
                        VertexPositionChunk[] vertsArr = new VertexPositionChunk[verts.Count];
                        verts.CopyTo(vertsArr);
                        curVS.Vertices = vertsArr;
                        ret.Add(curVS);
                    }
                    verts = new List<VertexPositionChunk>();
                    if (parts[1] == "solid")
                    {
                        curVS = new VertexSet(new Vector4(
                            byte.Parse(parts[2]) / 255.0f,
                            byte.Parse(parts[3]) / 255.0f,
                            byte.Parse(parts[4]) / 255.0f,
                            byte.Parse(parts[5]) / 255.0f));
                    }
                    else if (parts[1] == "textured")
                    {
                        VertexSet.MaterialType matType = VertexSet.MaterialType.TextureWrapped;
                        if (parts[2] == "clamp") matType = VertexSet.MaterialType.TextureClamped;
                        float sx = float.Parse(parts[4]) / 20.0f;
                        float sy = float.Parse(parts[5]) / 20.0f;
                        float sk0 = float.Parse(parts[6]) / 20.0f;
                        float sk1 = float.Parse(parts[7]) / 20.0f;
                        float tx = float.Parse(parts[8]) / 20.0f;
                        float ty = float.Parse(parts[9]) / 20.0f;
                        Matrix matrix = new Matrix(sx, sk0, 0.0f, 0.0f,
                            sk1, sy, 0.0f, 0.0f,
                            0.0f, 0.0f, 1.0f, 0.0f,
                            tx, ty, 0.0f, 1.0f);
                        curVS = new VertexSet(int.Parse(parts[3]), matrix, matType);
                    }
                }
                else if (parts[0] == "t")
                {
                    if (curVS == null) throw new Exception("triangle before material?");
                    verts.Add(new VertexPositionChunk(allVerts[int.Parse(parts[1])]));
                    verts.Add(new VertexPositionChunk(allVerts[int.Parse(parts[2])]));
                    verts.Add(new VertexPositionChunk(allVerts[int.Parse(parts[3])]));
                }
            }

            if (verts != null)
            {
                VertexPositionChunk[] vertsArr = new VertexPositionChunk[verts.Count];
                verts.CopyTo(vertsArr);
                curVS.Vertices = vertsArr;
                ret.Add(curVS);
            }
            return ret;
        }

        enum ParseDLTagResult { WasntOne, ReadTag, EndOfFrame };
        private ParseDLTagResult ParseDisplayListTag(XPathNavigator nav, Frame curFrame, string spriteAndFrameName)
        {
            if (nav.Name == "PlaceObject2")
            {
                //const byte HasClipActions = 0x80;
                //const byte HasClipDepth = 0x40;
                const byte HasName = 0x20;
                //const byte HasRatio = 0x10;
                const byte HasColorTransform = 0x8;
                const byte HasMatrix = 0x4;
                const byte HasCharacter = 0x2;
                //const byte HasMove = 0x1;
                int depth = GetInt(nav, "Depth");
                ControlCommandPlace place = new ControlCommandPlace(depth);
                byte flags = (byte)GetInt(nav, "Flags");
                if ((flags & HasMatrix) != 0)
                {
                    place.Matrix = GetMatrix2D(nav, "Matrix/MATRIX", false);
                }
                if ((flags & HasColorTransform) != 0)
                {
                    place.ColorMatrix = GetColorMatrix(nav, "ColorTransform/CXFORMWITHALPHA");
                }
                if ((flags & HasCharacter) != 0)
                {
                    place.ID = GetInt(nav, "CharacterID");
                }
                if ((flags & HasName) != 0)
                {
                    place.Name = GetString(nav, "Name");
                }
                place.HasData = (ControlCommandPlace.Has)flags;
                curFrame.Display.Add(place);
                return ParseDLTagResult.ReadTag;
            }
            else if (nav.Name == "RemoveObject2")
            {
                int depth = GetInt(nav, "Depth");
                curFrame.Display.Add(new ControlCommandRemove(depth));
                return ParseDLTagResult.ReadTag;
            }
            else if (nav.Name == "ShowFrame")
            {
                return ParseDLTagResult.EndOfFrame;
            }
            else if (nav.Name == "DoAction")
            {
                mILTrans.GenerateMethod(nav, "Actions/ACTIONRECORDARRAY", spriteAndFrameName);
                curFrame.Display.Add(new ControlCommandAction(spriteAndFrameName));
                return ParseDLTagResult.ReadTag;
            }
            else if (nav.Name == "SoundStreamHead2")
            {
                // todo; ignore for now
                return ParseDLTagResult.ReadTag;
            }
            else if (nav.Name == "End")
            {
                // nothing to be done
                return ParseDLTagResult.ReadTag;
            }
            else if (nav.Name == "FrameLabel")
            {
                string name = GetString(nav, "Name");
                // todo; something
                return ParseDLTagResult.ReadTag;
            }
            return ParseDLTagResult.WasntOne;
        }

        private List<Frame> ParseDisplayList(XPathNavigator nav, int spriteId)
        {
            List<Frame> ret = new List<Frame>();
            Frame curFrame = new Frame();
            int tagCount = 0;
            for (; ; )
            {
                ParseDLTagResult result = ParseDisplayListTag(nav, curFrame, "Sprite" + spriteId + "_Frame" + ret.Count + "_" + tagCount);
                if (result == ParseDLTagResult.EndOfFrame)
                {
                    ret.Add(curFrame);
                    curFrame = new Frame();
                }
                else if (result == ParseDLTagResult.WasntOne)
                {
                    throw new InvalidContentException("Was expecting display list tag. Got '" + nav.Name + "'");
                }
                if (!nav.MoveToNext()) break;
                tagCount++;
            }
            return ret;
        }

        private int GetFont(string name, int height, ContentProcessorContext ctx)
        {
            KeyValuePair<string, int> f = new KeyValuePair<string, int>(name, height);
            if (mGeneratedFonts.ContainsKey(f)) return mGeneratedFonts[f];
            FontGenerator fg = new FontGenerator(name, height, ctx);
            FontContent fc = fg.Generate(' ', '~');
            mFonts.Add(fc);
            mGeneratedFonts[f] = mFonts.Count - 1;
            return mFonts.Count - 1;
        }

        public SwfCompiled Process(SwfContentItem input, ContentProcessorContext context)
        {
            // load all textures, sounds, geometry, tags
            // put textures, sounds, geometry into "normal" nodes
            // put the tags into a swfimportedxmltags or something
            XPathNavigator nav = input.Tags;
            Dictionary<int, string> fontNames = new Dictionary<int, string>();

            string assemblyFullPath = input.BaseName + ".fa";
            mILTrans = new ILTranslator(input.BaseName, "FluixAS_" + input.BaseName, assemblyFullPath);
            nav = nav.SelectSingleNode("Tags");
            nav.MoveToFirstChild();
            SwfCompiled ret = new SwfCompiled();
            CharacterSprite mainSprite = new CharacterSprite(0);
            ret.Main = mainSprite;
            ret.AssemblyTypeName = input.BaseName;
            Frame curFrame = new Frame();
            int tagCount = 0;
            for (;;)
            {
                ParseDLTagResult result = ParseDisplayListTag(nav, curFrame, "Sprite0_Frame" + mainSprite.Frames.Count + "_" + tagCount);

                if (result == ParseDLTagResult.ReadTag)
                {
                    // ok, nothing to do
                }
                else if (result == ParseDLTagResult.EndOfFrame)
                {
                    mainSprite.Frames.Add(curFrame);
                    curFrame = new Frame();
                }
                else if (nav.Name == "FrameRate")
                {
                    ret.FrameRate = GetInt(nav, "Value");
                }
                else if (nav.Name == "NumFrames")
                {
                    ret.NumFrames = GetInt(nav, "Value");
                }
                else if (nav.Name == "SetBackgroundColor")
                {
                    ret.BackgroundColour = new Color(
                        (byte)GetInt(nav, "BackgroundColor/RGB/Red"),
                        (byte)GetInt(nav, "BackgroundColor/RGB/Green"),
                        (byte)GetInt(nav, "BackgroundColor/RGB/Blue"));
                }
                else if (nav.Name == "DefineShape" || nav.Name == "DefineShape2" || nav.Name == "DefineShape3")
                {
                    int id = GetInt(nav, "ShapeID");
                    CharacterShape shape = new CharacterShape(id);
                    shape.VertexSets = LoadGeo(id, input.ExtractedAssetDir);
                    ret.Characters.Add(id, shape);
                }
                else if (nav.Name == "DefineSprite")
                {
                    int id = GetInt(nav, "SpriteID");
                    CharacterSprite sprite = new CharacterSprite(id);
                    XPathNavigator controlTags = nav.SelectSingleNode("ControlTags/TAGARRAY");
                    controlTags.MoveToFirstChild();
                    sprite.Frames = ParseDisplayList(controlTags, id);
                    ret.Characters.Add(id, sprite);
                }
                else if (nav.Name == "DefineButton2")
                {
                    // todo;
                }
                else if (nav.Name == "DefineBitsLossless" || nav.Name == "DefineBitsLossless2")
                {
                    int id = GetInt(nav, "CharacterID");
                    TextureContent tex = context.BuildAndLoadAsset<TextureContent, TextureContent>(new ExternalReference<TextureContent>(input.ExtractedAssetDir + "\\" + id + ".tga"), "NextPowerOfTwoTextureProcessor");
                    ret.Textures.Add(id, (Texture2DContent)tex);
                    ret.TextureData.Add(id, new TextureData((int)tex.OpaqueData["OrigWidth"], (int)tex.OpaqueData["OrigHeight"]));
                }
                else if (nav.Name == "DefineBits" || nav.Name == "DefineBitsJPEG" || nav.Name == "DefineBitsJPEG2")
                {
                    int id = GetInt(nav, "CharacterID");
                    TextureContent tex = context.BuildAndLoadAsset<TextureContent, TextureContent>(new ExternalReference<TextureContent>(input.ExtractedAssetDir + "\\" + id + ".jpg"), "NextPowerOfTwoTextureProcessor");
                    ret.Textures.Add(id, (Texture2DContent)tex);
                    ret.TextureData.Add(id, new TextureData((int)tex.OpaqueData["OrigWidth"], (int)tex.OpaqueData["OrigHeight"]));
                }
                else if (nav.Name == "DefineSound")
                {
                    int id = GetInt(nav, "SoundID");
                    ret.Characters.Add(id, new CharacterSound(id));
                }
                else if (nav.Name == "DefineFont2")
                {
                    fontNames[GetInt(nav, "FontID")] = Uri.UnescapeDataString(GetString(nav, "FontName"));
                }
                else if (nav.Name == "DefineText")
                {
                    //throw new InvalidContentException("encountered 'DefineText' indicating 'Static' text field. All text fields must be 'Dynamic' in Flash");
                }
                else if (nav.Name == "DefineEditText")
                {
                    int id = GetInt(nav, "CharacterID");
                    int flags = GetInt(nav, "Flags");

                    const int HasText = 0x80;
                    const int WordWrap = 0x40;
                    const int Multiline = 0x20;
                    const int Password = 0x10;
                    const int ReadOnly = 0x8;
                    const int HasTextColour = 0x4;
                    //const int HasMaxLength = 0x2;
                    const int HasFont = 0x1;

                    string initialText = (flags & HasText) == HasText ? Uri.UnescapeDataString(GetString(nav, "InitialText")) : "";
                    bool wordWrap = (flags & WordWrap) == WordWrap;
                    bool multiline = (flags & Multiline) == Multiline;

                    if ((flags & Password) == Password) throw new InvalidContentException("password text fields aren't currently supported");
                    if ((flags & ReadOnly) == 0) throw new InvalidContentException("editable text fields aren't currently supported");

                    if ((flags & HasFont) == 0) throw new InvalidContentException("expecting to have font for text field");

                    Vector4 colour = new Vector4(0, 0, 0, 255);
                    if ((flags & HasTextColour) == HasTextColour)
                    {
                        colour = new Vector4(
                                GetInt(nav, "TextColor/RGBA/Red"),
                                GetInt(nav, "TextColor/RGBA/Green"),
                                GetInt(nav, "TextColor/RGBA/Blue"),
                                GetInt(nav, "TextColor/RGBA/Alpha"));
                    }

                    int xmin = GetInt(nav, "Bounds/RECT/Xmin") / 20;
                    int ymin = GetInt(nav, "Bounds/RECT/Ymin") / 20;
                    Rectangle bounds = new Rectangle(xmin, ymin, xmin + GetInt(nav, "Bounds/RECT/Xmax") / 20, ymin + GetInt(nav, "Bounds/RECT/Ymax") / 20);

                    int align = GetInt(nav, "Align");

                    string variable = Uri.UnescapeDataString(GetString(nav, "VariableName"));

                    int height = GetInt(nav, "FontHeight") / 20;
                    string fontName = fontNames[GetInt(nav, "FontID")];

                    int fontId = GetFont(fontName, height, context);
                    ret.Characters.Add(id, new CharacterText(id, fontId, initialText, variable, bounds, wordWrap, multiline, colour, (CharacterText.Align)align));
                }
                else if (nav.Name == "JPEGTables")
                {
                    // nothing to do
                }
                else if (nav.Name == "ExportAssets")
                {
                    XPathNavigator assets = nav.SelectSingleNode("Assets/ASSETARRAY");
                    for (; ; )
                    {
                        int id = assets.SelectSingleNode("ASSET/ID").ValueAsInt;
                        string name = assets.SelectSingleNode("ASSET/Name").Value;
                        ret.Exports[id] = name;

                        if (ret.Characters.ContainsKey(id))
                        {
                            if (ret.Characters[id] is CharacterSound)
                            {
                                mWaves.Add(new Wave(name, input.ExtractedAssetDir + "\\" + id + ".wav"));
                            }
                        }

                        if (!assets.MoveToNext()) break;
                    }
                }
                else if (nav.Name == "PathsArePostscript")
                {
                    // ignore for now
                }
                else
                {
                    throw new InvalidContentException("Unhandled tag type: " + nav.Name);
                }

                if (!nav.MoveToNext()) break;

                tagCount++;
            }

            bool hadSomeMethods = mILTrans.Finish();
            if (hadSomeMethods)
            {
                ret.CodeAssembly = File.ReadAllBytes(assemblyFullPath);
                File.Delete(assemblyFullPath);
            }

            ret.SoundData = GenerateSoundBanks(input.BaseName, input.ExtractedAssetDir, context.TargetPlatform);
            ret.Fonts = mFonts;

            return ret;
        }
    }

    [ContentProcessor(DisplayName="SWF - Fluix")]
    class SwfProcessor : ContentProcessor<SwfContentItem, SwfCompiled>
    {
        public override SwfCompiled Process(SwfContentItem input, ContentProcessorContext context)
        {
            SwfProcessorImpl impl = new SwfProcessorImpl();
            return impl.Process(input, context);
        }
    }

    [ContentProcessor(DisplayName="Texture (Next power-of-two, no mips, DXT) - Fluix (Internal)")]
    internal class NextPowerOfTwoTextureProcessor : ContentProcessor<TextureContent, TextureContent>
    {
        private static bool HasFractionalAlpha(TextureContent input)
        {
            foreach (PixelBitmapContent<Color> content in input.Faces[0])
            {
                for (int i = 0; i < content.Height; i++)
                {
                    foreach (Color color in content.GetRow(i))
                    {
                        byte a = color.A;
                        if ((a != 0xff) && (a != 0))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private static bool IsPowerOfTwo(int x)
        {
            return ((x & (x - 1)) == 0);
        }

        private static int NextPowerOfTwo(int x)
        {
            if (IsPowerOfTwo(x)) return x;
            double log = Math.Truncate(Math.Log(x, 2)) + 1;
            return (int)Math.Pow(2, log);
        }

        public override TextureContent Process(TextureContent input, ContentProcessorContext context)
        {
            input.ConvertBitmapType(typeof(PixelBitmapContent<Color>));
            BitmapContent source = input.Faces[0][0];
            BitmapContent upsized = new PixelBitmapContent<Color>(NextPowerOfTwo(source.Width), NextPowerOfTwo(source.Height));
            BitmapContent.Copy(source, new Rectangle(0, 0, source.Width, source.Height),
                upsized, new Rectangle(0, 0, source.Width, source.Height));

            // fill boundaries to help linear mip

            // right of texture
            PixelBitmapContent<Color> us = (PixelBitmapContent<Color>)upsized;
            int fillWithRight = (upsized.Width - source.Width) / 2 + source.Width;
            for (int y = 0; y < source.Height; ++y)
            {
                Color right = us.GetPixel(source.Width - 1, y);
                Color left = us.GetPixel(0, y);
                for (int x = source.Width; x < us.Width; ++x)
                {
                    if (x < fillWithRight)
                    {
                        us.SetPixel(x, y, right);
                    }
                    else
                    {
                        us.SetPixel(x, y, left);
                    }
                }
            }

            // below texture
            int fillWithBottom = (upsized.Height - source.Height) / 2 + source.Height;
            for (int x = 0; x < source.Width; ++x)
            {
                Color bottom = us.GetPixel(x, source.Height - 1);
                Color top = us.GetPixel(x, 0);
                for (int y = source.Height; y < us.Height; ++y)
                {
                    if (y < fillWithBottom)
                    {
                        us.SetPixel(x, y, bottom);
                    }
                    else
                    {
                        us.SetPixel(x, y, top);
                    }
                }
            }

            // bottom right
            Color brColour = us.GetPixel(source.Width - 1, source.Height - 1);
            for (int x = source.Width; x < us.Width; ++x)
            {
                for (int y = source.Height; y < us.Height; ++y)
                {
                    us.SetPixel(x, y, brColour);
                }
            }

            input.Faces[0][0] = upsized;

            if (HasFractionalAlpha(input))
            {
                input.ConvertBitmapType(typeof(Dxt5BitmapContent));
            }
            else
            {
                input.ConvertBitmapType(typeof(Dxt1BitmapContent));
            }
            input.OpaqueData["OrigWidth"] = source.Width;
            input.OpaqueData["OrigHeight"] = source.Height;

            return input;
        }
    }
}
