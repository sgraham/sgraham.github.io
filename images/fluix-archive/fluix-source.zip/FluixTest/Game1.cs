using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Fluix;

namespace FluixTest
{
    public partial class Form1 : Form
    {
        GraphicsDevice device;

        VertexPositionColor[] triVerts = new VertexPositionColor[] {
            new VertexPositionColor(Vector3.Zero*2,
                        Microsoft.Xna.Framework.Graphics.Color.Blue),
            new VertexPositionColor(Vector3.Right*2,
                        Microsoft.Xna.Framework.Graphics.Color.Green),
            new VertexPositionColor(Vector3.Up*2,
                        Microsoft.Xna.Framework.Graphics.Color.Red)};

        Effect triEffect;

        Timer redrawTimer;

        string strEffect;

        float yRotation = 0.0f;

        public Form1()
        {
            InitializeComponent();
        }

        private void OnLoad(object sender, EventArgs e)
        {
            PresentationParameters pp = new PresentationParameters();
            pp.BackBufferCount = 1;
            pp.IsFullScreen = false;
            pp.SwapEffect = SwapEffect.Discard;
            pp.BackBufferWidth = panelViewport.Width;
            pp.BackBufferHeight = panelViewport.Height;

            pp.AutoDepthStencilFormat = DepthFormat.Depth24Stencil8;
            pp.EnableAutoDepthStencil = true;
            pp.PresentationInterval = PresentInterval.Default;
            pp.BackBufferFormat = SurfaceFormat.Unknown;
            pp.MultiSampleType = MultiSampleType.None;

            device = new GraphicsDevice(GraphicsAdapter.DefaultAdapter,
                DeviceType.Hardware, this.panelViewport.Handle,
                CreateOptions.HardwareVertexProcessing,
                pp);

            strEffect = File.ReadAllText("SimpleEffect.fx");



            ResetGraphicsDevice();
        }

        private void OnViewportResize(object sender, EventArgs e)
        {
            ResetGraphicsDevice();
        }

        private void ResetGraphicsDevice()
        {
            if (redrawTimer != null)
            {
                redrawTimer.Stop();
            }

            if (panelViewport.Width == 0 || panelViewport.Height == 0)
                return;

            if (triEffect != null)
                triEffect.Dispose();

            device.PresentationParameters.BackBufferWidth = panelViewport.Width;
            device.PresentationParameters.BackBufferHeight = panelViewport.Height;

            device.Reset();


            CompiledEffect compEffect = Effect.CompileEffectFromSource(strEffect,
                null, null, CompilerOptions.Debug, TargetPlatform.Windows);

            System.Diagnostics.Debug.Assert(compEffect.Success == true,
                                            compEffect.ErrorsAndWarnings);

            byte[] effectCode = compEffect.GetEffectCode();

            triEffect = new Effect(device, effectCode, CompilerOptions.Debug, null);

            triEffect.CurrentTechnique = triEffect.Techniques[0];

            if (redrawTimer == null)
            {
                redrawTimer = new Timer();
                redrawTimer.Interval = 16;
                redrawTimer.Tick += new EventHandler(redrawTimer_Tick);
            }

            redrawTimer.Start();

            OnVieweportPaint(null, null);
        }

        void redrawTimer_Tick(object sender, EventArgs e)
        {
            OnVieweportPaint(null, null);
        }

        private void OnVieweportPaint(object sender, PaintEventArgs e)
        {
            device.Clear(Microsoft.Xna.Framework.Graphics.Color.LightBlue);

            device.VertexDeclaration = new VertexDeclaration(device, VertexPositionColor.VertexElements);

            device.RenderState.CullMode = CullMode.None;

            triEffect.Parameters["WorldViewProj"].SetValue(
                Matrix.CreateRotationY(yRotation) *
                Matrix.CreateLookAt(Vector3.Backward * 10,
                    Vector3.Zero, Vector3.Up) *
                Matrix.CreatePerspectiveFieldOfView(MathHelper.Pi / 4.0f,
                    (float)panelViewport.Width / (float)panelViewport.Height,
                    1.0f, 100.0f));

            triEffect.CommitChanges();


            triEffect.Begin();

            triEffect.Techniques[0].Passes[0].Begin();

            device.DrawUserPrimitives<VertexPositionColor>(PrimitiveType.TriangleList,
                triVerts, 0, 1);

            triEffect.Techniques[0].Passes[0].End();

            triEffect.End();

            device.Present();
        }

        private void OnScrollRotation(object sender, ScrollEventArgs e)
        {
            yRotation = MathHelper.ToRadians(e.NewValue);
            OnVieweportPaint(null, null);
        }
    }

}

#if false
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Fluix;

namespace FluixTest
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        ContentManager content;
        MovieInstance testMovie;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            content = new ContentManager(Services);
            graphics.PreferredBackBufferWidth = 1280;
            graphics.PreferredBackBufferHeight = 720;
        }


        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            base.Initialize();
        }


        /// <summary>
        /// Load your graphics content.  If loadAllContent is true, you should
        /// load content from both ResourceManagementMode pools.  Otherwise, just
        /// load ResourceManagementMode.Manual content.
        /// </summary>
        /// <param name="loadAllContent">Which type of content to load.</param>
        protected override void LoadGraphicsContent(bool loadAllContent)
        {
            if (loadAllContent)
            {
                testMovie = MovieInstance.Create("Data/test8", graphics.GraphicsDevice, content);
                //testMovie.UseMovieBackgroundColor = true;

                 // TODO: Load any ResourceManagementMode.Automatic content
            }

            // TODO: Load any ResourceManagementMode.Manual content
        }


        /// <summary>
        /// Unload your graphics content.  If unloadAllContent is true, you should
        /// unload content from both ResourceManagementMode pools.  Otherwise, just
        /// unload ResourceManagementMode.Manual content.  Manual content will get
        /// Disposed by the GraphicsDevice during a Reset.
        /// </summary>
        /// <param name="unloadAllContent">Which type of content to unload.</param>
        protected override void UnloadGraphicsContent(bool unloadAllContent)
        {
            if (unloadAllContent == true)
            {
                content.Unload();
            }
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Space))
            {
                return;
            }
            
            // Allows the default game to exit on Xbox 360 and Windows
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();

            testMovie.Update(gameTime);

            // TODO: Add your update logic here

            base.Update(gameTime);
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);

            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            testMovie.Draw();
            
//            double fps = 1.0f / gameTime.ElapsedGameTime.TotalSeconds;
  //          Window.Title = "FluixTest  FPS: " + fps.ToString("F");
        }
    }
}

#endif