using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Fluix;
using OrganicBit.Zip;

namespace FluixTest
{
    public partial class FunctionalTest : Form, IServiceProvider
    {
        #region Numeric sort code from http://www.codeproject.com/cs/algorithms/csnsort.asp
        
        public class NumericComparer : IComparer<string>
        {
            public NumericComparer()
            { }

            public int Compare(string x, string y)
            {
                return StringLogicalComparer.Compare((string)x, (string)y);
            }
        }

        // emulates StrCmpLogicalW, but not fully
        public class StringLogicalComparer
        {
            public static int Compare(string s1, string s2)
            {
                //get rid of special cases
                if ((s1 == null) && (s2 == null)) return 0;
                else if (s1 == null) return -1;
                else if (s2 == null) return 1;

                if ((s1.Equals(string.Empty) && (s2.Equals(string.Empty)))) return 0;
                else if (s1.Equals(string.Empty)) return -1;
                else if (s2.Equals(string.Empty)) return -1;

                //WE style, special case
                bool sp1 = Char.IsLetterOrDigit(s1, 0);
                bool sp2 = Char.IsLetterOrDigit(s2, 0);
                if (sp1 && !sp2) return 1;
                if (!sp1 && sp2) return -1;

                int i1 = 0, i2 = 0; //current index
                int r = 0; // temp result
                while (true)
                {
                    bool c1 = Char.IsDigit(s1, i1);
                    bool c2 = Char.IsDigit(s2, i2);
                    if (!c1 && !c2)
                    {
                        bool letter1 = Char.IsLetter(s1, i1);
                        bool letter2 = Char.IsLetter(s2, i2);
                        if ((letter1 && letter2) || (!letter1 && !letter2))
                        {
                            if (letter1 && letter2)
                            {
                                r = Char.ToLower(s1[i1]).CompareTo(Char.ToLower(s2[i2]));
                            }
                            else
                            {
                                r = s1[i1].CompareTo(s2[i2]);
                            }
                            if (r != 0) return r;
                        }
                        else if (!letter1 && letter2) return -1;
                        else if (letter1 && !letter2) return 1;
                    }
                    else if (c1 && c2)
                    {
                        r = CompareNum(s1, ref i1, s2, ref i2);
                        if (r != 0) return r;
                    }
                    else if (c1)
                    {
                        return -1;
                    }
                    else if (c2)
                    {
                        return 1;
                    }
                    i1++;
                    i2++;
                    if ((i1 >= s1.Length) && (i2 >= s2.Length))
                    {
                        return 0;
                    }
                    else if (i1 >= s1.Length)
                    {
                        return -1;
                    }
                    else if (i2 >= s2.Length)
                    {
                        return -1;
                    }
                }
            }

            private static int CompareNum(string s1, ref int i1, string s2, ref int i2)
            {
                int nzStart1 = i1, nzStart2 = i2; // nz = non zero
                int end1 = i1, end2 = i2;

                ScanNumEnd(s1, i1, ref end1, ref nzStart1);
                ScanNumEnd(s2, i2, ref end2, ref nzStart2);
                int start1 = i1; i1 = end1 - 1;
                int start2 = i2; i2 = end2 - 1;

                int nzLength1 = end1 - nzStart1;
                int nzLength2 = end2 - nzStart2;

                if (nzLength1 < nzLength2) return -1;
                else if (nzLength1 > nzLength2) return 1;

                for (int j1 = nzStart1, j2 = nzStart2; j1 <= i1; j1++, j2++)
                {
                    int r = s1[j1].CompareTo(s2[j2]);
                    if (r != 0) return r;
                }
                // the nz parts are equal
                int length1 = end1 - start1;
                int length2 = end2 - start2;
                if (length1 == length2) return 0;
                if (length1 > length2) return -1;
                return 1;
            }

            //lookahead
            private static void ScanNumEnd(string s, int start, ref int end, ref int nzStart)
            {
                nzStart = start;
                end = start;
                bool countZeros = true;
                while (Char.IsDigit(s, end))
                {
                    if (countZeros && s[end].Equals('0'))
                    {
                        nzStart++;
                    }
                    else countZeros = false;
                    end++;
                    if (end >= s.Length) break;
                }
            }
        }
        #endregion

        class TextBoxListener : TraceListener
        {
            TextBox mTextBox;
            public TextBoxListener(TextBox t)
            {
                mTextBox = t;
            }

            public override void Write(string message)
            {
                mTextBox.Text += message;
                mTextBox.SelectionStart = mTextBox.Text.Length;
                mTextBox.SelectionLength = 0;
                mTextBox.ScrollToCaret();
            }
            public override void WriteLine(string message)
            {
                Write(message + "\r\n");
            }
        }

        private SimpleGraphicsDeviceService graphicsDeviceService;
        private Microsoft.Xna.Framework.Content.ContentManager contentManager;
        int count = 0;
        Texture2D mBBTex;

        VertexPositionColor[] triVerts = new VertexPositionColor[] {
            new VertexPositionColor(Vector3.Zero*2,
                        Microsoft.Xna.Framework.Graphics.Color.Blue),
            new VertexPositionColor(Vector3.Right*2,
                        Microsoft.Xna.Framework.Graphics.Color.Green),
            new VertexPositionColor(Vector3.Up*2,
                        Microsoft.Xna.Framework.Graphics.Color.Red)};

        System.Windows.Forms.Timer redrawTimer;
        MovieInstance mViewing;
        MovieInstance mTesting;
        bool mOnlyView;
        string mInitialSelection;
        GameServiceContainer Services;

        public new object GetService(Type serviceType)
        {
            if (serviceType == typeof(Microsoft.Xna.Framework.Graphics.IGraphicsDeviceService))
                return this.graphicsDeviceService;
            else
                return base.GetService(serviceType);
        }

        public FunctionalTest(string[] args)
        {
            InitializeComponent();
            Services = new GameServiceContainer();
            if (args.Length > 0)
            {
                mOnlyView = true;
                listView.ContextMenuStrip = null;
                mInitialSelection = args[0];
            }
            else
            {
                mOnlyView = false;
            }
        }

        private void OnLoad(object sender, EventArgs e)
        {
            graphicsDeviceService = new SimpleGraphicsDeviceService(panelViewport, mOnlyView);
            graphicsDeviceService.CreateDevice();
            if (!mOnlyView)
            {
                mBBTex = new Texture2D(graphicsDeviceService.GraphicsDevice, panelViewport.Width, panelViewport.Height, 1, ResourceUsage.ResolveTarget, SurfaceFormat.Rgba32, ResourceManagementMode.Manual);
            }

            contentManager = new Microsoft.Xna.Framework.Content.ContentManager(this);
            redrawTimer = new System.Windows.Forms.Timer();
            redrawTimer.Interval = 16;
            redrawTimer.Tick += new EventHandler(redrawTimer_Tick);
            redrawTimer.Start();

            listView.SelectedIndexChanged += new EventHandler(listView_SelectedIndexChanged);

            string[] tests = Directory.GetFiles("tests", "*.xnb", SearchOption.AllDirectories);
            Array.Sort(tests, new NumericComparer());
            ListViewItem initial = null;
            foreach (string test in tests)
            {
                string testWOXnb = Path.GetDirectoryName(test) + "\\" + Path.GetFileNameWithoutExtension(test);
                try
                {
                    MovieInstance movie = MovieInstance.Create(testWOXnb, graphicsDeviceService.GraphicsDevice, contentManager);
                    movie.OnFSCommand += new FSCommandEventDelegate(movie_OnFSCommand);
                    ListViewItem lvi = new ListViewItem(new string[] { "", testWOXnb });
                    listView.Items.Add(lvi);
                    if (mInitialSelection == testWOXnb)
                    {
                        initial = lvi;
                    }
                }
                catch (Microsoft.Xna.Framework.Content.ContentLoadException)
                {
                    //break;
                }
            }

            if (initial != null)
            {
                initial.Selected = true;
            }

            Debug.Listeners.Add(new TextBoxListener(textBoxOutput));
        }

        void movie_OnFSCommand(object sender, FSCommandEventArgs fse)
        {
            Debug.WriteLine("fscommand: '" + fse.Command + "', params: '" + fse.Parameters + "'");
        }

        void listView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView.SelectedIndices.Count == 1)
            {
                textBoxOutput.Text = "";
                mViewing = MovieInstance.Create(listView.Items[listView.SelectedIndices[0]].SubItems[1].Text, graphicsDeviceService.GraphicsDevice, contentManager);
                mViewing.OnFSCommand += new FSCommandEventDelegate(movie_OnFSCommand);
            }
            else
            {
                mViewing = null;
            }
        }

        void redrawTimer_Tick(object sender, EventArgs e)
        {
            redrawTimer.Stop();
            OnViewportPaint(null, null);
            redrawTimer.Start();
        }

        void DoRenderOf(MovieInstance movie, bool oneFrame, int count)
        {
            movie.UseMovieBackgroundColor = true;
            if (count != -1) Debug.WriteLine("--- FRAME " + count + " ---");
            if (count == 0)
            {
                movie.FlushActions();
            }
            else
            {
                if (oneFrame) movie.UpdateAdvanceExactlyOneFrame();
                else movie.Update(new GameTime(new TimeSpan(0), new TimeSpan(166666), new TimeSpan(0), new TimeSpan(166666)));
            }
            movie.Draw();
        }
        
        private TextWriterTraceListener mTraceListener;
        
        private void AddFile(ZipWriter zip, string fn)
        {
            byte[] buffer = new byte[4096];
            int byteCount;
            ZipEntry entry = new ZipEntry(fn);
            entry.Method = CompressionMethod.Stored;
            entry.ModifiedTime = File.GetLastWriteTime(entry.Name);
            zip.AddEntry(entry);
            FileStream reader = File.OpenRead(entry.Name);
            while ((byteCount = reader.Read(buffer, 0, buffer.Length)) > 0) { zip.Write(buffer, 0, byteCount); }
            reader.Close();
        }

        private void OnViewportPaint(object sender, PaintEventArgs e)
        {
            GraphicsDevice device = graphicsDeviceService.GraphicsDevice;

            if (mTesting == null && mToTestList != null && mToTestList.Count > 0)
            {
                textBoxOutput.Text = "";
                mTesting = MovieInstance.Create(listView.Items[mToTestList[0]].SubItems[1].Text, graphicsDeviceService.GraphicsDevice, contentManager);
                mTesting.OnFSCommand += new FSCommandEventDelegate(movie_OnFSCommand);
                Stream traceFile = File.Create("trace.txt");
                mTraceListener = new TextWriterTraceListener(traceFile);
                Debug.Listeners.Add(mTraceListener);
                mViewing = null;
                count = 0;
            }

            if (mTesting != null)
            {
                try
                {
                    DoRenderOf(mTesting, true, count);
                    device.ResolveBackBuffer(mBBTex);
                    mBBTex.Save(count + ".png", ImageFileFormat.Png);
                    ++count;
                    if (count == mTesting.NumFrames)
                    {
                        string zipFn = @"..\..\..\" + listView.Items[mToTestList[0]].SubItems[1].Text + ".ok.zip";
                        Trace.Flush();
                        mTraceListener.Close();
                        Debug.Listeners.Remove(mTraceListener);
                        if (mMode == TestMode.Update)
                        {
                            ZipWriter zip = new ZipWriter(zipFn);
                            for (int i = 0; i < count; ++i)
                            {
                                AddFile(zip, i + ".png");
                            }
                            AddFile(zip, "trace.txt");
                            zip.Close();
                            listView.Items[mToTestList[0]].SubItems[0].Text = "Updated";
                        }
                        else if (mMode == TestMode.Test)
                        {
                            ZipReader reader = new ZipReader(zipFn);

                            bool failed = false;

                            // buffer to hold temp bytes
                            byte[] buffer = new byte[4096];
                            int byteCount;

                            // Get the zipped entries
                            while (reader.MoveNext())
                            {
                                ZipEntry entry = reader.Current;

                                if (!File.Exists(entry.Name))
                                {
                                    failed = true;
                                    break;
                                }

                                byte[] newFile = new byte[0];
                                while ((byteCount = reader.Read(buffer, 0, buffer.Length)) > 0)
                                {
                                    long oldLen = newFile.Length;
                                    Array.Resize(ref newFile, newFile.Length + byteCount);
                                    Array.Copy(buffer, 0, newFile, oldLen, byteCount);
                                }

                                byte[] origFile = File.ReadAllBytes(entry.Name);
                                if (origFile.Length != newFile.Length)
                                {
                                    failed = true;
                                    break;
                                }

                                for (int i = 0; i < origFile.Length; ++i)
                                {
                                    if (newFile[i] != origFile[i])
                                    {
                                        failed = true;
                                        break;
                                    }
                                }

                                if (failed) break;
                            }

                            listView.Items[mToTestList[0]].SubItems[0].Text = failed ? "FAIL: " + reader.Current.Name : "Passed";

                            reader.Close();
                        }

                        mTesting = null;
                        mToTestList.RemoveAt(0);
                        count = 0;
                    }
                }
                catch (Exception except)
                {
                    listView.Items[mToTestList[0]].SubItems[0].Text = "FAIL: threw " + except.ToString();
                    mTesting = null;
                    mTraceListener.Close();
                    Debug.Listeners.Remove(mTraceListener);
                    mToTestList.RemoveAt(0);
                    count = 0;
                }
            }
            else if (mViewing != null)
            {
                DoRenderOf(mViewing, false, -1);
            }
            else
            {
                device.Clear(Microsoft.Xna.Framework.Graphics.Color.Black);
            }
            device.Present();

            //mBBTex.Save("test11_" + count++ + ".png", ImageFileFormat.Png);


        }

        private void shellExecuteOriginalSWFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count == 1)
            {
                Process.Start(@"..\..\..\" + listView.SelectedItems[0].SubItems[1].Text + ".swf");
                redrawTimer.Stop();
                Thread.Sleep(2000);
                redrawTimer.Start();
            }
        }

        enum TestMode { Test, Update };
        TestMode mMode;
        private List<int> mToTestList;
        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetPendingList();
            mMode = TestMode.Test;
        }

        void SetPendingList()
        {
            mToTestList = new List<int>();
            //foreach (ListViewItem lvi in listView.Items) lvi.SubItems[0].Text = "";
            foreach (int item in listView.SelectedIndices)
            {
                listView.Items[item].SubItems[0].Text = "Pending";
                mToTestList.Add(item);
            }
        }

        private void updateTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetPendingList();
            mMode = TestMode.Update;
        }
    }


    class SimpleGraphicsDeviceService : IGraphicsDeviceService, IGraphicsDeviceManager
    {
        private GraphicsDevice graphicsDevice;
        private System.Windows.Forms.Control renderControl;
        private bool doHardware;
        public SimpleGraphicsDeviceService(System.Windows.Forms.Control renderControl, bool hardware)
        {
            this.renderControl = renderControl;
            doHardware = hardware;
        }

        #region IGraphicsDeviceService Members
        public event EventHandler DeviceCreated;
        public event EventHandler DeviceDisposing;
        public event EventHandler DeviceReset;
        public event EventHandler DeviceResetting;

        public GraphicsDevice GraphicsDevice
        {
            get { return this.graphicsDevice; }
        }
        #endregion

        #region IGraphicsDeviceManager Members
        public bool BeginDraw()
        {
            //throw new Exception("The method or operation is not implemented.");
            return false;
        }

        public void CreateDevice()
        {
            Microsoft.Xna.Framework.Graphics.PresentationParameters presentationParameters = new
            Microsoft.Xna.Framework.Graphics.PresentationParameters();
            presentationParameters.IsFullScreen = false;
            presentationParameters.BackBufferCount = 1;
            presentationParameters.BackBufferHeight = this.renderControl.Height;
            presentationParameters.BackBufferWidth = this.renderControl.Width;
            presentationParameters.MultiSampleType = MultiSampleType.None;
            DeviceType dt = DeviceType.Reference;
            if (doHardware) dt = DeviceType.Hardware;
            this.graphicsDevice = new GraphicsDevice(
              GraphicsAdapter.Adapters[0],
              dt,
              this.renderControl.Handle,
              CreateOptions.HardwareVertexProcessing,
              presentationParameters);
        }

        public void EndDraw()
        {
            //throw new Exception("The method or operation is not implemented.");
        }
        #endregion
    }
}